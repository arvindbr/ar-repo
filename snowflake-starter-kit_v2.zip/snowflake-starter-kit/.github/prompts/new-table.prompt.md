---
mode: agent
description: Generate a Snowflake table DDL with best practices
---

Generate a Snowflake `CREATE TABLE` statement following project conventions.

Ask the user for:
1. Table name (snake_case, plural noun)
2. Schema and database (or use defaults from project config)
3. Column definitions with business meaning
4. Whether this is a fact, dimension, or staging table
5. Expected row volume and query patterns (to recommend clustering keys)

Then generate:

- A `CREATE OR REPLACE TABLE` statement with `IF NOT EXISTS` consideration
- Appropriate Snowflake data types (`NUMBER`, `VARCHAR`, `TIMESTAMP_NTZ`, `VARIANT`, `BOOLEAN`)
- A primary key constraint (Snowflake doesn't enforce, but useful for documentation)
- `COMMENT` on the table and on each column explaining purpose
- A `CLUSTER BY` clause if the table is large and has predictable filter patterns
- Audit columns: `created_at`, `updated_at`, `created_by`, `updated_by` where appropriate
- A header comment block with: purpose, owner, dependencies, and last-modified

Place the file in `sql/ddl/` with the naming convention `<table_name>.sql`.

After generating, suggest a corresponding test query to validate the DDL.
