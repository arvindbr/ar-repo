---
mode: agent
description: Generate pytest tests for Snowflake code
---

Generate pytest tests for the Python file or SQL artifact in context.

For Python code:
- Use `unittest.mock.MagicMock` to mock the Snowflake connection and cursor
- Test happy path, edge cases, and error handling
- Assert that the correct SQL was passed to `cursor.execute()`
- Verify parameterized query usage (no string interpolation of user input)
- Use pytest fixtures for reusable mock setups
- Tag integration tests with `@pytest.mark.integration` so they can be skipped in CI without credentials

For SQL artifacts:
- Generate a Python test that runs the SQL against a `_TEST` schema
- Set up test data, run the artifact, assert results, tear down
- Use transactions where possible to roll back automatically
- For DDL tests, validate the resulting schema with `INFORMATION_SCHEMA` queries

Test file structure:
```python
import pytest
from unittest.mock import MagicMock, patch

@pytest.fixture
def mock_snowflake_conn():
    conn = MagicMock()
    cursor = MagicMock()
    conn.cursor.return_value.__enter__.return_value = cursor
    return conn, cursor

class TestMyFunction:
    def test_happy_path(self, mock_snowflake_conn):
        conn, cursor = mock_snowflake_conn
        # ... test logic
        cursor.execute.assert_called_once_with(...)

    def test_handles_empty_result(self, mock_snowflake_conn):
        # ...

    @pytest.mark.integration
    def test_against_real_snowflake(self):
        # ...
```

Place test files in `tests/` mirroring the source structure.
File naming: `test_<module_name>.py`.
Class naming: `Test<ClassName>`.
Function naming: `test_<scenario_being_tested>`.
