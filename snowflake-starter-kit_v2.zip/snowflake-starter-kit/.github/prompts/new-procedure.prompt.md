---
mode: agent
description: Scaffold a Snowflake stored procedure with proper error handling
---

Generate a Snowflake stored procedure following project conventions.

Ask the user for:
1. Procedure name (prefix `sp_`, snake_case)
2. Purpose and inputs
3. Language preference: SQL Scripting, JavaScript, or Python (Snowpark)

Then generate:

- A `CREATE OR REPLACE PROCEDURE` statement
- Properly typed input parameters with default values where sensible
- A clear `RETURNS` clause
- `EXECUTE AS CALLER` or `EXECUTE AS OWNER` (recommend with reasoning)
- A `COMMENT` describing the procedure's purpose, inputs, and outputs
- Inside the body:
  - Input validation
  - A TRY/CATCH (JavaScript) or EXCEPTION block (SQL Scripting/Python) for error handling
  - Logging via `SYSTEM$LOG()` or inserts to an audit log table
  - Return status: success/failure with descriptive messages
- Sample `CALL` statement(s) at the bottom as a comment showing usage

Place the file in `sql/procedures/` with the naming convention `<procedure_name>.sql`.

For Snowpark Python procedures, also generate a corresponding `.py` file in `python/procedures/` that can be unit tested locally.

After generating, recommend pytest tests that mock the Snowflake session and validate the procedure logic.
