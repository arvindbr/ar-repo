---
mode: ask
description: Analyze a Snowflake query and suggest optimizations
---

Analyze the provided Snowflake SQL query and suggest optimizations.

For the query in context, evaluate:

1. **Pruning effectiveness**
   - Are filter predicates on clustered columns?
   - Are date/timestamp filters using sargable expressions?
   - Could clustering keys help?

2. **Join strategy**
   - Are joins using equality predicates?
   - Is the larger table on the appropriate side?
   - Are there missing join predicates causing cross joins?
   - Could a `BROADCAST` hint help for small dimension tables?

3. **Window functions**
   - Could `QUALIFY` replace a subquery?
   - Are partitions reasonably sized?

4. **Anti-patterns**
   - `SELECT *` in production code
   - `DISTINCT` masking duplicate-causing joins
   - `OR` conditions that could be `IN` or `UNION ALL`
   - Functions on filter columns blocking pruning (e.g., `WHERE UPPER(col) = 'X'`)
   - Unnecessary `ORDER BY` in subqueries

5. **Cost considerations**
   - Could materialized views help for repeated patterns?
   - Should this be cached as a result_scan?
   - Is the warehouse size appropriate?

Return:
- A bulleted list of findings
- A rewritten query with improvements
- Explanation of expected performance impact
- Recommended `EXPLAIN` and `QUERY_HISTORY` checks to verify

Reference Snowflake's `QUERY_PROFILE` view if deeper analysis would help.
