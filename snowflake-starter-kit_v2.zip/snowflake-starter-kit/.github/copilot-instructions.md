# GitHub Copilot Instructions for Snowflake Project

These instructions are automatically loaded by GitHub Copilot when working in this repository.

## Project Context

This is a Snowflake data platform project. We use:
- **Snowflake** as our cloud data warehouse
- **Python** with `snowflake-connector-python` and `snowflake-snowpark-python`
- **SQL** following Snowflake-specific syntax and best practices
- **pytest** for testing
- **GitHub Actions** for CI/CD

## Code Style Guidelines

### SQL
- Use **UPPERCASE** for SQL keywords (`SELECT`, `FROM`, `WHERE`, `CREATE TABLE`)
- Use **snake_case** for identifiers (tables, columns, schemas)
- Always qualify table names with database and schema: `DATABASE.SCHEMA.TABLE`
- Prefer **CTEs** over nested subqueries for readability
- Add `OR REPLACE` to `CREATE` statements during development
- Always include `IF NOT EXISTS` for idempotency where appropriate
- End every statement with a semicolon
- Use `--` for single-line comments, `/* */` for block comments
- Add a comment block at the top of each SQL file describing purpose, author, and dependencies

### Python
- Follow **PEP 8** style
- Use **type hints** on all function signatures
- Use **f-strings** for string formatting (never `%` or `.format()`)
- Use `pathlib.Path` instead of `os.path`
- Prefer **context managers** (`with` statements) for connections and cursors
- Always close Snowflake connections explicitly or use context managers
- Use `logging` module, never `print()` for production code
- Docstrings: Google style

### Snowflake-Specific Best Practices

When generating Snowflake code, always consider:

1. **Security**
   - Never hardcode credentials — use environment variables or secrets management
   - Prefer **key-pair authentication** over passwords for service accounts
   - Use **role-based access control (RBAC)** — always specify the role
   - Mask PII columns using dynamic data masking policies

2. **Performance**
   - Use **clustering keys** on large tables that are frequently filtered
   - Leverage **micro-partitions** — write predicates that prune efficiently
   - Use `QUALIFY` for window function filtering instead of subqueries
   - Avoid `SELECT *` in production code
   - Use **result caching** awareness — identical queries hit cache
   - Right-size warehouses; suspend when idle

3. **Cost**
   - Set `STATEMENT_TIMEOUT_IN_SECONDS` to prevent runaway queries
   - Use `WAREHOUSE_SIZE` appropriate to workload
   - Enable `AUTO_SUSPEND` (default 60 seconds for dev)
   - Monitor with `QUERY_HISTORY` and `WAREHOUSE_METERING_HISTORY`

4. **Data Types**
   - Use `NUMBER(precision, scale)` for exact numerics
   - Use `VARCHAR` without length for variable strings (no storage penalty)
   - Use `TIMESTAMP_NTZ` for timestamps without timezone, `TIMESTAMP_TZ` with
   - Use `VARIANT` for semi-structured JSON data
   - Use `BOOLEAN` for true/false (not `NUMBER(1)`)

5. **Naming Conventions**
   - Tables: `snake_case`, plural nouns (`customers`, `order_items`)
   - Views: prefix with `v_` or `vw_` (`v_active_customers`)
   - Stored procedures: prefix with `sp_` (`sp_load_daily_data`)
   - UDFs: prefix with `udf_` or `fn_`
   - Staging tables: prefix with `stg_`
   - Dimension tables: prefix with `dim_`
   - Fact tables: prefix with `fct_`

## Connection Patterns

When suggesting Snowflake connection code, use this pattern:

```python
from snowflake.connector import connect
from contextlib import contextmanager
import os

@contextmanager
def snowflake_connection():
    """Yields a Snowflake connection from environment variables."""
    conn = connect(
        account=os.environ["SNOWFLAKE_ACCOUNT"],
        user=os.environ["SNOWFLAKE_USER"],
        private_key_file=os.environ.get("SNOWFLAKE_PRIVATE_KEY_PATH"),
        password=os.environ.get("SNOWFLAKE_PASSWORD"),
        warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
        database=os.environ["SNOWFLAKE_DATABASE"],
        schema=os.environ["SNOWFLAKE_SCHEMA"],
        role=os.environ["SNOWFLAKE_ROLE"],
    )
    try:
        yield conn
    finally:
        conn.close()
```

## Testing Guidelines

- Mock Snowflake connections in unit tests using `unittest.mock`
- Use a separate `_TEST` schema for integration tests
- Always clean up test data with `tearDown` or fixtures
- Tag integration tests with `@pytest.mark.integration` so they can be skipped

## Things to Avoid

- ❌ Don't use `account_usage` views in time-sensitive code (latency up to 3 hours)
- ❌ Don't use `INFORMATION_SCHEMA` for very large metadata queries — use `account_usage` (with the latency caveat)
- ❌ Don't create permanent tables in shared schemas without explicit approval
- ❌ Don't use `SELECT *` in views — list columns explicitly
- ❌ Don't disable query result caching without good reason
- ❌ Don't use `BEGIN`/`COMMIT` blocks unnecessarily — Snowflake auto-commits by default

## When suggesting code, prefer

- ✅ Parameterized queries to prevent SQL injection
- ✅ Snowpark DataFrames for complex transformations in Python
- ✅ Tasks and Streams for incremental data processing
- ✅ Time Travel for recovery scenarios
- ✅ Zero-copy cloning for dev/test environment setup
