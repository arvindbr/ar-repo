---
applyTo: "**/*.sql"
---

# Copilot rules for SQL files

When generating or editing any `.sql` file in this project, follow these rules in addition to the project-wide instructions in `.github/copilot-instructions.md`:

## Mandatory file header

Every `.sql` file must begin with:

```sql
/*
 * File:        <filename>.sql
 * Purpose:     <one-line description>
 * Owner:       <team or person>
 * Dependencies: <upstream tables, schemas, roles>
 * Last modified: <YYYY-MM-DD>
 */
```

## Formatting

- UPPERCASE all SQL keywords
- snake_case identifiers; never quoted mixed-case
- Two-space indent inside CTEs and subqueries
- Always end statements with `;`
- Maximum line length 120 characters

## Naming prefixes

Use the right prefix based on object type:
- `stg_` for staging tables
- `dim_` for dimensions
- `fct_` for facts
- `v_` for views
- `sp_` for stored procedures
- `udf_` for user-defined functions
- `seq_` for sequences
- `audit_` for audit/log tables

## Snowflake data types

- Integers → `NUMBER(38,0)`
- Decimals → `NUMBER(precision, scale)` (never `FLOAT` for money)
- Strings → `VARCHAR` (no length needed)
- Timestamps → `TIMESTAMP_NTZ` unless timezone needed
- Booleans → `BOOLEAN`
- Semi-structured → `VARIANT`

## Audit columns on every analytics table

```sql
created_at        TIMESTAMP_NTZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
updated_at        TIMESTAMP_NTZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
loaded_by_run_id  VARCHAR
```

## Idempotency

- Dev: prefer `CREATE OR REPLACE`
- Prod migrations: use `CREATE ... IF NOT EXISTS`
- DML: use `MERGE` so re-runs produce the same end state

## Anti-patterns to refuse

- ❌ `SELECT *` in production code
- ❌ `WHERE UPPER(col) = 'X'` (kills pruning)
- ❌ `FLOAT` for currency
- ❌ Tables without comments
- ❌ Hardcoded credentials
