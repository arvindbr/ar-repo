---
applyTo: "python/**/*.py,boilerplates/**/*.py,tests/**/*.py"
---

# Copilot rules for Python files

When generating or editing Python in this project, follow these in addition to the project-wide instructions:

## Style

- PEP 8 with line length 100
- Use **type hints** on every public function signature
- Use `from __future__ import annotations` at the top of every file
- Use **f-strings** for string formatting (never `%` or `.format()`)
- Use `pathlib.Path` instead of `os.path`
- Google-style docstrings

## Imports

Order:
1. `from __future__ import annotations`
2. Standard library
3. Third-party
4. First-party (this project)

Use `isort` rules; the kit's `pyproject.toml` enforces this.

## Logging

- Always use `logging`, never `print()` for production code
- Module-level logger: `logger = logging.getLogger(__name__)`
- INFO for major events, DEBUG for detail, ERROR with `exc_info=True` for failures

## Snowflake connections

- Use the project's `snowflake_connection()` context manager from `python.connectors.snowflake_conn`
- Never instantiate `snowflake.connector.connect()` directly outside the connector module
- Use parameterized queries (`%(name)s`); never string-concatenate user input

```python
from python.connectors.snowflake_conn import snowflake_connection

with snowflake_connection() as conn, conn.cursor() as cur:
    cur.execute("SELECT * FROM t WHERE id = %(id)s", {"id": user_id})
```

## Tests

- Mock Snowflake connections with `MagicMock`
- Use the `mock_snowflake_connection` fixture from `tests/conftest.py`
- Tag integration tests with `@pytest.mark.integration`
- Test names: `test_<scenario>` not `test_<function_name>`

## Anti-patterns

- ❌ Hardcoded credentials anywhere
- ❌ String concatenation of user input into SQL
- ❌ `except: pass` — always log
- ❌ Mutable default arguments (`def f(x=[])`)
- ❌ Wildcard imports (`from x import *`)
