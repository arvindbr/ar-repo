"""Convenience helpers for running Snowflake queries from Python."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

from python.connectors.snowflake_conn import snowflake_connection

logger = logging.getLogger(__name__)


def run_query(
    query: str,
    params: dict[str, Any] | None = None,
) -> pd.DataFrame:
    """Execute a query and return results as a pandas DataFrame.

    Args:
        query: SQL query string. Use %(name)s for parameter binding.
        params: Optional dict of parameters for safe substitution.

    Returns:
        DataFrame with the query results.

    Example:
        df = run_query(
            "SELECT * FROM customers WHERE state = %(state)s",
            params={"state": "CA"},
        )
    """
    with snowflake_connection() as conn, conn.cursor() as cur:
        cur.execute(query, params or {})
        return cur.fetch_pandas_all()


def run_sql_file(
    path: Path | str,
    params: dict[str, Any] | None = None,
) -> list[pd.DataFrame]:
    """Run all statements in a SQL file. Returns a DataFrame per statement.

    Args:
        path: Path to the .sql file.
        params: Optional bind parameters.

    Returns:
        List of DataFrames, one per non-empty statement in the file.
    """
    sql_path = Path(path)
    statements = _split_statements(sql_path.read_text())
    results: list[pd.DataFrame] = []

    with snowflake_connection() as conn, conn.cursor() as cur:
        for stmt in statements:
            logger.debug("Executing: %s", stmt[:80])
            cur.execute(stmt, params or {})
            try:
                results.append(cur.fetch_pandas_all())
            except Exception:
                # Not every statement returns rows (e.g., DDL)
                results.append(pd.DataFrame())

    return results


def execute_many(
    query: str,
    rows: Iterable[tuple],
) -> int:
    """Bulk-insert rows using executemany().

    Args:
        query: Parameterized INSERT statement using %s placeholders.
        rows: Iterable of tuples, one per row.

    Returns:
        Number of rows inserted.
    """
    rows_list = list(rows)
    with snowflake_connection() as conn, conn.cursor() as cur:
        cur.executemany(query, rows_list)
    return len(rows_list)


def _split_statements(sql: str) -> list[str]:
    """Naive splitter on semicolons that ignores comment-only lines.

    For complex scripts with stored procedures containing semicolons in
    bodies, use a proper SQL parser like sqlparse instead.
    """
    cleaned = []
    for raw in sql.split(";"):
        stmt = raw.strip()
        # Skip empty statements and comment-only ones
        non_comment = "\n".join(
            line for line in stmt.splitlines() if not line.strip().startswith("--")
        ).strip()
        if non_comment:
            cleaned.append(stmt)
    return cleaned
