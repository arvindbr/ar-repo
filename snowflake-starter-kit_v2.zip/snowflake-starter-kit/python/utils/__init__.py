"""Shared utilities for Snowflake operations."""
