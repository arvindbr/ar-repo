"""Snowflake starter kit Python package."""
