"""Example ETL pipeline: load CSV from local stage to a Snowflake table.

This demonstrates the standard pattern:
    1. Stage the file (PUT)
    2. Create or merge into the target table (COPY INTO / MERGE)
    3. Validate row counts
    4. Clean up the stage

Replace the example with your real source and target.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import NamedTuple

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from dotenv import load_dotenv

from python.connectors.snowflake_conn import snowflake_connection

logger = logging.getLogger(__name__)


class LoadResult(NamedTuple):
    """Outcome of a single file load."""

    file_name: str
    rows_loaded: int
    rows_failed: int


def stage_and_copy(
    local_file: Path,
    stage_name: str,
    target_table: str,
    file_format: str = "(TYPE = CSV, FIELD_OPTIONALLY_ENCLOSED_BY = '\"', SKIP_HEADER = 1)",
) -> LoadResult:
    """Upload a local file to a Snowflake stage and COPY into a target table.

    Args:
        local_file: Path to the local file to load.
        stage_name: Snowflake stage name (e.g., '@my_db.my_schema.my_stage').
        target_table: Fully qualified target table name.
        file_format: Inline file format string for the COPY statement.

    Returns:
        A LoadResult summarizing the load.
    """
    if not local_file.exists():
        raise FileNotFoundError(f"Source file not found: {local_file}")

    with snowflake_connection() as conn, conn.cursor() as cur:
        # 1. PUT the file onto the stage
        # NOTE: AUTO_COMPRESS=TRUE compresses with gzip during upload
        put_stmt = (
            f"PUT 'file://{local_file.resolve()}' {stage_name} "
            f"AUTO_COMPRESS=TRUE OVERWRITE=TRUE"
        )
        logger.info("Staging file: %s", local_file.name)
        cur.execute(put_stmt)

        # 2. COPY INTO the target table
        copy_stmt = f"""
            COPY INTO {target_table}
            FROM {stage_name}/{local_file.name}.gz
            FILE_FORMAT = {file_format}
            ON_ERROR = 'CONTINUE'
        """
        logger.info("Copying into %s", target_table)
        cur.execute(copy_stmt)

        # 3. Inspect load results
        cur.execute(
            f"""
            SELECT file_name, status, row_count, row_parsed, errors_seen
            FROM TABLE(INFORMATION_SCHEMA.COPY_HISTORY(
                TABLE_NAME => '{target_table}',
                START_TIME => DATEADD(minute, -5, CURRENT_TIMESTAMP())
            ))
            ORDER BY last_load_time DESC
            LIMIT 1
            """
        )
        row = cur.fetchone()
        result = LoadResult(
            file_name=row[0] if row else local_file.name,
            rows_loaded=row[2] if row else 0,
            rows_failed=row[4] if row else 0,
        )

        # 4. Optional: remove the staged file to save storage
        cur.execute(f"REMOVE {stage_name}/{local_file.name}.gz")

        logger.info(
            "Load complete: %s rows loaded, %s rows failed",
            result.rows_loaded,
            result.rows_failed,
        )
        return result


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    load_dotenv()

    # Example invocation — edit for your data
    result = stage_and_copy(
        local_file=Path("data/sample.csv"),
        stage_name="@MY_DB.MY_SCHEMA.MY_STAGE",
        target_table="MY_DB.MY_SCHEMA.MY_TABLE",
    )
    print(result)
