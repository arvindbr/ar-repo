"""ETL pipelines and data loading utilities."""
