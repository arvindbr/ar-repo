"""Example: customer revenue analysis using Snowpark DataFrames.

Demonstrates Snowpark's DataFrame API as an alternative to writing raw SQL.
Snowpark pushes the computation down to Snowflake — your Python code
generates SQL under the hood.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from dotenv import load_dotenv
from snowflake.snowpark.functions import avg, col, count, sum as sum_

from python.connectors.snowpark_session import snowpark_session

logger = logging.getLogger(__name__)


def top_customers_by_revenue(limit: int = 10) -> None:
    """Print the top N customers by total order revenue."""
    with snowpark_session() as session:
        orders = session.table("APP_DB.ANALYTICS.FCT_ORDERS")
        customers = session.table("APP_DB.ANALYTICS.DIM_CUSTOMERS").filter(
            col("IS_CURRENT") == True  # noqa: E712 — Snowpark requires ==
        )

        result = (
            orders
            .filter(col("ORDER_STATUS") == "DELIVERED")
            .join(customers, on="CUSTOMER_ID", how="inner")
            .group_by("CUSTOMER_ID", "FIRST_NAME", "LAST_NAME", "EMAIL")
            .agg(
                count("*").alias("ORDER_COUNT"),
                sum_("TOTAL_AMOUNT").alias("LIFETIME_VALUE"),
                avg("TOTAL_AMOUNT").alias("AVG_ORDER_VALUE"),
            )
            .order_by(col("LIFETIME_VALUE").desc())
            .limit(limit)
        )

        # Snowpark lazily builds the query — show() executes it
        result.show()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    load_dotenv()
    top_customers_by_revenue(limit=10)
