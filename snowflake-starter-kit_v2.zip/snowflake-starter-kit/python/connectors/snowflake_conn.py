"""Snowflake connection helpers.

Provides context managers for creating Snowflake connections using
environment variables. Supports password, key-pair, and SSO authentication.

Usage:
    from python.connectors.snowflake_conn import snowflake_connection

    with snowflake_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT CURRENT_VERSION()")
            print(cursor.fetchone())
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator, Optional

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from snowflake.connector import SnowflakeConnection, connect

logger = logging.getLogger(__name__)


class SnowflakeConfigError(Exception):
    """Raised when required Snowflake configuration is missing."""


def _required_env(key: str) -> str:
    """Return an env var value or raise a clear error if missing."""
    value = os.environ.get(key)
    if not value:
        raise SnowflakeConfigError(
            f"Required environment variable '{key}' is not set. "
            f"Check your .env file or environment."
        )
    return value


def _load_private_key(
    key_path: str, passphrase: Optional[str] = None
) -> bytes:
    """Load a PEM-encoded private key for key-pair authentication.

    Args:
        key_path: Filesystem path to the private key file.
        passphrase: Optional passphrase if the key is encrypted.

    Returns:
        DER-encoded private key bytes ready for the Snowflake connector.
    """
    key_file = Path(key_path).expanduser()
    if not key_file.exists():
        raise SnowflakeConfigError(f"Private key file not found: {key_file}")

    with key_file.open("rb") as f:
        p_key = serialization.load_pem_private_key(
            f.read(),
            password=passphrase.encode() if passphrase else None,
            backend=default_backend(),
        )

    return p_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def get_connection_params() -> dict[str, Any]:
    """Build Snowflake connection parameters from environment variables.

    Authentication priority:
        1. Key-pair (SNOWFLAKE_PRIVATE_KEY_PATH set)
        2. External browser SSO (SNOWFLAKE_AUTHENTICATOR=externalbrowser)
        3. Password (SNOWFLAKE_PASSWORD set)

    Returns:
        Dict of parameters ready to pass to snowflake.connector.connect().
    """
    params: dict[str, Any] = {
        "account": _required_env("SNOWFLAKE_ACCOUNT"),
        "user": _required_env("SNOWFLAKE_USER"),
        "warehouse": os.environ.get("SNOWFLAKE_WAREHOUSE"),
        "database": os.environ.get("SNOWFLAKE_DATABASE"),
        "schema": os.environ.get("SNOWFLAKE_SCHEMA"),
        "role": os.environ.get("SNOWFLAKE_ROLE"),
        "client_session_keep_alive": False,
    }

    # Pick auth method
    private_key_path = os.environ.get("SNOWFLAKE_PRIVATE_KEY_PATH")
    authenticator = os.environ.get("SNOWFLAKE_AUTHENTICATOR")
    password = os.environ.get("SNOWFLAKE_PASSWORD")

    if private_key_path:
        logger.info("Using key-pair authentication")
        passphrase = os.environ.get("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE")
        params["private_key"] = _load_private_key(private_key_path, passphrase)
    elif authenticator:
        logger.info("Using authenticator: %s", authenticator)
        params["authenticator"] = authenticator
        if password:
            params["password"] = password
    elif password:
        logger.info("Using password authentication (not recommended for production)")
        params["password"] = password
    else:
        raise SnowflakeConfigError(
            "No authentication method configured. Set one of: "
            "SNOWFLAKE_PRIVATE_KEY_PATH, SNOWFLAKE_AUTHENTICATOR, or SNOWFLAKE_PASSWORD."
        )

    # Optional safety net for cost control
    timeout = os.environ.get("SNOWFLAKE_STATEMENT_TIMEOUT_SECONDS")
    if timeout:
        params["session_parameters"] = {
            "STATEMENT_TIMEOUT_IN_SECONDS": int(timeout),
        }

    # Strip None values — connector dislikes them
    return {k: v for k, v in params.items() if v is not None}


@contextmanager
def snowflake_connection() -> Generator[SnowflakeConnection, None, None]:
    """Yield a Snowflake connection that closes automatically.

    Yields:
        An open SnowflakeConnection.

    Example:
        with snowflake_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT CURRENT_USER()")
                print(cur.fetchone())
    """
    params = get_connection_params()
    conn = connect(**params)
    try:
        logger.info(
            "Connected to Snowflake account=%s user=%s role=%s warehouse=%s",
            params.get("account"),
            params.get("user"),
            params.get("role"),
            params.get("warehouse"),
        )
        yield conn
    finally:
        conn.close()
        logger.info("Snowflake connection closed")
