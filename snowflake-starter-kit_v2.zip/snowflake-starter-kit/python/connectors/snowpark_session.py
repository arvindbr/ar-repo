"""Snowpark session helpers.

Snowpark provides a DataFrame API for Snowflake similar to PySpark.
Use this for complex transformations that benefit from Python-native syntax.

Usage:
    from python.connectors.snowpark_session import snowpark_session

    with snowpark_session() as session:
        df = session.table("CUSTOMERS").filter("STATE = 'CA'")
        df.show()
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Generator

from snowflake.snowpark import Session

from python.connectors.snowflake_conn import get_connection_params

logger = logging.getLogger(__name__)


@contextmanager
def snowpark_session() -> Generator[Session, None, None]:
    """Yield a Snowpark Session that closes automatically.

    Snowpark uses the same connection parameters as the Python connector,
    so this builds on get_connection_params() to stay DRY.

    Yields:
        An open Snowpark Session.
    """
    params = get_connection_params()
    session = Session.builder.configs(params).create()
    try:
        logger.info("Snowpark session created")
        yield session
    finally:
        session.close()
        logger.info("Snowpark session closed")
