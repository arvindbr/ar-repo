"""Quick smoke test for Snowflake connectivity.

Run this after setting up your .env file to verify everything works.

Usage:
    python python/connectors/test_connection.py
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

# Allow running this file directly without installing the package
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from dotenv import load_dotenv

from python.connectors.snowflake_conn import snowflake_connection

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def main() -> int:
    """Connect to Snowflake and print session details."""
    load_dotenv()

    print("\n🔍 Testing Snowflake connection...\n")

    try:
        with snowflake_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        CURRENT_VERSION()  AS version,
                        CURRENT_ACCOUNT()  AS account,
                        CURRENT_USER()     AS user,
                        CURRENT_ROLE()     AS role,
                        CURRENT_WAREHOUSE() AS warehouse,
                        CURRENT_DATABASE() AS database,
                        CURRENT_SCHEMA()   AS schema,
                        CURRENT_REGION()   AS region
                    """
                )
                row = cur.fetchone()
                columns = [c[0] for c in cur.description]

        print("✅ Connection successful!\n")
        print("Session details:")
        print("-" * 50)
        for col, val in zip(columns, row):
            print(f"  {col:12} : {val}")
        print("-" * 50)
        return 0

    except Exception as exc:
        print(f"\n❌ Connection failed: {exc}\n")
        logger.exception("Connection error details:")
        return 1


if __name__ == "__main__":
    sys.exit(main())
