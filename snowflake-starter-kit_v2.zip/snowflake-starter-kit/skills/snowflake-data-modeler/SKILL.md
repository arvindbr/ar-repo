---
name: snowflake-data-modeler
description: Use this skill for designing schemas, dimensional models, data vaults, SCD strategies, choosing between fact and dimension grain, or deciding between table types (permanent, transient, temporary, dynamic). Triggers include "model this", "schema design", "dimensional model", "star schema", "SCD type", "grain", or any question about how to structure data in Snowflake.
version: 1.0.0
---

# Snowflake Data Modeler Skill

## Choosing a modeling approach

| Approach              | When to use                                                  |
|-----------------------|--------------------------------------------------------------|
| **Star schema**       | Default. BI use cases, analyst friendliness, predictable joins |
| **Snowflake schema**  | When dimensions are themselves complex hierarchies             |
| **Data Vault 2.0**    | Enterprise integration, source-of-truth across many systems    |
| **One Big Table (OBT)** | Heavy aggregation workloads, ML feature stores               |
| **Activity schema**   | Behavioral analytics, customer journey                        |

Default to star schema unless there's a clear reason to deviate.

## Layered architecture

```
RAW         → exact copy of source, append-only
STAGING     → cleansed, typed, deduplicated; one row per source record
ANALYTICS   → conformed dimensions and facts (the model)
MARTS       → use-case specific subsets (finance, marketing, etc.)
```

Don't skip layers. Don't let BI tools query RAW or STAGING.

## Choosing grain (the most important decision)

Before writing any DDL, answer:
1. What does **one row** of this fact represent?
2. What is the **time grain** — event, day, month?
3. What are the **dimensional keys**?
4. What **measures** are additive, semi-additive, non-additive?

Bad grain choices cause every downstream problem. Spend time here.

### Examples
| Fact                | Grain                                   |
|---------------------|-----------------------------------------|
| `fct_orders`        | One row per order header                |
| `fct_order_items`   | One row per line item per order         |
| `fct_page_views`    | One row per page view event             |
| `fct_daily_revenue` | One row per (date, product, channel)    |

## Slowly Changing Dimension (SCD) decision tree

| Need to track history? | Strategy   | Snowflake feature                    |
|------------------------|------------|--------------------------------------|
| No, current value only | SCD Type 1 | Plain `MERGE` overwrites              |
| Yes, full history      | SCD Type 2 | Versioned rows + valid_from/valid_to  |
| Some columns history   | SCD Type 3 | Add `previous_value` column           |
| Audit log style        | SCD Type 4 | Separate history table                |
| Hybrid                 | SCD Type 6 | Combination of 1, 2, 3                |

For most cases, default to **Type 2** for analytics dimensions and **Type 1** for staging.

## Type 2 SCD pattern

```sql
CREATE OR REPLACE TABLE dim_customers (
    customer_sk     NUMBER(38,0) NOT NULL,    -- surrogate, version-specific
    customer_id     NUMBER(38,0) NOT NULL,    -- business key, stable
    -- attributes...
    valid_from      TIMESTAMP_NTZ NOT NULL,
    valid_to        TIMESTAMP_NTZ,            -- NULL = current
    is_current      BOOLEAN NOT NULL,
    record_hash     VARCHAR(64) NOT NULL,     -- for change detection
    CONSTRAINT pk_dim_customers PRIMARY KEY (customer_sk)
)
CLUSTER BY (customer_id, valid_from);

-- Indexes (logical, not physical) on:
-- (customer_id, is_current) for current-state queries
-- (customer_id, valid_from, valid_to) for point-in-time queries
```

Joining a fact to a Type 2 dimension:
```sql
SELECT *
FROM fct_orders o
JOIN dim_customers c
  ON o.customer_id = c.customer_id
 AND o.order_timestamp >= c.valid_from
 AND (o.order_timestamp < c.valid_to OR c.valid_to IS NULL);
```

## Snowflake-specific table types

| Type        | Time travel | Fail-safe | Use when                            |
|-------------|-------------|-----------|-------------------------------------|
| Permanent   | 0–90 days   | Yes (7d)  | Default for analytics tables        |
| Transient   | 0–1 day     | No        | Staging, easy to rebuild            |
| Temporary   | Session     | No        | Scratchpad in a single session      |
| External    | N/A         | N/A       | Querying S3/GCS/Azure files in place |
| Dynamic     | Per refresh | Yes       | Declarative incremental transforms  |
| Iceberg     | Per source  | Per source| Open-table-format data              |

## Dynamic tables (the modern alternative to streams + tasks)

Use when you'd otherwise write a stream + task pair.

```sql
CREATE OR REPLACE DYNAMIC TABLE dt_active_customers
    TARGET_LAG = '5 minutes'
    WAREHOUSE = app_wh_xs
    AS
SELECT
    customer_id,
    MAX(order_timestamp) AS last_order_at,
    COUNT(*)             AS lifetime_orders
FROM fct_orders
WHERE order_status = 'DELIVERED'
GROUP BY customer_id;
```

Snowflake handles incremental refresh automatically. Limitations: fewer SQL constructs than regular materialized views; check docs before complex transforms.

## Surrogate keys

Use sequences, not the source's natural key:
```sql
CREATE SEQUENCE seq_dim_customers START 1 INCREMENT 1;

-- In INSERT:
INSERT INTO dim_customers (customer_sk, customer_id, ...)
SELECT seq_dim_customers.NEXTVAL, source.customer_id, ...
FROM source;
```

Why: source IDs can collide across systems, change types, or be reused.

## Naming the model

Reinforce the layer in the name:
- `stg_<source>_<entity>` — `stg_shopify_orders`
- `dim_<entity>` — `dim_customers`
- `fct_<process>` — `fct_orders`, `fct_payment_events`
- `agg_<grain>_<entity>` — `agg_daily_revenue`
- `bridge_<a>_<b>` — `bridge_customer_account`

## Modeling for change

Anticipate:
- New attributes added to a dimension → make schema additive (new columns are safe)
- Source system replaced → keep `source_system` and `source_record_id` columns
- Late-arriving data → idempotent merges, no destructive deletes
- Backfills → `loaded_by_run_id` column ties rows to ETL runs for selective replay

## Anti-patterns

- ❌ Reusing the source primary key as the warehouse PK without surrogate
- ❌ Storing JSON blobs as `VARCHAR` instead of `VARIANT`
- ❌ One mega-fact with 200 columns — split by grain
- ❌ Type 2 SCD without `is_current` boolean (forces analysts to write `valid_to IS NULL` everywhere)
- ❌ "Universal" dimensions like `dim_metadata` that hold unrelated attributes
- ❌ Dimensions without a `dim_unknown` row (causes outer joins everywhere)

## The unknown member pattern

Every dimension should have a "-1" row for unknown / not-yet-loaded values:
```sql
INSERT INTO dim_customers (customer_sk, customer_id, first_name, ...)
VALUES (-1, -1, '(unknown)', ...);
```
Facts then always inner-join cleanly.

## Cross-references

- Performance implications of clustering choices → `snowflake-performance-tuner`
- Securing dimensional models with PII → `snowflake-security-auditor`
- For the actual SQL syntax, → `snowflake-sql-author`
