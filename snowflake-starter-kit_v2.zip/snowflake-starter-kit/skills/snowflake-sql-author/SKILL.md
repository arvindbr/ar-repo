---
name: snowflake-sql-author
description: Use this skill whenever writing or editing Snowflake SQL — DDL, DML, queries, views, procedures, or UDFs. Triggers include any mention of CREATE TABLE, MERGE, COPY INTO, stored procedures, window functions, or general SQL tasks against a Snowflake target. Enforces project conventions for formatting, naming, data types, and idempotency.
version: 1.0.0
---

# Snowflake SQL Authoring Skill

## When to use

Activate this skill for any task that produces or edits Snowflake SQL. Do not use it for non-Snowflake dialects (Postgres, BigQuery, MySQL).

## Required output conventions

### Formatting
- UPPERCASE all SQL keywords (`SELECT`, `FROM`, `CREATE`, `WITH`, `QUALIFY`)
- snake_case identifiers; no quoted mixed-case names
- Two-space indent inside CTEs and subqueries
- Trailing semicolon on every statement
- Block comments at file head; inline `--` comments otherwise
- Maximum line length 120 characters

### File header (mandatory for every .sql file)
```sql
/*
 * File:        <filename>.sql
 * Purpose:     <one-line description>
 * Owner:       <team or person>
 * Dependencies: <upstream tables, schemas, or roles>
 * Last modified: <YYYY-MM-DD>
 */
```

### Naming
| Object         | Prefix     | Example                        |
|----------------|------------|--------------------------------|
| Staging table  | `stg_`     | `stg_customers`                |
| Dimension      | `dim_`     | `dim_customers`                |
| Fact           | `fct_`     | `fct_orders`                   |
| View           | `v_`       | `v_active_customers`           |
| Stored proc    | `sp_`      | `sp_refresh_dim_customers`     |
| UDF            | `udf_`     | `udf_format_phone`             |
| Sequence       | `seq_`     | `seq_dim_customers`            |
| Audit table    | `audit_`   | `audit_log`                    |

### Data types — pick from this list
- Integers → `NUMBER(38,0)`
- Decimals → `NUMBER(precision, scale)` (never `FLOAT` for money)
- Strings → `VARCHAR` (no length needed; storage is identical)
- Timestamps → `TIMESTAMP_NTZ` unless timezone matters, then `TIMESTAMP_TZ`
- Dates → `DATE`
- Booleans → `BOOLEAN` (never `NUMBER(1)`)
- Semi-structured → `VARIANT` for JSON, `ARRAY` for arrays, `OBJECT` for maps
- Binary → `BINARY`

### Idempotency
- DDL: prefer `CREATE OR REPLACE` in dev, `CREATE ... IF NOT EXISTS` in production migrations
- DML: write `MERGE` statements that produce identical state when re-run with the same input
- Use surrogate keys + business keys to support re-runs

### Audit columns (every analytics table)
```sql
created_at        TIMESTAMP_NTZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
updated_at        TIMESTAMP_NTZ NOT NULL DEFAULT CURRENT_TIMESTAMP(),
loaded_by_run_id  VARCHAR
```

## Patterns to use

### CTE-first style (always prefer over nested subqueries)
```sql
WITH filtered_orders AS (
    SELECT order_id, customer_id, total_amount
    FROM app_db.analytics.fct_orders
    WHERE order_date >= DATEADD(day, -30, CURRENT_DATE())
),
ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY total_amount DESC) AS rn
    FROM filtered_orders
)
SELECT *
FROM ranked
WHERE rn = 1;
```

### QUALIFY for window-function filtering
Replace this:
```sql
SELECT * FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY id ORDER BY ts DESC) AS rn FROM events
) WHERE rn = 1;
```
With:
```sql
SELECT *
FROM events
QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY ts DESC) = 1;
```

### MERGE with change detection
```sql
MERGE INTO target t
USING (
    SELECT *,
           HASH(col1, col2, col3) AS attr_hash
    FROM source
) s
ON t.business_key = s.business_key
WHEN MATCHED AND t.attr_hash <> s.attr_hash
    THEN UPDATE SET t.col1 = s.col1, t.col2 = s.col2, t.attr_hash = s.attr_hash, t.updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED
    THEN INSERT (business_key, col1, col2, attr_hash, created_at)
         VALUES (s.business_key, s.col1, s.col2, s.attr_hash, CURRENT_TIMESTAMP());
```

### Safe COPY INTO from stage
```sql
COPY INTO app_db.raw.events
FROM @app_db.util.s3_stage/events/
FILE_FORMAT = (FORMAT_NAME = 'app_db.util.json_format')
ON_ERROR = 'CONTINUE'
PURGE = FALSE
RETURN_FAILED_ONLY = FALSE;
```

## Anti-patterns to reject

- ❌ `SELECT *` in production queries, views, or materialized views
- ❌ `WHERE UPPER(col) = 'X'` — kills micro-partition pruning
- ❌ String concatenation of user input — always parameterize
- ❌ `BEGIN`/`COMMIT` blocks unless transactions are explicitly required
- ❌ `INFORMATION_SCHEMA` queries on accounts with thousands of objects (use `ACCOUNT_USAGE` views instead, accepting up to ~3 hour latency)
- ❌ `FLOAT` / `DOUBLE` for currency or counts
- ❌ Nested subqueries when a CTE would read clearly
- ❌ `CREATE TABLE` without comments

## Workflow when authoring

1. **Confirm intent** — what schema, what grain, what consumer pattern?
2. **Pick the right object type** — table vs view vs materialized view vs dynamic table
3. **Write the file header**
4. **Write the DDL/DML following conventions above**
5. **Add comments** on the object and on every column
6. **Suggest a smoke test** — a SELECT that validates the result
7. **Mention indexing/clustering** if the table is large enough to need it (>1 GB or >1M rows)

## Cross-references

- For performance issues, switch to `snowflake-performance-tuner` skill
- For permission/grant questions, switch to `snowflake-security-auditor` skill
- For schema design choices, switch to `snowflake-data-modeler` skill
