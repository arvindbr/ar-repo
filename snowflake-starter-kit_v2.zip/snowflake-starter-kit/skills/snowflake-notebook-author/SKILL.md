---
name: snowflake-notebook-author
description: Use this skill when authoring Jupyter or Snowflake notebooks for data exploration, analysis, or presentation. Triggers include "create a notebook", "explore this data", "analyze X", or any task that benefits from cell-by-cell narrative + code. Establishes structure, narrative flow, and reproducibility patterns.
version: 1.0.0
---

# Snowflake Notebook Authoring Skill

## When to use

- Ad-hoc data exploration that another person will read later
- Analyses that mix prose, SQL, charts, and conclusions
- Onboarding documents that walk through a dataset
- Presentation-quality reports built directly from Snowflake

## When NOT to use

- Production code → use `python/etl/` instead
- One-off queries → use a SQL file or Snowsight worksheet
- Anything that needs to be scheduled → notebooks are not pipelines

## Required structure

Every notebook should follow this seven-section template:

1. **Title and purpose** (markdown) — one-line goal, author, date, links to upstream context
2. **Setup** (code) — imports, connection, session config
3. **Data loading** (code + markdown) — what tables, what filters, why
4. **Validation** (code) — sanity checks: row counts, nulls, ranges
5. **Analysis** (alternating markdown + code) — the actual investigation
6. **Findings** (markdown) — bulleted conclusions, ideally with hyperlinks back to charts
7. **Next steps** (markdown) — what to do with this — productionize? share? ignore?

Skipping any of these is a smell.

## Setup cell template

```python
# Standard imports
import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd().parent))

import pandas as pd
import numpy as np

# Project helpers
from dotenv import load_dotenv
load_dotenv(Path.cwd().parent / '.env')

from python.connectors.snowflake_conn import snowflake_connection
from python.utils.query_helpers import run_query

# Display settings
pd.set_option('display.max_columns', 50)
pd.set_option('display.float_format', '{:,.2f}'.format)

# Optional: matplotlib / plotly defaults
%matplotlib inline
```

## Conventions

- **One question per cell.** Don't bundle unrelated SQL.
- **Comment the SQL.** A future reader needs to know why a filter exists.
- **Cache expensive cells.** Use `pd.read_pickle` / `pd.to_pickle` to avoid re-running 10-minute queries.
- **Surface assumptions.** "Excluding test orders (customer_id < 1000)" should be a markdown sentence, not a buried `WHERE` clause.
- **Use raw SQL via `run_query()`** rather than building DataFrames imperatively when the result fits in memory.
- **No credentials in cells.** Load from `.env` only.

## Anti-patterns

- ❌ A 50-line SQL string with no surrounding markdown
- ❌ `print()` for findings — use markdown cells
- ❌ Hardcoded `LIMIT 1000` left in by accident
- ❌ Charts without titles or axis labels
- ❌ Notebooks that don't run top-to-bottom (state pollution)

## Productionization checklist

When a notebook turns out to be valuable, before running it on a schedule:

1. Move the code into `python/etl/` modules with proper functions
2. Replace pandas with Snowpark DataFrames (or pure SQL) where data is large
3. Add tests
4. Add to Airflow / scheduler
5. Keep the original notebook as documentation

## Cross-references

- `snowflake-sql-author` for SQL conventions inside cells
- `snowflake-performance-tuner` if a cell takes more than a minute
