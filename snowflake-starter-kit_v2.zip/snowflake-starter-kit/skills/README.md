# Skills

Domain-expert knowledge packs that AI assistants load on-demand to specialize their behavior. Each skill is self-contained and uses a frontmatter block so assistants can route to the right one based on the task.

## How skills work

1. The assistant reads the `description` field in each skill's frontmatter
2. When a user request matches a skill's domain, the assistant loads that skill's full SKILL.md
3. The skill's content takes precedence over generic conventions for that domain

## Available skills

| Skill                              | Triggers on                                       |
|------------------------------------|---------------------------------------------------|
| [snowflake-sql-author](./snowflake-sql-author/SKILL.md)             | Any SQL authoring or editing task                 |
| [snowflake-performance-tuner](./snowflake-performance-tuner/SKILL.md) | Slow queries, optimization, clustering            |
| [snowflake-security-auditor](./snowflake-security-auditor/SKILL.md)  | RBAC, grants, PII, masking, network policies      |
| [snowflake-cost-optimizer](./snowflake-cost-optimizer/SKILL.md)      | Credit usage, FinOps, warehouse sizing            |
| [snowflake-data-modeler](./snowflake-data-modeler/SKILL.md)          | Schema design, SCD, dimensional modeling          |
| [snowflake-notebook-author](./snowflake-notebook-author/SKILL.md)    | Jupyter notebooks for exploration and analysis    |

## Adding a new skill

1. Create `skills/<your-skill-name>/SKILL.md`
2. Start with a frontmatter block:
   ```yaml
   ---
   name: your-skill-name
   description: When to use this skill — specific triggers, not generic
   version: 1.0.0
   ---
   ```
3. Write the skill content as plain markdown, organized by:
   - When to use (and when not to)
   - Required outputs / patterns
   - Anti-patterns to reject
   - Cross-references to other skills
4. Reference the skill from `CLAUDE.md` and `.github/copilot-instructions.md`

## Skill design tips

- **Be specific in the description.** "Use for database stuff" is bad. "Use when authoring SQL DDL with Snowflake-specific data types" is good.
- **Lead with what to do.** Examples > rules.
- **Cross-reference related skills.** Skills compose well when they hand off cleanly.
- **Keep skills under ~500 lines.** Longer means it's two skills.
