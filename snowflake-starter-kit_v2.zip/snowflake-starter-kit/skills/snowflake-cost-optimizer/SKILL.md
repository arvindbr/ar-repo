---
name: snowflake-cost-optimizer
description: Use this skill for Snowflake cost analysis, FinOps, credit consumption review, warehouse right-sizing, storage optimization, or building cost dashboards. Triggers include "credits", "cost", "billing", "FinOps", "warehouse usage", "storage spend", "resource monitor", or any review of "where is the money going".
version: 1.0.0
---

# Snowflake Cost Optimizer Skill

## Cost components

Snowflake bills in three streams:
1. **Compute** — credits consumed by warehouses, serverless tasks, search optimization, etc.
2. **Storage** — flat per-TB rate for tables, fail-safe, time-travel
3. **Cloud services** — usually free up to 10% of compute; charged above that

Compute dominates total cost for most workloads. Start there.

## Diagnostic queries

### Top warehouses by credit burn (last 30 days)
```sql
SELECT
    warehouse_name,
    SUM(credits_used)              AS total_credits,
    SUM(credits_used_compute)      AS compute_credits,
    SUM(credits_used_cloud_services) AS cloud_services_credits,
    COUNT(DISTINCT DATE(start_time)) AS active_days
FROM snowflake.account_usage.warehouse_metering_history
WHERE start_time >= DATEADD(day, -30, CURRENT_TIMESTAMP())
GROUP BY warehouse_name
ORDER BY total_credits DESC;
```

### Top queries by credit cost
```sql
SELECT
    query_id,
    user_name,
    warehouse_name,
    warehouse_size,
    total_elapsed_time / 1000      AS elapsed_seconds,
    bytes_scanned / POWER(1024,3)  AS gb_scanned,
    credits_used_cloud_services,
    LEFT(query_text, 100)          AS preview
FROM snowflake.account_usage.query_history
WHERE start_time >= DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND total_elapsed_time > 60000
ORDER BY total_elapsed_time DESC
LIMIT 50;
```

### Idle warehouse detection
```sql
WITH wh_activity AS (
    SELECT
        warehouse_name,
        SUM(credits_used) AS credits,
        COUNT(*) AS sessions
    FROM snowflake.account_usage.warehouse_metering_history
    WHERE start_time >= DATEADD(day, -30, CURRENT_TIMESTAMP())
    GROUP BY warehouse_name
),
wh_queries AS (
    SELECT warehouse_name, COUNT(*) AS query_count
    FROM snowflake.account_usage.query_history
    WHERE start_time >= DATEADD(day, -30, CURRENT_TIMESTAMP())
    GROUP BY warehouse_name
)
SELECT a.warehouse_name, a.credits, a.sessions, COALESCE(q.query_count, 0) AS queries
FROM wh_activity a
LEFT JOIN wh_queries q USING (warehouse_name)
ORDER BY credits DESC;
```

### Storage hogs
```sql
SELECT
    table_catalog || '.' || table_schema || '.' || table_name AS full_name,
    active_bytes / POWER(1024,3)    AS active_gb,
    time_travel_bytes / POWER(1024,3) AS time_travel_gb,
    failsafe_bytes / POWER(1024,3)  AS failsafe_gb,
    retained_for_clone_bytes / POWER(1024,3) AS clone_gb
FROM snowflake.account_usage.table_storage_metrics
WHERE deleted = FALSE
ORDER BY active_bytes DESC
LIMIT 25;
```

## Levers (in order of impact)

### 1. Fix `AUTO_SUSPEND` (biggest win, easiest fix)
```sql
-- Audit
SELECT name, auto_suspend FROM (SHOW WAREHOUSES);

-- Fix anything > 60s for non-BI workloads
ALTER WAREHOUSE my_wh SET AUTO_SUSPEND = 60;
```

### 2. Right-size warehouses
A common mistake: oversized warehouses for predictable workloads.
- ETL: pick the smallest size that finishes within the SLA window
- BI: smaller + multi-cluster scaling > bigger single cluster
- Ad-hoc: XS or S almost always

Test by halving the size and measuring elapsed time. If elapsed time roughly doubles, you were correctly sized. If it stays flat, you can stay smaller.

### 3. Suspend or drop unused warehouses
The query above identifies them. After confirming with owners, drop or set very aggressive auto-suspend.

### 4. Set resource monitors
Hard caps protect against runaway costs.
```sql
CREATE RESOURCE MONITOR rm_etl_monthly
    WITH CREDIT_QUOTA = 5000
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    TRIGGERS
        ON 75 PERCENT DO NOTIFY
        ON 90 PERCENT DO SUSPEND
        ON 100 PERCENT DO SUSPEND_IMMEDIATE;

ALTER WAREHOUSE app_wh_load SET RESOURCE_MONITOR = rm_etl_monthly;
```

### 5. Reduce query work
Each of these is a `snowflake-performance-tuner` problem; switch skills:
- Add clustering keys where pruning is failing
- Replace correlated subqueries with window functions
- Materialize expensive aggregations

### 6. Manage time-travel and fail-safe storage
```sql
-- Default is 1 day; check anything higher
SELECT name, retention_time
FROM (SHOW TABLES IN DATABASE app_db)
WHERE retention_time > 1;

-- Reduce non-critical tables
ALTER TABLE app_db.staging.stg_huge_log SET DATA_RETENTION_TIME_IN_DAYS = 0;
```
Note: setting to 0 also eliminates fail-safe for that table. Make sure that's intended.

### 7. Drop transient/temp tables you forgot
Transient tables don't get fail-safe but still accrue storage.
```sql
SELECT table_schema, table_name, bytes / POWER(1024,3) AS gb, last_altered
FROM information_schema.tables
WHERE table_type = 'TRANSIENT TABLE'
  AND last_altered < DATEADD(day, -30, CURRENT_DATE());
```

### 8. Watch cloud-services overage
Cloud services are free up to 10% of daily compute. Going over costs real money. Heavy `INFORMATION_SCHEMA` queries, lots of small queries, and metadata-heavy operations push this up.
```sql
SELECT
    DATE(start_time) AS day,
    SUM(credits_used_compute)        AS compute,
    SUM(credits_used_cloud_services) AS cloud,
    100.0 * SUM(credits_used_cloud_services) / NULLIF(SUM(credits_used_compute), 0) AS pct
FROM snowflake.account_usage.warehouse_metering_history
WHERE start_time >= DATEADD(day, -30, CURRENT_TIMESTAMP())
GROUP BY day
HAVING pct > 10
ORDER BY day DESC;
```

## Reporting templates

### Weekly cost summary (paste into Slack / email)
Run all four diagnostic queries above. Format:
- Total credits used: X (vs Y last week, ±Z%)
- Top 3 warehouses by spend
- Top 3 expensive queries
- Storage growth this week
- Anomalies / things to investigate

### Anomaly detection
```sql
WITH daily_credits AS (
    SELECT
        DATE(start_time) AS day,
        warehouse_name,
        SUM(credits_used) AS credits
    FROM snowflake.account_usage.warehouse_metering_history
    WHERE start_time >= DATEADD(day, -90, CURRENT_TIMESTAMP())
    GROUP BY day, warehouse_name
),
stats AS (
    SELECT
        warehouse_name,
        AVG(credits) AS avg_credits,
        STDDEV(credits) AS std_credits
    FROM daily_credits
    WHERE day < DATEADD(day, -1, CURRENT_DATE())
    GROUP BY warehouse_name
)
SELECT d.day, d.warehouse_name, d.credits, s.avg_credits,
       (d.credits - s.avg_credits) / NULLIF(s.std_credits, 0) AS z_score
FROM daily_credits d
JOIN stats s USING (warehouse_name)
WHERE d.day = DATEADD(day, -1, CURRENT_DATE())
  AND ABS((d.credits - s.avg_credits) / NULLIF(s.std_credits, 0)) > 2
ORDER BY ABS(z_score) DESC;
```

## Cross-references

- For making queries actually faster (not just cheaper), `snowflake-performance-tuner`
- For audit log access patterns, `snowflake-security-auditor`
