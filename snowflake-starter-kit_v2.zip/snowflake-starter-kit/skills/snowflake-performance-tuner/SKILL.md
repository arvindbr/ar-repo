---
name: snowflake-performance-tuner
description: Use this skill when investigating slow Snowflake queries, optimizing existing SQL, designing clustering keys, choosing warehouse sizes, or debugging poor pruning. Triggers include phrases like "this query is slow", "optimize", "QUERY_PROFILE", "warehouse sizing", "clustering", or any task that involves making Snowflake go faster or use less compute.
version: 1.0.0
---

# Snowflake Performance Tuning Skill

## Diagnostic playbook

When given a slow query, walk through these in order. Stop at the first root cause that explains the symptom.

### 1. Inspect the query profile
Always start here. Do not guess.
```sql
-- Find the query ID
SELECT query_id, total_elapsed_time, bytes_scanned, partitions_scanned, partitions_total
FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY())
WHERE query_text ILIKE '%<distinctive snippet>%'
ORDER BY start_time DESC
LIMIT 10;
```
Then open the query profile in Snowsight. Look for the **most expensive operator** — that's where to focus.

### 2. Check pruning effectiveness
The single most common cause of slow Snowflake queries.
```sql
SELECT
    partitions_scanned,
    partitions_total,
    ROUND(100.0 * partitions_scanned / NULLIF(partitions_total, 0), 1) AS pct_scanned
FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY_BY_USER(USER_NAME => CURRENT_USER()))
WHERE query_id = '<id>';
```
- `pct_scanned > 50%` on a large table → pruning is failing
- Common causes: function on the filter column, type mismatch, `OR` predicates, missing clustering

### 3. Look for spilling
Spilling to local or remote storage means the warehouse is undersized for the workload.
- Local spillage: tolerable if small
- Remote spillage: red flag — either size up or rewrite the query

### 4. Check join cardinality
Exploding joins (Cartesian or near-Cartesian) show up as a single operator consuming most of the time. Fix the join keys, don't size up.

## Common optimizations

### Enable pruning on date columns
**Bad:**
```sql
WHERE TO_CHAR(order_timestamp, 'YYYY-MM') = '2026-01'
```
**Good:**
```sql
WHERE order_timestamp >= '2026-01-01'
  AND order_timestamp <  '2026-02-01'
```

### Replace correlated subquery with window function
**Bad:**
```sql
SELECT o.*,
       (SELECT MAX(order_date) FROM orders o2 WHERE o2.customer_id = o.customer_id) AS last_order
FROM orders o;
```
**Good:**
```sql
SELECT o.*,
       MAX(order_date) OVER (PARTITION BY customer_id) AS last_order
FROM orders o;
```

### Use QUALIFY instead of subquery
**Bad:**
```sql
SELECT * FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date DESC) AS rn
    FROM orders
) WHERE rn = 1;
```
**Good:**
```sql
SELECT *
FROM orders
QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date DESC) = 1;
```

## Clustering keys

### When to add clustering
- Table is large (>1 TB)
- Queries consistently filter or join on the same columns
- Auto-clustering credit cost is justified by query speedup

### When NOT to cluster
- Small tables (<1 GB) — the natural micro-partition layout is fine
- High-churn tables — re-clustering costs may exceed benefit
- Tables filtered on many different columns — pick max 3-4 cluster keys

### Choosing keys
```sql
-- Order matters: most-selective filter first
ALTER TABLE fct_orders CLUSTER BY (order_date, customer_id);

-- Check effectiveness
SELECT SYSTEM$CLUSTERING_INFORMATION('fct_orders', '(order_date, customer_id)');
```
Look at `average_overlaps` and `average_depth` — lower is better.

## Warehouse sizing rules of thumb

| Workload                        | Starting size | Notes                                        |
|---------------------------------|---------------|----------------------------------------------|
| Interactive BI dashboards       | XS or S       | Multi-cluster scaling for concurrency        |
| Daily ETL loads                 | S or M        | Size up only if jobs miss SLA                |
| Heavy aggregations / ML feature | L or XL       | Watch for remote spillage as the size signal |
| Ad-hoc analyst queries          | S             | With auto-suspend = 60s                      |

Doubling warehouse size doubles cost per second but typically halves runtime — so cost per query is similar. Size up only if elapsed time matters or if you see spillage.

## Materialized views vs dynamic tables

| Need                                  | Use                  |
|---------------------------------------|----------------------|
| Single-table aggregation, fast read   | Materialized view    |
| Multi-table transformation            | Dynamic table        |
| Streaming ingest pattern              | Stream + Task        |
| One-time transform                    | CTAS                 |

Materialized views have restrictions (no joins, no window functions, no aggregations on aggregations). Hit the docs before recommending.

## Result cache awareness

Identical queries hit the result cache for free if:
- Same exact text (whitespace-sensitive)
- Underlying data hasn't changed
- 24-hour reuse window
- Caller has the same role

To benefit, parameterize at the application layer instead of inlining values.

## Cost vs. performance tradeoffs

Always state the tradeoff explicitly when recommending changes. Examples:
- "Adding `CLUSTER BY (order_date)` will speed up date-range queries but costs ~X credits/month for auto-clustering on this table."
- "Sizing up from S to M halves query time but doubles per-second credit burn."
- "A materialized view eliminates the 30-second aggregation but adds storage and refresh costs."

## Cross-references

- For schema design that prevents future tuning needs, switch to `snowflake-data-modeler`
- For cost monitoring beyond a single query, switch to `snowflake-cost-optimizer`
