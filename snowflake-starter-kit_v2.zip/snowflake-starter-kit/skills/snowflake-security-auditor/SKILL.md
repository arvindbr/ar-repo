---
name: snowflake-security-auditor
description: Use this skill for any task involving Snowflake security — RBAC design, role grants, network policies, key-pair authentication, masking policies, row access policies, secure views, secrets handling, or audit log review. Triggers include "permissions", "grant", "role", "PII", "masking", "encryption", "service account", "OAuth", or any review of who can access what.
version: 1.0.0
---

# Snowflake Security Auditor Skill

## Core principles

1. **Least privilege, always.** Default deny; grant only what's needed.
2. **Functional roles, not user roles.** Grant privileges to roles, not users.
3. **Layered roles.** Build a hierarchy: SYSADMIN > APP_ADMIN > APP_DEVELOPER.
4. **Service accounts use key-pair auth.** Never passwords.
5. **PII is masked at the column level.** Apply masking policies, don't rely on view-level filters alone.
6. **Audit everything.** Use `ACCOUNT_USAGE` views to verify access patterns.

## RBAC design pattern

```
ACCOUNTADMIN
    └── SECURITYADMIN
        └── USERADMIN (manages users and roles)
    └── SYSADMIN
        └── APP_ADMIN
            ├── APP_DEVELOPER (read/write dev schemas)
            ├── APP_LOADER    (insert into raw/staging)
            └── APP_ANALYST   (read-only analytics)
```

Users are granted functional roles. Roles are granted privileges. This is the only sane way to scale.

### Role hierarchy in code
```sql
USE ROLE SECURITYADMIN;
GRANT ROLE APP_DEVELOPER TO ROLE APP_ADMIN;
GRANT ROLE APP_LOADER    TO ROLE APP_ADMIN;
GRANT ROLE APP_ANALYST   TO ROLE APP_ADMIN;
GRANT ROLE APP_ADMIN     TO ROLE SYSADMIN;
```

## Authentication methods (in order of preference)

### 1. Key-pair authentication (service accounts)
```sql
-- Register the public key
ALTER USER svc_loader SET RSA_PUBLIC_KEY='MIIBIjANBgkqhkiG9w0BAQEFAA...';

-- Optional: register a second key for rotation
ALTER USER svc_loader SET RSA_PUBLIC_KEY_2='MIIBIjANBgkqhkiG9w0BAQEFAA...';
```
Rotate keys quarterly. Never store private keys in source control.

### 2. SSO via SAML / external IdP (human users)
Set the user's authenticator to `externalbrowser` or use the IdP-issued OAuth token. Usernames must match the IdP's email or NameID.

### 3. OAuth (applications)
For apps that act on behalf of users. Configure a security integration:
```sql
CREATE SECURITY INTEGRATION my_oauth_app
    TYPE = OAUTH
    OAUTH_CLIENT = CUSTOM
    OAUTH_CLIENT_TYPE = 'CONFIDENTIAL'
    OAUTH_REDIRECT_URI = 'https://myapp.example.com/callback'
    ENABLED = TRUE;
```

### 4. Password (last resort)
Allowed only for personal sandboxes. Enforce MFA:
```sql
ALTER USER my_user SET MINS_TO_BYPASS_MFA = 0;
ALTER ACCOUNT SET ALLOW_CLIENT_MFA_CACHING = TRUE;
```

## PII protection

### Dynamic data masking
Apply once, enforce everywhere the column is queried.
```sql
CREATE OR REPLACE MASKING POLICY mask_email AS (val VARCHAR) RETURNS VARCHAR ->
    CASE
        WHEN CURRENT_ROLE() IN ('APP_ADMIN', 'PII_READER') THEN val
        ELSE REGEXP_REPLACE(val, '.+\\@', '*****@')
    END;

ALTER TABLE dim_customers
    MODIFY COLUMN email SET MASKING POLICY mask_email;
```

### Row access policies
For multi-tenant data:
```sql
CREATE OR REPLACE ROW ACCESS POLICY tenant_isolation AS (tenant_id NUMBER) RETURNS BOOLEAN ->
    EXISTS (
        SELECT 1
        FROM auth.user_tenant_map
        WHERE user_name = CURRENT_USER()
          AND user_tenant_map.tenant_id = tenant_id
    );

ALTER TABLE fct_orders ADD ROW ACCESS POLICY tenant_isolation ON (tenant_id);
```

### Tag-based classification
```sql
CREATE TAG pii_classification ALLOWED_VALUES 'pii', 'pci', 'phi', 'public';
ALTER TABLE dim_customers MODIFY COLUMN email SET TAG pii_classification = 'pii';

-- Then apply masking by tag
ALTER TAG pii_classification SET MASKING POLICY mask_pii_default;
```

## Network policies

Lock down account access by IP range.
```sql
CREATE NETWORK POLICY corp_only
    ALLOWED_IP_LIST = ('203.0.113.0/24', '198.51.100.0/24')
    BLOCKED_IP_LIST = ()
    COMMENT = 'Corporate network ranges';

ALTER ACCOUNT SET NETWORK_POLICY = corp_only;

-- Or per-user (overrides account-level)
ALTER USER svc_loader SET NETWORK_POLICY = ci_runners_only;
```

## Audit and monitoring

### Who has access to what
```sql
-- All grants on a table
SELECT grantee_name, privilege, granted_by
FROM snowflake.account_usage.grants_to_roles
WHERE table_name = 'DIM_CUSTOMERS'
  AND deleted_on IS NULL;

-- All roles a user has
SELECT *
FROM snowflake.account_usage.grants_to_users
WHERE grantee_name = 'MY_USER'
  AND deleted_on IS NULL;
```

### Login history
```sql
SELECT user_name, client_ip, reported_client_type, is_success, error_message
FROM snowflake.account_usage.login_history
WHERE event_timestamp >= DATEADD(day, -7, CURRENT_TIMESTAMP())
  AND is_success = 'NO'
ORDER BY event_timestamp DESC;
```

### Sensitive data access
```sql
SELECT user_name, query_text, start_time
FROM snowflake.account_usage.access_history
WHERE ARRAY_TO_STRING(direct_objects_accessed, ',') ILIKE '%DIM_CUSTOMERS%'
  AND start_time >= DATEADD(day, -1, CURRENT_TIMESTAMP());
```

## Common findings during audits

- Users with `ACCOUNTADMIN` doing daily work → revoke, give them `SYSADMIN` instead
- Service accounts with passwords → migrate to key-pair
- Tables with PII columns and no masking policy → apply masking
- Roles granted directly to users without going through functional roles → restructure
- Stale users (`LAST_SUCCESS_LOGIN > 90 days ago`) → disable
- Network policy missing on the account → add one
- `PUBLIC` role with usage on production schemas → revoke

## Things to refuse / escalate

- Granting `OWNERSHIP` of objects to anyone other than `SYSADMIN` or its descendants
- Disabling MFA for human users
- Storing passwords or keys in code
- Adding new admins without an approved change request
- Bypassing masking policies for "just this one query"

## Cross-references

- Cost implications of audit log retention → `snowflake-cost-optimizer`
- Schema design with security in mind → `snowflake-data-modeler`
