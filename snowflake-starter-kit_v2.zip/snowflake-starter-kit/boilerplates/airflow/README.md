# Airflow + Snowflake Boilerplate

DAGs and helpers for orchestrating Snowflake workloads with Apache Airflow.

## What's here

- `dags/` — example DAGs covering common patterns
- `plugins/` — custom operators and hooks
- `connections/` — example connection definitions
- `requirements.txt` — Snowflake provider and dependencies

## Setup

In your Airflow environment:

```bash
pip install -r requirements.txt
```

Add a Snowflake connection in the Airflow UI (or via env var):

```bash
export AIRFLOW_CONN_SNOWFLAKE_DEFAULT='snowflake://USER:PASSWORD@ACCOUNT/DATABASE/SCHEMA?role=APP_LOADER&warehouse=APP_WH_LOAD&authenticator=snowflake'
```

For key-pair auth (recommended), set the connection extras:
```json
{
  "private_key_file": "/secrets/rsa_key.p8",
  "private_key_passphrase": "..."
}
```

## DAG patterns included

| DAG                          | Pattern                                      |
|------------------------------|----------------------------------------------|
| `daily_orders_load.py`       | Standard daily incremental load              |
| `customer_scd2_refresh.py`   | SCD2 dimension refresh with merge            |
| `dbt_run.py`                 | Trigger dbt-core via BashOperator            |
| `data_quality_checks.py`     | Run DQ assertions, branch on results         |
| `cost_monitor.py`            | Daily cost report posted to Slack            |

## Conventions

- One DAG per logical job; don't bundle unrelated work
- Use the `SnowflakeOperator` for SQL, the `SQLExecuteQueryOperator` if on Airflow 2.8+
- Write idempotent tasks — Airflow retries
- Use `data_interval_start` / `data_interval_end` for parameterizing windows, never `datetime.now()`
- Tag every DAG with `team:<name>`, `domain:<area>`
