"""SCD2 dimension refresh.

Refreshes the customer SCD2 dimension. Designed to handle:
    - New customers (insert)
    - Changed attributes (expire current row, insert new version)
    - Deleted customers in source (mark as terminated, don't delete)
    - Late-arriving data (idempotent — safe to re-run)

Schedule: every 4 hours
Owner: data-platform-team
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator

DEFAULT_ARGS = {
    "owner": "data-platform-team",
    "depends_on_past": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=10),
    "snowflake_conn_id": "snowflake_default",
}

with DAG(
    dag_id="customer_scd2_refresh",
    description="Refreshes the customer SCD2 dimension",
    default_args=DEFAULT_ARGS,
    schedule="0 */4 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["team:data-platform", "domain:customers", "tier:standard"],
) as dag:

    refresh_dim_customers = SnowflakeOperator(
        task_id="refresh_dim_customers",
        sql="""
            CALL app_db.util.sp_refresh_dim_customers(
                P_RUN_ID => '{{ run_id }}'
            )
        """,
    )

    validate_no_orphan_currents = SnowflakeOperator(
        task_id="validate_no_orphan_currents",
        sql="""
            -- Each customer should have exactly one is_current = TRUE row
            SELECT CASE
                WHEN COUNT(*) > 0 THEN 1/0
                ELSE 1
            END AS check_passed
            FROM (
                SELECT customer_id, COUNT(*) AS active_count
                FROM app_db.analytics.dim_customers
                WHERE is_current = TRUE
                GROUP BY customer_id
                HAVING COUNT(*) <> 1
            )
        """,
    )

    validate_history_continuity = SnowflakeOperator(
        task_id="validate_history_continuity",
        sql="""
            -- valid_to of an expired row should equal valid_from of the next version
            SELECT CASE
                WHEN COUNT(*) > 0 THEN 1/0
                ELSE 1
            END AS gap_count
            FROM (
                SELECT
                    customer_id,
                    valid_to,
                    LEAD(valid_from) OVER (PARTITION BY customer_id ORDER BY valid_from) AS next_valid_from
                FROM app_db.analytics.dim_customers
                WHERE valid_to IS NOT NULL
            )
            WHERE next_valid_from IS NOT NULL
              AND valid_to <> next_valid_from
        """,
    )

    refresh_dim_customers >> [validate_no_orphan_currents, validate_history_continuity]
