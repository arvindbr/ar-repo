"""Run a battery of data quality checks. Branches based on severity.

Critical failures → page via PagerDuty
Warning failures  → file a ticket
All clear         → no-op
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import BranchPythonOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.utils.trigger_rule import TriggerRule

DEFAULT_ARGS = {
    "owner": "data-platform-team",
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
    "snowflake_conn_id": "snowflake_default",
}

DQ_CHECKS = [
    {
        "name": "fct_orders_pk_unique",
        "severity": "critical",
        "sql": """
            SELECT COUNT(*) - COUNT(DISTINCT order_id) AS dup_count
            FROM app_db.analytics.fct_orders
            WHERE order_date = '{{ ds }}'
        """,
        "expect_zero_in_column": "DUP_COUNT",
    },
    {
        "name": "fct_orders_freshness",
        "severity": "critical",
        "sql": """
            SELECT DATEDIFF(hour, MAX(order_timestamp), CURRENT_TIMESTAMP()) AS hours_lag
            FROM app_db.analytics.fct_orders
        """,
        "expect_max_value": ("HOURS_LAG", 25),
    },
    {
        "name": "fct_orders_revenue_in_range",
        "severity": "warning",
        "sql": """
            SELECT COUNT(*) AS bad_rows
            FROM app_db.analytics.fct_orders
            WHERE order_date = '{{ ds }}'
              AND total_amount NOT BETWEEN 0 AND 1000000
        """,
        "expect_zero_in_column": "BAD_ROWS",
    },
]


def decide_branch(**context):
    """Inspect XCom from the check tasks and route to the right alert path."""
    ti = context["ti"]
    has_critical = False
    has_warning = False

    for check in DQ_CHECKS:
        result = ti.xcom_pull(task_ids=f"check__{check['name']}")
        if result and result != "PASS":
            if check["severity"] == "critical":
                has_critical = True
            else:
                has_warning = True

    if has_critical:
        return "page_oncall"
    if has_warning:
        return "file_ticket"
    return "all_clear"


with DAG(
    dag_id="data_quality_checks",
    default_args=DEFAULT_ARGS,
    schedule="30 3 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["team:data-platform", "domain:quality"],
) as dag:

    check_tasks = []
    for check in DQ_CHECKS:
        task = SnowflakeOperator(
            task_id=f"check__{check['name']}",
            sql=check["sql"],
            do_xcom_push=True,
            trigger_rule=TriggerRule.ALL_DONE,
        )
        check_tasks.append(task)

    branch = BranchPythonOperator(
        task_id="branch_on_results",
        python_callable=decide_branch,
        trigger_rule=TriggerRule.ALL_DONE,
    )

    page_oncall = EmptyOperator(task_id="page_oncall")
    file_ticket = EmptyOperator(task_id="file_ticket")
    all_clear = EmptyOperator(task_id="all_clear")

    check_tasks >> branch >> [page_oncall, file_ticket, all_clear]
