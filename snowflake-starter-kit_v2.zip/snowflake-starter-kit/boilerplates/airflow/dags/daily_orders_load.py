"""Daily incremental load of orders from RAW to ANALYTICS.

Schedule: daily at 02:00 UTC
Owner: data-platform-team

Pattern:
    1. Wait for RAW.ORDERS_DAILY to be loaded by upstream pipeline
    2. Validate RAW row count is non-zero
    3. Run sp_load_orders procedure (handles staging + merge)
    4. Run data quality checks against the result
    5. Notify Slack on failure
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.providers.snowflake.sensors.snowflake import SnowflakeSqlSensor

DEFAULT_ARGS = {
    "owner": "data-platform-team",
    "depends_on_past": False,
    "email": ["data-alerts@example.com"],
    "email_on_failure": True,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "snowflake_conn_id": "snowflake_default",
}

with DAG(
    dag_id="daily_orders_load",
    description="Incremental load of orders to the analytics layer",
    default_args=DEFAULT_ARGS,
    schedule="0 2 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["team:data-platform", "domain:orders", "tier:critical"],
) as dag:

    wait_for_raw = SnowflakeSqlSensor(
        task_id="wait_for_raw_orders",
        sql="""
            SELECT COUNT(*)
            FROM app_db.raw.orders_daily
            WHERE DATE(_loaded_at) = '{{ ds }}'
        """,
        success=lambda count: count and count[0][0] > 0,
        timeout=60 * 60 * 4,
        poke_interval=60 * 5,
        mode="reschedule",
    )

    load_orders = SnowflakeOperator(
        task_id="load_orders",
        sql="""
            CALL app_db.util.sp_load_orders(
                P_RUN_ID => '{{ run_id }}',
                P_AS_OF_DATE => '{{ ds }}'
            )
        """,
    )

    validate_load = SnowflakeOperator(
        task_id="validate_load",
        sql="""
            SELECT
                CASE
                    WHEN COUNT(*) > 0 THEN 1
                    ELSE 1/0  -- forces failure
                END AS rows_loaded
            FROM app_db.analytics.fct_orders
            WHERE order_date = '{{ ds }}'
        """,
    )

    refresh_metrics = SnowflakeOperator(
        task_id="refresh_daily_revenue_mart",
        sql="""
            CALL app_db.util.sp_refresh_agg_daily_revenue(
                P_AS_OF_DATE => '{{ ds }}'
            )
        """,
    )

    wait_for_raw >> load_orders >> validate_load >> refresh_metrics
