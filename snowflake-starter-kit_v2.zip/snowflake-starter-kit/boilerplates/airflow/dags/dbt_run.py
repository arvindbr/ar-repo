"""Run dbt-core models on a schedule.

Using BashOperator keeps the DAG simple. For more sophisticated dbt orchestration
(per-model task graph, partial reruns), consider Cosmos: https://github.com/astronomer/astronomer-cosmos
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.bash import BashOperator

DEFAULT_ARGS = {
    "owner": "analytics-team",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

DBT_DIR = "/opt/airflow/dbt"
DBT_TARGET = "prod"

with DAG(
    dag_id="dbt_run",
    default_args=DEFAULT_ARGS,
    schedule="0 4 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["team:analytics", "tool:dbt"],
) as dag:

    dbt_deps = BashOperator(
        task_id="dbt_deps",
        bash_command=f"cd {DBT_DIR} && dbt deps --target {DBT_TARGET}",
    )

    dbt_seed = BashOperator(
        task_id="dbt_seed",
        bash_command=f"cd {DBT_DIR} && dbt seed --target {DBT_TARGET}",
    )

    dbt_snapshot = BashOperator(
        task_id="dbt_snapshot",
        bash_command=f"cd {DBT_DIR} && dbt snapshot --target {DBT_TARGET}",
    )

    dbt_run = BashOperator(
        task_id="dbt_run",
        bash_command=f"cd {DBT_DIR} && dbt run --target {DBT_TARGET}",
    )

    dbt_test = BashOperator(
        task_id="dbt_test",
        bash_command=f"cd {DBT_DIR} && dbt test --target {DBT_TARGET}",
    )

    dbt_docs = BashOperator(
        task_id="dbt_docs_generate",
        bash_command=f"cd {DBT_DIR} && dbt docs generate --target {DBT_TARGET}",
    )

    dbt_deps >> dbt_seed >> dbt_snapshot >> dbt_run >> dbt_test >> dbt_docs
