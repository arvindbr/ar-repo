"""Daily Snowflake cost report posted to Slack.

Pulls credit usage for the previous day, computes week-over-week deltas,
and posts a formatted summary to Slack. Flags anomalies (z-score > 2).

Schedule: daily at 08:00 UTC
Owner: data-platform-team
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.operators.python import PythonOperator

DEFAULT_ARGS = {
    "owner": "data-platform-team",
    "retries": 1,
    "retry_delay": timedelta(minutes=15),
}


def fetch_cost_summary(**context) -> dict:
    """Run diagnostic queries and return a summary dict."""
    hook = SnowflakeHook(snowflake_conn_id="snowflake_default")

    summary = {}

    # Total credits yesterday vs same day last week
    summary["totals"] = hook.get_first(
        """
        SELECT
            SUM(CASE WHEN DATE(start_time) = CURRENT_DATE() - 1 THEN credits_used END) AS yesterday,
            SUM(CASE WHEN DATE(start_time) = CURRENT_DATE() - 8 THEN credits_used END) AS last_week_same_day
        FROM snowflake.account_usage.warehouse_metering_history
        WHERE start_time >= DATEADD(day, -10, CURRENT_TIMESTAMP())
        """
    )

    # Top 5 warehouses
    summary["top_warehouses"] = hook.get_records(
        """
        SELECT warehouse_name, SUM(credits_used) AS credits
        FROM snowflake.account_usage.warehouse_metering_history
        WHERE DATE(start_time) = CURRENT_DATE() - 1
        GROUP BY warehouse_name
        ORDER BY credits DESC
        LIMIT 5
        """
    )

    # Anomalies (z-score > 2)
    summary["anomalies"] = hook.get_records(
        """
        WITH daily AS (
            SELECT DATE(start_time) AS day, warehouse_name, SUM(credits_used) AS credits
            FROM snowflake.account_usage.warehouse_metering_history
            WHERE start_time >= DATEADD(day, -90, CURRENT_TIMESTAMP())
            GROUP BY 1, 2
        ),
        stats AS (
            SELECT warehouse_name, AVG(credits) AS mu, STDDEV(credits) AS sigma
            FROM daily
            WHERE day < CURRENT_DATE()
            GROUP BY warehouse_name
        )
        SELECT d.warehouse_name, d.credits, s.mu, (d.credits - s.mu) / NULLIF(s.sigma, 0) AS z
        FROM daily d
        JOIN stats s USING (warehouse_name)
        WHERE d.day = CURRENT_DATE() - 1
          AND ABS((d.credits - s.mu) / NULLIF(s.sigma, 0)) > 2
        ORDER BY ABS(z) DESC
        """
    )

    return summary


def format_slack_message(**context) -> str:
    """Format the summary as a Slack message."""
    summary = context["ti"].xcom_pull(task_ids="fetch_cost_summary")

    yesterday, last_week = summary["totals"]
    yesterday = yesterday or 0
    last_week = last_week or 0
    delta_pct = ((yesterday - last_week) / last_week * 100) if last_week else 0
    direction = "📈" if delta_pct > 0 else "📉"

    lines = [
        f"*Snowflake Daily Cost Report — {(datetime.utcnow() - timedelta(days=1)).date()}*",
        f"",
        f"Total credits: *{yesterday:.1f}* {direction} ({delta_pct:+.1f}% vs same day last week)",
        f"",
        f"*Top warehouses:*",
    ]
    for wh, credits in summary["top_warehouses"]:
        lines.append(f"  • `{wh}`: {credits:.1f} credits")

    if summary["anomalies"]:
        lines.append("")
        lines.append("*🚨 Anomalies detected:*")
        for wh, credits, mu, z in summary["anomalies"]:
            lines.append(f"  • `{wh}`: {credits:.1f} credits (avg {mu:.1f}, z={z:+.1f})")

    return "\n".join(lines)


with DAG(
    dag_id="cost_monitor",
    description="Daily Snowflake cost report to Slack",
    default_args=DEFAULT_ARGS,
    schedule="0 8 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["team:data-platform", "domain:finops"],
) as dag:

    fetch = PythonOperator(
        task_id="fetch_cost_summary",
        python_callable=fetch_cost_summary,
    )

    format_msg = PythonOperator(
        task_id="format_message",
        python_callable=format_slack_message,
    )

    notify = SlackWebhookOperator(
        task_id="notify_slack",
        slack_webhook_conn_id="slack_finops",
        message="{{ ti.xcom_pull(task_ids='format_message') }}",
    )

    fetch >> format_msg >> notify
