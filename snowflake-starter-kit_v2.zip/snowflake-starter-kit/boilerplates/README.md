# Boilerplates

Drop-in mini-projects for common Snowflake tooling. Each boilerplate is independent, has its own README, and can be lifted out and used standalone.

## Available boilerplates

| Boilerplate         | Stack                       | Ready to                                              |
|---------------------|-----------------------------|-------------------------------------------------------|
| [dbt/](./dbt/)              | dbt-snowflake               | Run staging → marts transforms with tests             |
| [streamlit/](./streamlit/)  | Streamlit + Snowpark        | Deploy a dashboard locally or as Streamlit-in-Snowflake |
| [airflow/](./airflow/)      | Apache Airflow              | Orchestrate Snowflake loads, dbt, DQ checks           |
| [snowpark-app/](./snowpark-app/) | Snowpark Python        | Build and deploy stored procedures and UDFs           |
| [data-quality/](./data-quality/) | YAML + Python          | Declare and run table-level data quality assertions   |
| [cicd/](./cicd/)            | GitHub Actions              | PR validation, CI deploys, prod approvals             |

## How to use

1. Pick the boilerplate that matches your need
2. Copy the folder out of the kit (or use it in place)
3. Read its README — each has setup instructions
4. Adapt to your environment

## Conventions

All boilerplates follow the project-wide conventions documented in:
- `../skills/snowflake-sql-author/SKILL.md` — SQL style
- `../skills/snowflake-data-modeler/SKILL.md` — modeling
- `../skills/snowflake-security-auditor/SKILL.md` — auth and grants
- `../docs/ARCHITECTURE.md` — overall layering

This means switching between boilerplates feels consistent — naming, auth, and structure are aligned.

## Combining boilerplates

A typical full-stack setup uses several together:

- **dbt** for transformations
- **Airflow** to orchestrate dbt runs and dependencies
- **Data quality** to validate dbt outputs
- **Streamlit** to expose results
- **CI/CD** to deploy everything safely

Each is independent; pull in only what you need.
