"""Orders dashboard — Streamlit app on Snowflake.

Works in both modes:
    - Local: connects via snowflake-connector-python using .env credentials
    - Streamlit-in-Snowflake: uses get_active_session() (zero credentials)
"""

from __future__ import annotations

import os
from datetime import date, timedelta

import pandas as pd
import streamlit as st


# ============================================================================
# Connection — works in both local and SiS environments
# ============================================================================
@st.cache_resource
def get_session():
    """Return a Snowpark session. In SiS, reuses the active session."""
    try:
        from snowflake.snowpark.context import get_active_session
        return get_active_session()
    except Exception:
        # Local mode — build session from env vars
        from snowflake.snowpark import Session
        from dotenv import load_dotenv
        load_dotenv()

        return Session.builder.configs({
            "account": os.environ["SNOWFLAKE_ACCOUNT"],
            "user": os.environ["SNOWFLAKE_USER"],
            "password": os.environ.get("SNOWFLAKE_PASSWORD"),
            "warehouse": os.environ.get("SNOWFLAKE_WAREHOUSE"),
            "database": os.environ.get("SNOWFLAKE_DATABASE"),
            "schema": os.environ.get("SNOWFLAKE_SCHEMA"),
            "role": os.environ.get("SNOWFLAKE_ROLE"),
        }).create()


@st.cache_data(ttl=300)
def query(sql: str) -> pd.DataFrame:
    """Run a SQL query and return a pandas DataFrame. Cached for 5 minutes."""
    session = get_session()
    return session.sql(sql).to_pandas()


# ============================================================================
# Page config
# ============================================================================
st.set_page_config(
    page_title="Orders Dashboard",
    page_icon="📊",
    layout="wide",
)

st.title("📊 Orders Dashboard")
st.caption("Connected to Snowflake — data refreshes every 5 minutes")


# ============================================================================
# Sidebar filters
# ============================================================================
with st.sidebar:
    st.header("Filters")

    date_range = st.date_input(
        "Date range",
        value=(date.today() - timedelta(days=30), date.today()),
        max_value=date.today(),
    )

    statuses = st.multiselect(
        "Order status",
        options=["PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"],
        default=["DELIVERED"],
    )

    if not statuses:
        st.warning("Select at least one status")
        st.stop()

    if len(date_range) != 2:
        st.warning("Pick a date range")
        st.stop()


# ============================================================================
# Data
# ============================================================================
status_list = ", ".join(f"'{s}'" for s in statuses)
start_date, end_date = date_range

orders_df = query(f"""
    SELECT
        order_date,
        order_status,
        currency_code,
        COUNT(DISTINCT order_id) AS order_count,
        SUM(total_amount)        AS revenue,
        AVG(total_amount)        AS avg_order_value
    FROM app_db.analytics.fct_orders
    WHERE order_date BETWEEN '{start_date}' AND '{end_date}'
      AND order_status IN ({status_list})
    GROUP BY 1, 2, 3
    ORDER BY 1
""")


# ============================================================================
# KPIs
# ============================================================================
col1, col2, col3, col4 = st.columns(4)

total_orders = int(orders_df["ORDER_COUNT"].sum()) if not orders_df.empty else 0
total_revenue = float(orders_df["REVENUE"].sum()) if not orders_df.empty else 0.0
avg_order_value = total_revenue / total_orders if total_orders else 0.0
distinct_days = orders_df["ORDER_DATE"].nunique() if not orders_df.empty else 0

col1.metric("Total Orders", f"{total_orders:,}")
col2.metric("Revenue", f"${total_revenue:,.0f}")
col3.metric("Avg Order Value", f"${avg_order_value:,.2f}")
col4.metric("Active Days", distinct_days)


# ============================================================================
# Charts
# ============================================================================
st.subheader("Daily revenue")
if not orders_df.empty:
    daily = orders_df.groupby("ORDER_DATE", as_index=False)["REVENUE"].sum()
    st.line_chart(daily, x="ORDER_DATE", y="REVENUE", height=300)
else:
    st.info("No data for the selected filters")

col_a, col_b = st.columns(2)

with col_a:
    st.subheader("Orders by status")
    if not orders_df.empty:
        by_status = orders_df.groupby("ORDER_STATUS", as_index=False)["ORDER_COUNT"].sum()
        st.bar_chart(by_status, x="ORDER_STATUS", y="ORDER_COUNT")

with col_b:
    st.subheader("Revenue by currency")
    if not orders_df.empty:
        by_currency = orders_df.groupby("CURRENCY_CODE", as_index=False)["REVENUE"].sum()
        st.bar_chart(by_currency, x="CURRENCY_CODE", y="REVENUE")


# ============================================================================
# Raw data
# ============================================================================
with st.expander("Raw data"):
    st.dataframe(orders_df, use_container_width=True)
    st.download_button(
        "Download as CSV",
        orders_df.to_csv(index=False).encode("utf-8"),
        f"orders_{start_date}_{end_date}.csv",
        "text/csv",
    )
