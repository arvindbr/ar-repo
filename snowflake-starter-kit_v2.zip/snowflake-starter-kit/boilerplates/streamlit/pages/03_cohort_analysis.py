"""Cohort retention analysis."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st

from app import query

st.set_page_config(page_title="Cohort Analysis", page_icon="📈", layout="wide")
st.title("📈 Cohort Retention")
st.caption("Customers grouped by signup month; revenue retention shown over time")


@st.cache_data(ttl=600)
def fetch_cohort_data(months_back: int) -> pd.DataFrame:
    return query(f"""
        WITH customer_signup AS (
            SELECT
                customer_id,
                DATE_TRUNC('month', signup_date) AS signup_month
            FROM app_db.analytics.dim_customers
            WHERE is_current = TRUE
              AND signup_date >= DATEADD(month, -{months_back}, CURRENT_DATE())
        ),
        order_months AS (
            SELECT
                o.customer_id,
                DATE_TRUNC('month', o.order_date) AS order_month,
                SUM(o.total_amount) AS revenue
            FROM app_db.analytics.fct_orders o
            WHERE o.order_status = 'DELIVERED'
            GROUP BY 1, 2
        ),
        cohorts AS (
            SELECT
                cs.signup_month,
                om.order_month,
                DATEDIFF('month', cs.signup_month, om.order_month) AS months_since_signup,
                COUNT(DISTINCT cs.customer_id) AS active_customers,
                SUM(om.revenue) AS revenue
            FROM customer_signup cs
            JOIN order_months om USING (customer_id)
            WHERE om.order_month >= cs.signup_month
            GROUP BY 1, 2, 3
        )
        SELECT * FROM cohorts
        ORDER BY signup_month, months_since_signup
    """)


months_back = st.slider("Cohorts to include (months)", 3, 24, 12)
data = fetch_cohort_data(months_back)

if data.empty:
    st.info("No cohort data available")
    st.stop()


# ============================================================================
# Cohort heatmap
# ============================================================================
pivot = data.pivot_table(
    index="SIGNUP_MONTH",
    columns="MONTHS_SINCE_SIGNUP",
    values="REVENUE",
    aggfunc="sum",
).fillna(0)

st.subheader("Revenue by cohort and months since signup")
st.dataframe(
    pivot.style.format("${:,.0f}").background_gradient(cmap="Blues", axis=None),
    use_container_width=True,
)


# ============================================================================
# Customer count heatmap
# ============================================================================
pivot_cust = data.pivot_table(
    index="SIGNUP_MONTH",
    columns="MONTHS_SINCE_SIGNUP",
    values="ACTIVE_CUSTOMERS",
    aggfunc="sum",
).fillna(0)

st.subheader("Active customer count by cohort")
st.dataframe(
    pivot_cust.style.format("{:.0f}").background_gradient(cmap="Greens", axis=None),
    use_container_width=True,
)
