"""Customer drill-down page.

Shows individual customer details, order history, and lifetime value metrics.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st

from app import query

st.set_page_config(page_title="Customer Drill-Down", page_icon="🧑", layout="wide")
st.title("🧑 Customer Drill-Down")


# ============================================================================
# Customer search
# ============================================================================
search = st.text_input("Search by customer ID or email", placeholder="e.g. 12345 or jane@example.com")

if not search:
    st.info("Enter a customer ID or email to begin")
    st.stop()


@st.cache_data(ttl=300)
def find_customer(search_term: str) -> pd.DataFrame:
    if search_term.isdigit():
        return query(f"""
            SELECT customer_id, email, first_name, last_name, country_code,
                   customer_segment, signup_date
            FROM app_db.analytics.dim_customers
            WHERE customer_id = {int(search_term)}
              AND is_current = TRUE
        """)

    safe = search_term.lower().replace("'", "''")
    return query(f"""
        SELECT customer_id, email, first_name, last_name, country_code,
               customer_segment, signup_date
        FROM app_db.analytics.dim_customers
        WHERE LOWER(email) LIKE '%{safe}%'
          AND is_current = TRUE
        LIMIT 25
    """)


customers = find_customer(search)
if customers.empty:
    st.warning("No customers found")
    st.stop()


if len(customers) > 1:
    st.write(f"{len(customers)} matches — pick one:")
    selected_id = st.selectbox(
        "Customer",
        options=customers["CUSTOMER_ID"],
        format_func=lambda cid: (
            f"{cid} — {customers.loc[customers['CUSTOMER_ID'] == cid, 'EMAIL'].iloc[0]}"
        ),
    )
else:
    selected_id = int(customers["CUSTOMER_ID"].iloc[0])


customer = customers[customers["CUSTOMER_ID"] == selected_id].iloc[0]


# ============================================================================
# Customer profile card
# ============================================================================
col1, col2, col3 = st.columns(3)
col1.metric("Customer ID", customer["CUSTOMER_ID"])
col2.metric("Segment", customer["CUSTOMER_SEGMENT"] or "—")
col3.metric("Country", customer["COUNTRY_CODE"] or "—")

st.write(f"**Name:** {customer['FIRST_NAME']} {customer['LAST_NAME']}")
st.write(f"**Email:** {customer['EMAIL']}")
st.write(f"**Signed up:** {customer['SIGNUP_DATE']}")


# ============================================================================
# Order history
# ============================================================================
st.subheader("Order history")

orders = query(f"""
    SELECT
        order_id,
        order_date,
        order_status,
        total_amount,
        currency_code,
        payment_method,
        shipping_country
    FROM app_db.analytics.fct_orders
    WHERE customer_id = {selected_id}
    ORDER BY order_timestamp DESC
""")

if orders.empty:
    st.info("This customer has no orders yet")
else:
    col_a, col_b, col_c, col_d = st.columns(4)
    delivered = orders[orders["ORDER_STATUS"] == "DELIVERED"]
    col_a.metric("Total Orders", len(orders))
    col_b.metric("Delivered", len(delivered))
    col_c.metric("Lifetime Value", f"${delivered['TOTAL_AMOUNT'].sum():,.2f}")
    col_d.metric(
        "Avg Order Value",
        f"${delivered['TOTAL_AMOUNT'].mean():,.2f}" if not delivered.empty else "—",
    )

    st.dataframe(orders, use_container_width=True, hide_index=True)
