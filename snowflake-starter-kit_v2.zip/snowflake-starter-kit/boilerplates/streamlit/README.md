# Streamlit + Snowflake Boilerplate

A starter Streamlit app that connects to Snowflake and displays an interactive dashboard. Works both standalone (Streamlit Community Cloud, local) and as a Streamlit-in-Snowflake (SiS) app.

## Run locally

```bash
cd boilerplates/streamlit
pip install -r requirements.txt
cp ../../.env.example .env  # then fill in
streamlit run app.py
```

## Deploy as Streamlit-in-Snowflake

```sql
-- 1. Create a stage for the app files
CREATE OR REPLACE STAGE app_db.util.streamlit_apps;

-- 2. Upload the files (use SnowSQL or Snowsight)
PUT file://./app.py @app_db.util.streamlit_apps/orders_dashboard/;
PUT file://./environment.yml @app_db.util.streamlit_apps/orders_dashboard/;

-- 3. Create the app
CREATE OR REPLACE STREAMLIT app_db.analytics.orders_dashboard
    ROOT_LOCATION = '@app_db.util.streamlit_apps/orders_dashboard'
    MAIN_FILE = '/app.py'
    QUERY_WAREHOUSE = app_wh_xs
    COMMENT = 'Orders dashboard for the analytics team';

-- 4. Grant access
GRANT USAGE ON STREAMLIT app_db.analytics.orders_dashboard TO ROLE app_analyst;
```

## Files

- `app.py` — main Streamlit application
- `environment.yml` — conda environment for Streamlit-in-Snowflake
- `requirements.txt` — pip requirements for local
- `pages/` — additional pages (multi-page app)
- `components/` — reusable widgets
- `utils.py` — helper functions
