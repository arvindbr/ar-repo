# CI/CD Boilerplate

GitHub Actions workflows for safely promoting Snowflake changes from PR → CI → prod.

## Workflows included

| File                             | Trigger                       | Purpose                                                |
|----------------------------------|-------------------------------|--------------------------------------------------------|
| `pr-validation.yml`              | PR opened/updated             | Lint + unit tests + dry-run schema diff                |
| `ci-deploy.yml`                  | Merge to `develop`            | Deploy to CI Snowflake account, run integration tests  |
| `prod-deploy.yml`                | Manual dispatch from `main`   | Deploy to prod with approval gate                      |
| `nightly-dq.yml`                 | Cron daily                    | Run data quality suite, report to Slack                |
| `key-rotation-reminder.yml`      | Cron monthly                  | Open issue 30 days before service-account key expiry   |

## Required secrets

In your GitHub repo settings, add these as Actions secrets:

| Secret                                | Used for                                    |
|---------------------------------------|---------------------------------------------|
| `SNOWFLAKE_ACCOUNT`                   | All workflows                               |
| `SNOWFLAKE_USER_CI`                   | CI service account username                 |
| `SNOWFLAKE_PRIVATE_KEY_CI`            | Private key for CI account (PEM contents)   |
| `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE_CI` | Passphrase for the CI key                   |
| `SNOWFLAKE_USER_PROD`                 | Prod service account username               |
| `SNOWFLAKE_PRIVATE_KEY_PROD`          | Prod private key                            |
| `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE_PROD`| Prod key passphrase                        |
| `SLACK_WEBHOOK_URL`                   | Notifications                               |

## Environments

Create three GitHub Environments: `ci`, `staging`, `prod`.

- `prod` should require manual approval from a designated reviewer
- All environments restrict deployment branches (only `main` can deploy to `prod`)

## Migration ordering

Migrations in `sql/migrations/` are applied in lexicographic order. Use the `V####__` prefix consistently.

The deploy workflow applies only migrations whose version is newer than the maximum recorded in `app_db.util.migration_log`.
