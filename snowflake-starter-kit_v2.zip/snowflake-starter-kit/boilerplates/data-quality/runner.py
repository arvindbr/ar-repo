"""Data quality check runner.

Reads YAML check definitions, generates SQL, executes against Snowflake,
and prints a report. Exits non-zero if any critical check fails.

Usage:
    python runner.py --checks checks/fct_orders.yml
    python runner.py --all
    python runner.py --all --output-format json --output-file report.json
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from python.connectors.snowflake_conn import snowflake_connection

logger = logging.getLogger(__name__)


@dataclass
class CheckResult:
    name: str
    table: str
    type: str
    severity: str
    status: str  # PASS | FAIL | ERROR
    failed_rows: int
    message: str


# ============================================================================
# SQL builders for each check type
# ============================================================================

def sql_not_null(table: str, check: dict) -> str:
    return f"SELECT COUNT(*) FROM {table} WHERE {check['column']} IS NULL"


def sql_unique(table: str, check: dict) -> str:
    col = check["column"]
    return f"""
        SELECT COUNT(*)
        FROM (
            SELECT {col}
            FROM {table}
            GROUP BY {col}
            HAVING COUNT(*) > 1
        )
    """


def sql_accepted_values(table: str, check: dict) -> str:
    values = ", ".join(f"'{v}'" for v in check["values"])
    col = check["column"]
    return f"SELECT COUNT(*) FROM {table} WHERE {col} IS NOT NULL AND {col} NOT IN ({values})"


def sql_relationships(table: str, check: dict) -> str:
    col = check["column"]
    parent = check["parent_table"]
    parent_col = check["parent_column"]
    parent_filter = check.get("parent_filter")
    where = f"WHERE {parent_filter}" if parent_filter else ""
    return f"""
        SELECT COUNT(*)
        FROM {table} c
        WHERE c.{col} IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM {parent} p {where}
              {"AND" if parent_filter else "WHERE"} p.{parent_col} = c.{col}
          )
    """


def sql_freshness(table: str, check: dict) -> str:
    col = check["column"]
    max_lag = check["max_lag_hours"]
    return f"""
        SELECT CASE
            WHEN DATEDIFF(hour, MAX({col}), CURRENT_TIMESTAMP()) > {max_lag} THEN 1
            ELSE 0
        END
        FROM {table}
    """


def sql_row_count(table: str, check: dict) -> str:
    where = f"WHERE {check['filter']}" if check.get("filter") else ""
    min_v = check.get("min")
    max_v = check.get("max")
    conditions = []
    if min_v is not None:
        conditions.append(f"COUNT(*) < {min_v}")
    if max_v is not None:
        conditions.append(f"COUNT(*) > {max_v}")
    cond = " OR ".join(conditions) or "FALSE"
    return f"""
        SELECT CASE WHEN {cond} THEN 1 ELSE 0 END
        FROM {table} {where}
    """


def sql_value_range(table: str, check: dict) -> str:
    col = check["column"]
    bounds = []
    if "min" in check:
        bounds.append(f"{col} < {check['min']}")
    if "max" in check:
        bounds.append(f"{col} > {check['max']}")
    cond = " OR ".join(bounds)
    return f"SELECT COUNT(*) FROM {table} WHERE {col} IS NOT NULL AND ({cond})"


def sql_regex_match(table: str, check: dict) -> str:
    col = check["column"]
    pattern = check["pattern"].replace("'", "''")
    return f"SELECT COUNT(*) FROM {table} WHERE {col} IS NOT NULL AND NOT REGEXP_LIKE({col}, '{pattern}')"


def sql_custom_sql(table: str, check: dict) -> str:
    # Wrap the user SQL in a count
    return f"SELECT COUNT(*) FROM ({check['sql']}) AS _custom"


BUILDERS = {
    "not_null": sql_not_null,
    "unique": sql_unique,
    "accepted_values": sql_accepted_values,
    "relationships": sql_relationships,
    "freshness": sql_freshness,
    "row_count": sql_row_count,
    "value_range": sql_value_range,
    "regex_match": sql_regex_match,
    "custom_sql": sql_custom_sql,
}


# ============================================================================
# Execution
# ============================================================================

def run_check(cursor, table: str, check: dict, default_severity: str) -> CheckResult:
    """Execute one check and return a result."""
    name = check["name"]
    check_type = check["type"]
    severity = check.get("severity", default_severity)

    if check_type not in BUILDERS:
        return CheckResult(
            name=name, table=table, type=check_type, severity=severity,
            status="ERROR", failed_rows=0,
            message=f"Unknown check type '{check_type}'",
        )

    sql = BUILDERS[check_type](table, check)
    try:
        cursor.execute(sql)
        failed = cursor.fetchone()[0] or 0
        status = "PASS" if failed == 0 else "FAIL"
        return CheckResult(
            name=name, table=table, type=check_type, severity=severity,
            status=status, failed_rows=int(failed),
            message=f"{failed} row(s) failed" if failed else "OK",
        )
    except Exception as exc:
        return CheckResult(
            name=name, table=table, type=check_type, severity=severity,
            status="ERROR", failed_rows=0,
            message=f"SQL error: {exc}",
        )


def run_file(path: Path, cursor) -> list[CheckResult]:
    with path.open() as f:
        spec = yaml.safe_load(f)

    table = spec["table"]
    default_severity = spec.get("severity_default", "warning")
    results = []
    for check in spec.get("checks", []):
        result = run_check(cursor, table, check, default_severity)
        results.append(result)
        symbol = {"PASS": "✅", "FAIL": "❌", "ERROR": "💥"}[result.status]
        print(f"  {symbol} [{result.severity:>8}] {result.name}: {result.message}")
    return results


def main() -> int:
    logging.basicConfig(level=logging.INFO)
    load_dotenv()

    parser = argparse.ArgumentParser()
    parser.add_argument("--checks", type=Path, action="append", default=[])
    parser.add_argument("--all", action="store_true", help="Run every yml in checks/")
    parser.add_argument("--output-format", choices=["text", "json"], default="text")
    parser.add_argument("--output-file", type=Path)
    args = parser.parse_args()

    files: list[Path] = list(args.checks)
    if args.all:
        files.extend(Path(__file__).parent.joinpath("checks").glob("*.yml"))

    if not files:
        parser.error("Provide --checks or --all")

    all_results: list[CheckResult] = []
    with snowflake_connection() as conn, conn.cursor() as cur:
        for path in files:
            print(f"\n📋 {path.name}")
            all_results.extend(run_file(path, cur))

    # Summary
    failed = [r for r in all_results if r.status == "FAIL"]
    errored = [r for r in all_results if r.status == "ERROR"]
    critical_failures = [r for r in failed if r.severity == "critical"]

    print("\n" + "=" * 60)
    print(f"Total checks: {len(all_results)}")
    print(f"  Passed:    {sum(1 for r in all_results if r.status == 'PASS')}")
    print(f"  Failed:    {len(failed)}  (critical: {len(critical_failures)})")
    print(f"  Errored:   {len(errored)}")
    print("=" * 60)

    if args.output_file:
        if args.output_format == "json":
            args.output_file.write_text(
                json.dumps([asdict(r) for r in all_results], indent=2, default=str)
            )
        else:
            args.output_file.write_text(
                "\n".join(f"{r.status}\t{r.severity}\t{r.name}\t{r.message}" for r in all_results)
            )

    return 1 if critical_failures or errored else 0


if __name__ == "__main__":
    sys.exit(main())
