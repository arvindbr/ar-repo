# Data Quality Boilerplate

A lightweight framework for declaring and running data quality checks against Snowflake tables. Use this directly, or as a reference for integrating into dbt / Great Expectations / Soda.

## What's here

- `checks/` — declarative YAML check definitions
- `runner.py` — executes checks and reports results
- `templates/` — SQL templates for each check type
- `report_template.html` — HTML report template

## Check types supported

| Type             | Description                                   |
|------------------|-----------------------------------------------|
| `not_null`       | Column has no nulls (or below threshold)      |
| `unique`         | Column or combination is unique               |
| `accepted_values`| Column values are in an approved enum         |
| `relationships`  | All values exist in the parent table          |
| `freshness`      | Latest row is within expected lag             |
| `row_count`      | Row count is in expected range                |
| `value_range`    | Numeric column is within bounds               |
| `regex_match`    | String column matches a regex pattern         |
| `custom_sql`     | Run any SQL; expect zero rows                 |

## Run

```bash
python runner.py --checks checks/fct_orders.yml
python runner.py --all   # run every YAML in checks/
```

Failures exit non-zero so CI can pick them up.
