"""Deploy UDFs to Snowflake.

Usage:
    python deploy/deploy_udfs.py
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from dotenv import load_dotenv
from snowflake.snowpark import Session
from snowflake.snowpark.types import StringType

from python.connectors.snowflake_conn import get_connection_params

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def deploy_format_phone(session: Session) -> None:
    """Register format_phone_e164 as a scalar UDF."""
    from src.udfs.format_phone import format_phone_e164

    session.udf.register(
        func=format_phone_e164,
        name="APP_DB.UTIL.FORMAT_PHONE_E164",
        return_type=StringType(),
        input_types=[StringType(), StringType()],
        replace=True,
        is_permanent=True,
        stage_location="@APP_DB.UTIL.PYTHON_DEPLOY",
        packages=["snowflake-snowpark-python"],
        imports=[
            ("./src/lib/transformations.py", "lib.transformations"),
        ],
        comment="Normalize a phone number to E.164 format.",
    )
    logger.info("Deployed APP_DB.UTIL.FORMAT_PHONE_E164")


def main() -> int:
    load_dotenv()
    params = get_connection_params()
    session = Session.builder.configs(params).create()
    try:
        session.sql("CREATE STAGE IF NOT EXISTS APP_DB.UTIL.PYTHON_DEPLOY").collect()
        deploy_format_phone(session)
        logger.info("All UDFs deployed successfully")
        return 0
    except Exception:
        logger.exception("Deployment failed")
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    sys.exit(main())
