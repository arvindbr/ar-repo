"""Deploy stored procedures to Snowflake.

Usage:
    python deploy/deploy_procedures.py
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from dotenv import load_dotenv
from snowflake.snowpark import Session

from python.connectors.snowflake_conn import get_connection_params

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def deploy_score_customers(session: Session) -> None:
    """Register score_customers as a stored procedure."""
    from src.procedures.score_customers import score_customers

    session.sproc.register(
        func=score_customers,
        name="APP_DB.UTIL.SCORE_CUSTOMERS",
        replace=True,
        is_permanent=True,
        stage_location="@APP_DB.UTIL.PYTHON_DEPLOY",
        packages=["snowflake-snowpark-python"],
        imports=[
            ("./src/lib/transformations.py", "lib.transformations"),
        ],
        execute_as="OWNER",
        comment="Score customers based on RFM heuristics. Updates dim_customers.",
    )
    logger.info("Deployed APP_DB.UTIL.SCORE_CUSTOMERS")


def main() -> int:
    load_dotenv()
    params = get_connection_params()
    session = Session.builder.configs(params).create()
    try:
        # Ensure deploy stage exists
        session.sql("CREATE STAGE IF NOT EXISTS APP_DB.UTIL.PYTHON_DEPLOY").collect()

        deploy_score_customers(session)

        logger.info("All procedures deployed successfully")
        return 0
    except Exception:
        logger.exception("Deployment failed")
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    sys.exit(main())
