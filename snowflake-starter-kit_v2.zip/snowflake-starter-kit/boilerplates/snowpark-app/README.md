# Snowpark Python App Boilerplate

A complete project structure for building Snowpark Python applications — stored procedures, UDFs, and apps that run inside Snowflake's compute layer.

## Why Snowpark

Snowpark lets you write Python that executes inside Snowflake's warehouses, with full access to the data. Two main use cases:

1. **Stored procedures and UDFs** — Python logic callable from SQL
2. **Snowpark DataFrames** — PySpark-like API that pushes computation to Snowflake

## Structure

```
snowpark-app/
├── src/
│   ├── procedures/        # Procedures deployed to Snowflake
│   │   └── score_customers.py
│   ├── udfs/              # User-defined functions
│   │   └── format_phone.py
│   └── lib/               # Shared logic, importable both locally and in SP/UDF
│       └── transformations.py
├── deploy/
│   ├── deploy_procedures.py
│   ├── deploy_udfs.py
│   └── packages.yml       # Anaconda packages allowed in Snowflake
├── tests/
│   └── test_transformations.py
├── pyproject.toml
└── requirements.txt
```

## Local development workflow

1. Write your logic in `src/lib/` so it's testable locally with pytest
2. Wrap it in a procedure entry point in `src/procedures/`
3. Test locally: `pytest tests/`
4. Deploy: `python deploy/deploy_procedures.py`
5. Call from SQL: `CALL APP_DB.UTIL.SCORE_CUSTOMERS('2026-05-01');`

## Available Anaconda packages

Snowflake bundles a curated set of Anaconda packages. Common ones (pandas, numpy, scikit-learn, scipy, xgboost, lightgbm) work out of the box. To use less common packages, list them in `packages.yml` and verify availability:

```sql
SHOW PACKAGES LIKE 'package-name' IN ACCOUNT;
```

For non-Anaconda packages, upload them as a stage import.

## Limits

- Procedure runtime: up to 60 minutes default (configurable to several hours)
- UDF runtime per row: tens of milliseconds typical
- Memory per warehouse-node: depends on warehouse size
- Network: outbound calls require an external access integration
