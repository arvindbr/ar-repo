"""Unit tests for the pure-python transformations."""

from __future__ import annotations

import pytest

from src.lib.transformations import calculate_customer_score, format_phone


class TestCalculateCustomerScore:
    """Tests for calculate_customer_score."""

    def test_returns_zero_for_no_orders(self):
        assert calculate_customer_score(0, 0, 0) == 0.0

    def test_returns_zero_for_negative_ltv(self):
        assert calculate_customer_score(-100, 5, 1) == 0.0

    def test_high_score_for_recent_frequent_high_value(self):
        score = calculate_customer_score(
            lifetime_value=8000,
            days_since_last_order=5,
            order_count=40,
        )
        assert 80 <= score <= 100

    def test_low_score_for_distant_infrequent_low_value(self):
        score = calculate_customer_score(
            lifetime_value=50,
            days_since_last_order=300,
            order_count=1,
        )
        assert score < 20

    def test_score_is_in_range(self):
        for ltv in [10, 100, 1000, 10000]:
            for days in [0, 30, 180, 365]:
                for count in [1, 5, 20, 100]:
                    score = calculate_customer_score(ltv, days, count)
                    assert 0 <= score <= 100, (
                        f"Out of range: ltv={ltv}, days={days}, count={count}, score={score}"
                    )


class TestFormatPhone:
    """Tests for format_phone."""

    def test_returns_none_for_empty(self):
        assert format_phone(None) is None
        assert format_phone("") is None
        assert format_phone("  ") is None

    def test_passes_through_e164(self):
        assert format_phone("+14155551234") == "+14155551234"

    def test_strips_formatting(self):
        assert format_phone("(415) 555-1234") == "+14155551234"
        assert format_phone("415.555.1234") == "+14155551234"
        assert format_phone("415 555 1234") == "+14155551234"

    def test_handles_us_with_country_digit(self):
        assert format_phone("1-415-555-1234") == "+14155551234"

    def test_uk_number(self):
        assert format_phone("020 7946 0958", country_code="GB") == "+442079460958"

    def test_returns_none_for_unknown_country(self):
        assert format_phone("123456", country_code="ZZ") is None
