"""Score customers and write results to a table.

Deployed as a Snowflake stored procedure. Call from SQL:

    CALL APP_DB.UTIL.SCORE_CUSTOMERS('2026-05-01');

The procedure reads from FCT_ORDERS, computes a score per customer, and
upserts into DIM_CUSTOMERS.CUSTOMER_SCORE.
"""

from __future__ import annotations

from datetime import date

from snowflake.snowpark import Session
from snowflake.snowpark.functions import col, current_date, datediff, lit, max as max_, sum as sum_

# When deployed, lib is imported from the procedure's package
from lib.transformations import calculate_customer_score


def score_customers(session: Session, as_of_date: str) -> str:
    """Compute customer scores as of a given date and upsert to dim_customers.

    Args:
        session: Snowpark session (injected by Snowflake at runtime).
        as_of_date: ISO date string (e.g., '2026-05-01').

    Returns:
        Status message with row counts.
    """
    as_of = date.fromisoformat(as_of_date)

    # Aggregate orders per customer up to the as-of date
    orders = session.table("APP_DB.ANALYTICS.FCT_ORDERS").filter(
        (col("ORDER_STATUS") == "DELIVERED")
        & (col("ORDER_DATE") <= lit(as_of))
    )

    metrics = orders.group_by("CUSTOMER_ID").agg(
        sum_("TOTAL_AMOUNT").alias("LIFETIME_VALUE"),
        max_("ORDER_DATE").alias("LAST_ORDER_DATE"),
        sum_(lit(1)).alias("ORDER_COUNT"),
    ).with_column(
        "DAYS_SINCE_LAST_ORDER",
        datediff("day", col("LAST_ORDER_DATE"), lit(as_of)),
    )

    # Pull to driver to compute score with pure-python function
    rows = metrics.collect()
    scored = [
        (
            row["CUSTOMER_ID"],
            calculate_customer_score(
                lifetime_value=float(row["LIFETIME_VALUE"]),
                days_since_last_order=int(row["DAYS_SINCE_LAST_ORDER"]),
                order_count=int(row["ORDER_COUNT"]),
            ),
            as_of,
        )
        for row in rows
    ]

    if not scored:
        return "SUCCESS: 0 customers scored"

    # Write back to a scratch table, then merge
    scored_df = session.create_dataframe(
        scored,
        schema=["CUSTOMER_ID", "SCORE", "SCORED_AT"],
    )
    scored_df.write.mode("overwrite").save_as_table(
        "APP_DB.UTIL.CUSTOMER_SCORES_TMP"
    )

    session.sql(f"""
        MERGE INTO APP_DB.ANALYTICS.DIM_CUSTOMERS t
        USING APP_DB.UTIL.CUSTOMER_SCORES_TMP s
            ON t.customer_id = s.customer_id AND t.is_current = TRUE
        WHEN MATCHED THEN UPDATE SET
            t.customer_score   = s.score,
            t.score_updated_at = s.scored_at,
            t.updated_at       = CURRENT_TIMESTAMP();
    """).collect()

    return f"SUCCESS: {len(scored)} customers scored as of {as_of_date}"
