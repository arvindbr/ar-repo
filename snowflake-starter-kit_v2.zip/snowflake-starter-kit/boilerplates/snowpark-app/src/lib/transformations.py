"""Pure-Python transformations — no Snowflake dependencies.

Keeping the business logic here makes it testable locally with pytest. The
procedure and UDF wrappers in src/procedures and src/udfs import from this
module and add the Snowflake-specific I/O layer.
"""

from __future__ import annotations

import re
from typing import Optional


def calculate_customer_score(
    lifetime_value: float,
    days_since_last_order: int,
    order_count: int,
) -> float:
    """Score a customer based on RFM-style heuristics.

    Args:
        lifetime_value: Total revenue from this customer (USD).
        days_since_last_order: Recency in days; 0 = today.
        order_count: Total orders placed.

    Returns:
        A score from 0 to 100.
    """
    if lifetime_value <= 0 or order_count <= 0:
        return 0.0

    # Recency: full credit if within 30 days, decays linearly to 0 at 365
    recency_score = max(0.0, 1.0 - days_since_last_order / 365.0) * 40

    # Frequency: log-scaled
    import math
    frequency_score = min(math.log1p(order_count) / math.log(50), 1.0) * 30

    # Monetary: log-scaled
    monetary_score = min(math.log1p(lifetime_value) / math.log(10000), 1.0) * 30

    return round(recency_score + frequency_score + monetary_score, 2)


def format_phone(raw: Optional[str], country_code: str = "US") -> Optional[str]:
    """Normalize a phone number to E.164 format.

    Args:
        raw: Raw phone number string (any format).
        country_code: ISO country code for fallback when no '+' prefix.

    Returns:
        E.164 formatted string (e.g., "+14155551234"), or None if invalid.
    """
    if not raw:
        return None

    digits = re.sub(r"[^\d+]", "", raw)
    if not digits:
        return None

    if digits.startswith("+"):
        return digits

    country_prefixes = {"US": "+1", "CA": "+1", "GB": "+44", "DE": "+49"}
    prefix = country_prefixes.get(country_code, "")
    if not prefix:
        return None

    if country_code in ("US", "CA") and len(digits) == 10:
        return prefix + digits
    if country_code in ("US", "CA") and len(digits) == 11 and digits.startswith("1"):
        return "+" + digits

    return prefix + digits
