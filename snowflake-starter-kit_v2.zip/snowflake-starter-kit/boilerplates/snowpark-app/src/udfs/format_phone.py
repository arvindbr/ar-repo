"""Phone normalization UDF.

Deployed as a scalar UDF callable from SQL:

    SELECT app_db.util.format_phone_e164(phone, 'US') FROM dim_customers;

The function is a thin wrapper around the pure-python format_phone in
src/lib/transformations.py to keep business logic testable locally.
"""

from __future__ import annotations

from typing import Optional

from lib.transformations import format_phone


def format_phone_e164(raw: Optional[str], country_code: str = "US") -> Optional[str]:
    """Normalize a phone number to E.164.

    Args:
        raw: Raw phone string in any format.
        country_code: ISO country code if no prefix in raw.

    Returns:
        E.164 formatted string, or NULL if invalid.
    """
    return format_phone(raw, country_code)
