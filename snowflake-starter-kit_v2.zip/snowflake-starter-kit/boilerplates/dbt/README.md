# dbt + Snowflake Boilerplate

A minimal, production-ready dbt project configured for Snowflake.

## What you get

- `dbt_project.yml` with sensible defaults
- `profiles.yml` template using environment variables
- Example staging, dimension, and fact models
- `dbt_utils` and `dbt_expectations` packages pre-configured
- Generic + custom tests
- Snapshots for SCD2
- Macros for common patterns

## Setup

```bash
cd boilerplates/dbt
pip install dbt-snowflake
dbt deps
dbt debug    # verifies connection
dbt run
dbt test
```

## Layout

```
dbt/
├── dbt_project.yml
├── profiles.yml.example
├── packages.yml
├── models/
│   ├── staging/
│   │   ├── _sources.yml
│   │   ├── _staging.yml
│   │   └── stg_orders.sql
│   ├── intermediate/
│   │   └── int_orders_enriched.sql
│   └── marts/
│       ├── _marts.yml
│       ├── dim_customers.sql
│       └── fct_orders.sql
├── snapshots/
│   └── customers_snapshot.sql
├── macros/
│   ├── generate_schema_name.sql
│   └── audit_columns.sql
├── tests/
│   └── assert_positive_revenue.sql
└── seeds/
    └── country_codes.csv
```

## Conventions

Follows the project-wide conventions in `../../skills/snowflake-sql-author/SKILL.md` and `../../skills/snowflake-data-modeler/SKILL.md`.
