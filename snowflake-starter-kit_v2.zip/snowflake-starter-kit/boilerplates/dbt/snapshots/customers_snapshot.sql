{% snapshot customers_snapshot %}

{{
    config(
      target_schema='snapshots',
      unique_key='customer_id',
      strategy='check',
      check_cols=['email', 'first_name', 'last_name', 'phone', 'country_code', 'customer_segment'],
      invalidate_hard_deletes=True,
    )
}}

SELECT
    customer_id,
    email,
    first_name,
    last_name,
    phone,
    country_code,
    customer_segment,
    signup_date,
    _loaded_at
FROM {{ source('app_raw', 'customers') }}
WHERE customer_id IS NOT NULL

{% endsnapshot %}
