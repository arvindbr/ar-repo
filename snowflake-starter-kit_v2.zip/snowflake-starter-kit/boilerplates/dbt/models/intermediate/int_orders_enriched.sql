{{
    config(
        materialized='ephemeral',
        tags=['intermediate']
    )
}}

-- Enriches orders with customer attributes for downstream marts.
-- Ephemeral: inlined into consumers, never materialized.

WITH orders AS (
    SELECT * FROM {{ ref('stg_orders') }}
),

customers AS (
    SELECT
        customer_id,
        email,
        country_code,
        customer_segment,
        signup_date
    FROM {{ ref('stg_customers') }}
),

enriched AS (
    SELECT
        o.*,
        c.email                AS customer_email,
        c.country_code         AS customer_country,
        c.customer_segment,
        c.signup_date,
        DATEDIFF('day', c.signup_date, o.order_date) AS days_since_signup,
        CASE
            WHEN c.signup_date IS NULL                                  THEN 'unknown'
            WHEN o.order_date = c.signup_date                           THEN 'first_order'
            WHEN DATEDIFF('day', c.signup_date, o.order_date) <= 30     THEN 'new'
            WHEN DATEDIFF('day', c.signup_date, o.order_date) <= 365    THEN 'returning'
            ELSE 'loyal'
        END AS customer_lifecycle_stage
    FROM orders o
    LEFT JOIN customers c USING (customer_id)
)

SELECT * FROM enriched
