{{
    config(
        materialized='view',
        tags=['staging', 'customers']
    )
}}

WITH source AS (
    SELECT * FROM {{ source('app_raw', 'customers') }}
),

cleansed AS (
    SELECT
        customer_id::NUMBER(38,0)               AS customer_id,
        LOWER(TRIM(email))::VARCHAR             AS email,
        INITCAP(TRIM(first_name))::VARCHAR      AS first_name,
        INITCAP(TRIM(last_name))::VARCHAR       AS last_name,
        TRIM(phone)::VARCHAR                    AS phone,
        UPPER(TRIM(country_code))::VARCHAR(2)   AS country_code,
        UPPER(TRIM(customer_segment))::VARCHAR(30) AS customer_segment,
        signup_date::DATE                       AS signup_date,
        _loaded_at::TIMESTAMP_NTZ               AS _loaded_at
    FROM source
    WHERE customer_id IS NOT NULL
),

deduped AS (
    -- Keep only the most-recently-loaded row per customer
    SELECT *
    FROM cleansed
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY customer_id
        ORDER BY _loaded_at DESC
    ) = 1
)

SELECT * FROM deduped
