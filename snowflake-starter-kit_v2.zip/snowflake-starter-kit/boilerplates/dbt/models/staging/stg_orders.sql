{{
    config(
        materialized='view',
        tags=['staging', 'orders']
    )
}}

WITH source AS (
    SELECT * FROM {{ source('app_raw', 'orders') }}
),

cleansed AS (
    SELECT
        order_id::NUMBER(38,0)              AS order_id,
        customer_id::NUMBER(38,0)           AS customer_id,
        order_date::DATE                    AS order_date,
        order_timestamp::TIMESTAMP_NTZ      AS order_timestamp,
        UPPER(TRIM(order_status))::VARCHAR  AS order_status,
        currency_code::VARCHAR(3)           AS currency_code,
        subtotal_amount::NUMBER(18,4)       AS subtotal_amount,
        tax_amount::NUMBER(18,4)            AS tax_amount,
        shipping_amount::NUMBER(18,4)       AS shipping_amount,
        COALESCE(discount_amount, 0)::NUMBER(18,4) AS discount_amount,
        total_amount::NUMBER(18,4)          AS total_amount,
        payment_method::VARCHAR(30)         AS payment_method,
        UPPER(TRIM(shipping_country))::VARCHAR(2) AS shipping_country,
        _loaded_at::TIMESTAMP_NTZ           AS _loaded_at,
        _source_file::VARCHAR               AS _source_file
    FROM source
    WHERE order_id IS NOT NULL
)

SELECT * FROM cleansed
