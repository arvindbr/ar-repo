{{
    config(
        materialized='incremental',
        unique_key='order_id',
        on_schema_change='append_new_columns',
        cluster_by=['order_date', 'customer_id'],
        tags=['marts', 'finance']
    )
}}

WITH orders AS (
    SELECT * FROM {{ ref('stg_orders') }}
    {% if is_incremental() %}
        WHERE _loaded_at > (SELECT MAX(_loaded_at) FROM {{ this }})
    {% endif %}
),

customers AS (
    SELECT customer_id, signup_date
    FROM {{ ref('dim_customers') }}
    WHERE is_current = TRUE
),

enriched AS (
    SELECT
        o.order_id,
        o.customer_id,
        o.order_date,
        o.order_timestamp,
        o.order_status,
        o.currency_code,
        o.subtotal_amount,
        o.tax_amount,
        o.shipping_amount,
        o.discount_amount,
        o.total_amount,
        o.payment_method,
        o.shipping_country,
        c.signup_date,
        DATEDIFF('day', c.signup_date, o.order_date) AS days_since_signup,
        CASE
            WHEN o.order_date = c.signup_date THEN TRUE
            ELSE FALSE
        END AS is_first_order,
        o._loaded_at
    FROM orders o
    LEFT JOIN customers c USING (customer_id)
)

SELECT * FROM enriched
