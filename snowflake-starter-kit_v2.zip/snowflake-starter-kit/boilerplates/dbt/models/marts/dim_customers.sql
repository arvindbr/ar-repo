{{
    config(
        materialized='table',
        cluster_by=['customer_id'],
        tags=['marts', 'dimensions']
    )
}}

-- Pulls the current version of each customer from the snapshot table.
-- Use the snapshot directly for point-in-time analysis.

WITH source AS (
    SELECT
        customer_id,
        email,
        first_name,
        last_name,
        phone,
        country_code,
        customer_segment,
        signup_date,
        dbt_valid_from AS valid_from,
        dbt_valid_to   AS valid_to,
        CASE WHEN dbt_valid_to IS NULL THEN TRUE ELSE FALSE END AS is_current
    FROM {{ ref('customers_snapshot') }}
),

with_sk AS (
    SELECT
        {{ dbt_utils.generate_surrogate_key(['customer_id', 'valid_from']) }} AS customer_sk,
        *
    FROM source
)

SELECT * FROM with_sk
