{#
    generate_schema_name
    --------------------
    Override the default dbt schema-naming behavior so that:
      - In dev, all models go to the developer's personal schema
      - In CI and prod, the configured schema is used as-is
    See https://docs.getdbt.com/docs/build/custom-schemas
#}
{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- set default_schema = target.schema -%}
    {%- if target.name == 'dev' -%}
        {{ default_schema }}
    {%- elif custom_schema_name is none -%}
        {{ default_schema }}
    {%- else -%}
        {{ custom_schema_name | trim }}
    {%- endif -%}
{%- endmacro %}
