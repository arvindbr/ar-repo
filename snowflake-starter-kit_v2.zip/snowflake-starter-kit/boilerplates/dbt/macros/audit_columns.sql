{#
    audit_columns
    -------------
    Adds standard audit columns to a model after it's built.
    Hooked in dbt_project.yml as a post-hook for marts.

    Adds:
        dbt_run_id    — the dbt invocation_id
        dbt_run_at    — when this run executed
        dbt_model     — the model that produced the row
#}
{% macro audit_columns() %}
    ALTER TABLE {{ this }} ADD COLUMN IF NOT EXISTS dbt_run_id VARCHAR;
    ALTER TABLE {{ this }} ADD COLUMN IF NOT EXISTS dbt_run_at TIMESTAMP_NTZ;
    ALTER TABLE {{ this }} ADD COLUMN IF NOT EXISTS dbt_model VARCHAR;

    UPDATE {{ this }}
    SET
        dbt_run_id = '{{ invocation_id }}',
        dbt_run_at = CURRENT_TIMESTAMP(),
        dbt_model  = '{{ this.name }}'
    WHERE dbt_run_id IS NULL
       OR dbt_run_id <> '{{ invocation_id }}';
{% endmacro %}
