-- Asserts that no order has a negative or zero revenue value.
-- Run as part of `dbt test`.
-- Failure indicates either a data corruption or upstream pipeline bug.

SELECT
    order_id,
    customer_id,
    order_date,
    total_amount
FROM {{ ref('fct_orders') }}
WHERE order_status = 'DELIVERED'
  AND total_amount <= 0
