---
description: Optimize a slow Snowflake query
argument-hint: [query-id-or-paste-the-sql]
---

Diagnose and optimize the slow query: $ARGUMENTS

Use the `agents/query-optimizer/AGENT.md` agent.

If the user passed a query ID, fetch metrics from `QUERY_HISTORY` first. If they pasted SQL, ask whether you should also run diagnostics or reason from the SQL alone.

Output the four standard sections: Diagnosis, Rewritten query, Why this is faster, How to verify.
