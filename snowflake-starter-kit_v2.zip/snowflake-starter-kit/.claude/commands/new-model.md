---
description: Scaffold a new Snowflake model (table + load + test + docs)
argument-hint: <table-name> [fact|dim|stg]
---

Scaffold a complete new model named `$1` of type `$2` (default: `dim`).

Steps:
1. Read `skills/snowflake-data-modeler/SKILL.md` and `skills/snowflake-sql-author/SKILL.md`
2. Confirm with the user:
   - Grain
   - Source tables
   - Primary key
   - SCD type if dimension
3. Create:
   - `sql/ddl/$1.sql` — DDL with audit columns and clustering
   - `sql/dml/load_$1.sql` — merge or insert pattern
   - `tests/test_$1.py` — data quality tests
   - `docs/models/$1.md` — model documentation page
4. Print a summary of files created and next steps
