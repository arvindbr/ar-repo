---
description: Generate a safe Snowflake schema migration
argument-hint: <change description>
---

Generate a versioned schema migration for: $ARGUMENTS

Use the `agents/schema-migrator/AGENT.md` agent definition.

Required outputs:
- `sql/migrations/V####__<slug>.sql` (forward)
- `sql/migrations/V####__<slug>.rollback.sql` (rollback)

Both files must include header comments, pre-condition checks, and migration log entries.

Print the deployment command and rollback command after generating.
