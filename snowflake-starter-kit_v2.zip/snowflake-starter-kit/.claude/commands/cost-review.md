---
description: Run a Snowflake cost review and generate a report
---

Run a comprehensive cost review of the connected Snowflake account.

Steps:
1. Read `skills/snowflake-cost-optimizer/SKILL.md`
2. Run the diagnostic queries in that skill against the project's Snowflake connection
3. Identify the top 5 cost drivers
4. For each, propose a specific action with expected savings
5. Output a markdown report at `docs/cost-review-YYYY-MM-DD.md` with:
   - Executive summary (total spend, week-over-week change)
   - Top 5 findings with actions
   - Diagnostic query results as tables
   - Recommendations sorted by impact

Be conservative with recommendations — flag items needing owner sign-off rather than acting.
