# Snowflake Starter Kit for VS Code + GitHub Copilot

A complete, production-ready starter project for working with Snowflake. Optimized for AI-assisted development with GitHub Copilot, Claude Code, or any LLM-powered IDE.

## What's Included

### Core
- 🔌 **Snowflake connectors** — Python connector and Snowpark with key-pair, password, and SSO auth
- 🗄️ **SQL templates** — DDL, DML, queries, procedures, and migrations
- 🔧 **VS Code config** — extensions, settings, tasks, debug configs
- 🧪 **Tests** — pytest with mocking patterns and integration markers
- 📓 **Notebooks** — Jupyter examples
- 🔐 **Secure config** — `.env` patterns, key-pair generation script
- 🚀 **CI/CD** — GitHub Actions for PR validation and prod deploys

### AI assistance
- 🤖 **Copilot instructions** — `.github/copilot-instructions.md` loaded automatically
- 💬 **Custom prompts** — `.github/prompts/` for new tables, procedures, optimization, tests
- 🎯 **Chat modes** — DBA, analytics engineer, FinOps personas
- 📚 **Skills** — Six domain-expert knowledge packs (`skills/`)
- 🧑‍💻 **Agents** — Six task-focused agents (`agents/`)
- 📐 **Path-scoped instructions** — Targeted Copilot rules for SQL and Python files (`.github/instructions/`)
- 🧠 **Claude Code** — `CLAUDE.md` memory file and `.claude/commands/` slash commands

### Boilerplates
- 📊 **dbt** — full project with sources, models, snapshots, macros
- 📈 **Streamlit** — dashboard app with local + Streamlit-in-Snowflake support
- 🌬️ **Airflow** — DAGs for loads, dbt runs, data quality, cost monitoring
- 🐍 **Snowpark app** — procedures, UDFs, deploy scripts, tests
- ✅ **Data quality** — declarative YAML check framework with runner
- 🔄 **CI/CD** — PR validation, CI deploy, prod deploy with approvals

## Quick Start

```bash
# 1. Install
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. Configure
cp .env.example .env  # then edit

# 3. Verify
python python/connectors/test_connection.py
```

Open the folder in VS Code, accept the recommended extensions, and you're ready.

## Project Structure

```
snowflake-starter-kit/
├── .claude/
│   └── commands/              # Claude Code slash commands
├── .github/
│   ├── copilot-instructions.md
│   ├── prompts/               # Reusable Copilot prompts
│   ├── chatmodes/             # Custom chat personas
│   └── workflows/             # GitHub Actions
├── .vscode/                   # IDE config
├── CLAUDE.md                  # Claude Code project memory
├── agents/                    # Task-focused AI agents
│   ├── etl-pipeline-builder/
│   ├── query-optimizer/
│   ├── schema-migrator/
│   └── data-quality-guardian/
├── skills/                    # Domain-expert knowledge packs
│   ├── snowflake-sql-author/
│   ├── snowflake-performance-tuner/
│   ├── snowflake-security-auditor/
│   ├── snowflake-cost-optimizer/
│   └── snowflake-data-modeler/
├── boilerplates/              # Drop-in mini-projects
│   ├── dbt/
│   ├── streamlit/
│   ├── airflow/
│   ├── snowpark-app/
│   ├── data-quality/
│   └── cicd/
├── templates/                 # File templates for new objects
│   ├── sql/
│   ├── python/
│   └── yaml/
├── sql/
│   ├── ddl/                   # Tables, schemas, audit log
│   ├── dml/                   # Inserts, updates, merges
│   ├── queries/               # Analytical queries
│   ├── procedures/            # Stored procs and UDFs
│   └── migrations/            # Versioned schema changes
├── python/
│   ├── connectors/            # Connection helpers
│   ├── etl/                   # Pipeline code
│   └── utils/                 # Shared utilities
├── notebooks/                 # Jupyter examples
├── tests/                     # Pytest suite
├── scripts/                   # Setup and admin scripts
└── docs/                      # Architecture, Copilot guide
```

## Skills

Each skill is a markdown file with frontmatter that AI assistants read on-demand to specialize their behavior for a domain.

| Skill                              | Use for                                                |
|------------------------------------|--------------------------------------------------------|
| `snowflake-sql-author`             | Writing SQL — formatting, naming, idempotency          |
| `snowflake-performance-tuner`      | Diagnosing and fixing slow queries                     |
| `snowflake-security-auditor`       | RBAC, masking, network policies, key-pair auth         |
| `snowflake-cost-optimizer`         | Credit reviews, FinOps, warehouse right-sizing         |
| `snowflake-data-modeler`           | Star schemas, SCD, grain decisions                     |
| `snowflake-notebook-author`        | Jupyter / Snowflake notebooks for analysis             |

## Agents

Each agent is a complete task playbook for AI assistants — input requirements, workflow, output spec, and quality bar.

| Agent                        | Triggers when you ask to...                       |
|------------------------------|---------------------------------------------------|
| `etl-pipeline-builder`       | Build an end-to-end source-to-mart pipeline       |
| `query-optimizer`            | Diagnose and rewrite a slow query                 |
| `schema-migrator`            | Generate safe forward/rollback migrations         |
| `data-quality-guardian`      | Generate a test suite for a table                 |
| `test-data-factory`          | Generate realistic synthetic test data            |
| `docs-writer`                | Write or update model docs, runbooks, ADRs       |

## Custom prompts (Copilot Chat slash commands)

| Prompt              | Purpose                                        |
|---------------------|------------------------------------------------|
| `/new-table`        | Generate a Snowflake table DDL                 |
| `/new-procedure`    | Scaffold a stored procedure                    |
| `/optimize-query`   | Analyze and improve a slow query               |
| `/generate-test`    | Create pytest tests for code                   |

## Chat modes

Switch Copilot's persona for different tasks. In Copilot Chat, select a mode from the dropdown.

| Mode                  | Use for                                       |
|-----------------------|-----------------------------------------------|
| `snowflake-dba`       | Schema, security, platform tasks              |
| `analytics-engineer`  | Modeling, transforms, BI work                 |
| `finops`              | Cost reviews, warehouse tuning                |

## Claude Code commands

If you use Claude Code, these slash commands are available:

| Command          | Action                                              |
|------------------|-----------------------------------------------------|
| `/new-model`     | Scaffold a complete new fact or dimension           |
| `/migrate`       | Generate a versioned schema migration               |
| `/optimize`      | Diagnose and rewrite a slow query                   |
| `/cost-review`   | Run a Snowflake cost analysis report                |

## Boilerplates

Drop-in mini-projects you can copy and adapt. Each has its own README.

| Boilerplate         | What you get                                                |
|---------------------|-------------------------------------------------------------|
| `dbt/`              | Full dbt project: sources, staging, marts, snapshots, tests |
| `streamlit/`        | Dashboard app — works locally and as Streamlit-in-Snowflake |
| `airflow/`          | DAGs for loads, dbt, data quality, cost monitoring          |
| `snowpark-app/`     | Snowpark Python procedures + UDFs with deploy scripts       |
| `data-quality/`     | Declarative YAML check framework + runner                   |
| `cicd/`             | GitHub Actions workflows for PR + prod deploys              |

## Authentication Methods

1. **Username/password** — Quick start (dev only)
2. **Key-pair authentication** — Recommended for production (run `scripts/generate_key_pair.sh`)
3. **SSO/External browser** — For interactive use
4. **OAuth** — For applications

## License

MIT — Use this freely as a template for your team.

## Contributing

This kit is meant to be forked and adapted. The skills, agents, and boilerplates are deliberately opinionated to give AI assistants strong defaults. Override anything that doesn't match your team's conventions.
