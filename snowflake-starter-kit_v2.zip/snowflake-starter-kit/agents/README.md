# Agents

Task-focused playbooks that AI assistants follow end-to-end. Where a skill provides domain knowledge, an agent provides a workflow — what to ask, what to produce, in what order, and to what quality bar.

## When to use agents vs. skills

| You want...                                  | Use     |
|----------------------------------------------|---------|
| Domain expertise applied to ad-hoc tasks     | Skill   |
| A repeatable multi-step workflow             | Agent   |
| Both (most cases)                            | Both — agents reference skills |

Agents typically read 1–3 skills as part of their workflow.

## Available agents

| Agent                                                                      | Workflow                                              |
|----------------------------------------------------------------------------|-------------------------------------------------------|
| [etl-pipeline-builder](./etl-pipeline-builder/AGENT.md)                    | Source description → 8 production-ready files         |
| [query-optimizer](./query-optimizer/AGENT.md)                              | Slow query → diagnosis + rewrite + verification plan  |
| [schema-migrator](./schema-migrator/AGENT.md)                              | Change description → forward + rollback migrations    |
| [data-quality-guardian](./data-quality-guardian/AGENT.md)                  | Table → comprehensive DQ test suite                   |
| [test-data-factory](./test-data-factory/AGENT.md)                          | Schema → realistic synthetic data                     |
| [docs-writer](./docs-writer/AGENT.md)                                      | Object/pipeline → docs page, runbook, or ADR          |

## Agent format

Each agent's `AGENT.md` has:

```yaml
---
name: agent-name
description: When to invoke this agent
tools: [list of tools the agent should have access to]
model: sonnet | opus | haiku    # recommended Claude model
---
```

Followed by sections covering:

- **Inputs you need** — what to ask the user before starting
- **Outputs you produce** — exact files and shape
- **Workflow** — ordered steps
- **Quality bar** — checks before declaring done
- **Cross-references** — when to hand off to other agents/skills

## Adding a new agent

1. Create `agents/<your-agent-name>/AGENT.md`
2. Use the format above
3. Be explicit about inputs, outputs, and quality bar — agents are most useful when their contract is unambiguous
4. Reference relevant skills rather than duplicating their content
