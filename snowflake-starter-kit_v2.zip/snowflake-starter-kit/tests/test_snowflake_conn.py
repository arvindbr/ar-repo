"""Unit tests for snowflake_conn module."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from python.connectors.snowflake_conn import (
    SnowflakeConfigError,
    get_connection_params,
)


class TestGetConnectionParams:
    """Tests for get_connection_params()."""

    def test_raises_when_account_missing(self, monkeypatch):
        monkeypatch.delenv("SNOWFLAKE_ACCOUNT", raising=False)
        monkeypatch.setenv("SNOWFLAKE_USER", "u")
        monkeypatch.setenv("SNOWFLAKE_PASSWORD", "p")

        with pytest.raises(SnowflakeConfigError, match="SNOWFLAKE_ACCOUNT"):
            get_connection_params()

    def test_raises_when_user_missing(self, monkeypatch):
        monkeypatch.setenv("SNOWFLAKE_ACCOUNT", "a")
        monkeypatch.delenv("SNOWFLAKE_USER", raising=False)
        monkeypatch.setenv("SNOWFLAKE_PASSWORD", "p")

        with pytest.raises(SnowflakeConfigError, match="SNOWFLAKE_USER"):
            get_connection_params()

    def test_raises_when_no_auth_method_configured(self, monkeypatch):
        monkeypatch.setenv("SNOWFLAKE_ACCOUNT", "a")
        monkeypatch.setenv("SNOWFLAKE_USER", "u")
        monkeypatch.delenv("SNOWFLAKE_PASSWORD", raising=False)
        monkeypatch.delenv("SNOWFLAKE_PRIVATE_KEY_PATH", raising=False)
        monkeypatch.delenv("SNOWFLAKE_AUTHENTICATOR", raising=False)

        with pytest.raises(SnowflakeConfigError, match="No authentication method"):
            get_connection_params()

    def test_uses_password_auth(self, monkeypatch):
        monkeypatch.setenv("SNOWFLAKE_ACCOUNT", "a")
        monkeypatch.setenv("SNOWFLAKE_USER", "u")
        monkeypatch.setenv("SNOWFLAKE_PASSWORD", "secret")
        monkeypatch.delenv("SNOWFLAKE_PRIVATE_KEY_PATH", raising=False)
        monkeypatch.delenv("SNOWFLAKE_AUTHENTICATOR", raising=False)

        params = get_connection_params()
        assert params["password"] == "secret"
        assert "private_key" not in params

    def test_strips_none_values(self, monkeypatch):
        monkeypatch.setenv("SNOWFLAKE_ACCOUNT", "a")
        monkeypatch.setenv("SNOWFLAKE_USER", "u")
        monkeypatch.setenv("SNOWFLAKE_PASSWORD", "p")
        monkeypatch.delenv("SNOWFLAKE_WAREHOUSE", raising=False)

        params = get_connection_params()
        assert "warehouse" not in params

    def test_includes_statement_timeout(self, monkeypatch):
        monkeypatch.setenv("SNOWFLAKE_ACCOUNT", "a")
        monkeypatch.setenv("SNOWFLAKE_USER", "u")
        monkeypatch.setenv("SNOWFLAKE_PASSWORD", "p")
        monkeypatch.setenv("SNOWFLAKE_STATEMENT_TIMEOUT_SECONDS", "120")

        params = get_connection_params()
        assert params["session_parameters"]["STATEMENT_TIMEOUT_IN_SECONDS"] == 120


@pytest.mark.integration
class TestRealSnowflakeConnection:
    """Integration tests — require live credentials in .env. Skipped by default."""

    def test_can_connect(self):
        from python.connectors.snowflake_conn import snowflake_connection

        with snowflake_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                assert cur.fetchone()[0] == 1
