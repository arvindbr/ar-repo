"""Shared pytest fixtures."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def mock_snowflake_cursor():
    """A mock Snowflake cursor that supports the context manager protocol."""
    cursor = MagicMock()
    cursor.__enter__ = MagicMock(return_value=cursor)
    cursor.__exit__ = MagicMock(return_value=False)
    return cursor


@pytest.fixture
def mock_snowflake_connection(mock_snowflake_cursor):
    """A mock Snowflake connection that yields the mock cursor."""
    conn = MagicMock()
    conn.cursor.return_value = mock_snowflake_cursor
    conn.__enter__ = MagicMock(return_value=conn)
    conn.__exit__ = MagicMock(return_value=False)
    return conn
