# Claude Code Project Memory

This file is loaded automatically by Claude Code when working in this repository. It provides project-wide context that persists across all conversations.

## Project type
Snowflake data platform — SQL + Python + Snowpark

## Tech stack
- Snowflake (cloud data warehouse)
- Python 3.11+ with `snowflake-connector-python` and `snowflake-snowpark-python`
- pytest for testing
- GitHub Actions for CI
- (Optional) dbt, Airflow, Streamlit — see `boilerplates/`

## Skills available in this project

Read these on demand based on the task:

- `skills/snowflake-sql-author/SKILL.md` — SQL formatting, naming, idempotency
- `skills/snowflake-performance-tuner/SKILL.md` — query optimization, clustering, warehouse sizing
- `skills/snowflake-security-auditor/SKILL.md` — RBAC, masking, network policies
- `skills/snowflake-cost-optimizer/SKILL.md` — credit analysis, FinOps
- `skills/snowflake-data-modeler/SKILL.md` — dimensional modeling, SCD, grain

## Agents available

- `agents/etl-pipeline-builder/AGENT.md` — full source-to-mart pipeline
- `agents/query-optimizer/AGENT.md` — diagnose and rewrite slow queries
- `agents/schema-migrator/AGENT.md` — safe schema migrations
- `agents/data-quality-guardian/AGENT.md` — generate test suites

## Key conventions

- SQL: UPPERCASE keywords, snake_case identifiers, full schema qualification (`db.schema.table`)
- Python: PEP 8, type hints, context managers for connections, `logging` over `print`
- Naming: `stg_`, `dim_`, `fct_`, `v_`, `sp_`, `udf_`, `seq_`, `audit_` prefixes
- Auth: key-pair for service accounts, SSO for humans, no passwords in production
- Tests: mock connections in unit tests; `@pytest.mark.integration` for live tests

## Where things live

- `sql/ddl/` — table, view, schema definitions
- `sql/dml/` — inserts, updates, merges
- `sql/queries/` — analytical queries
- `sql/procedures/` — stored procs and UDFs
- `sql/migrations/` — versioned schema migrations
- `python/connectors/` — connection helpers (don't modify lightly)
- `python/etl/` — pipeline code
- `python/utils/` — shared helpers
- `boilerplates/` — starter templates for new components
- `tests/` — pytest suite mirroring `python/` layout

## What to do when uncertain

1. Read the relevant skill in `skills/`
2. Look at existing examples in `sql/` and `python/etl/`
3. Check `docs/ARCHITECTURE.md`
4. Ask the user — don't invent conventions

## What to never do

- Hardcode credentials anywhere
- Drop tables in production without explicit confirmation
- Use `SELECT *` in production code
- Skip the file header comment block
- Commit `.env`, `*.pem`, or `*.p8` files
