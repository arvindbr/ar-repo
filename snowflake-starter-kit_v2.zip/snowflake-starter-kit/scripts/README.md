# Scripts

Operational scripts for setting up and maintaining the Snowflake project.

| Script                       | Purpose                                          |
|------------------------------|--------------------------------------------------|
| `generate_key_pair.sh`       | Create an RSA key pair for key-pair auth         |
| `apply_migrations.py`        | Run pending schema migrations against Snowflake  |

## Setup script (run once per environment)

```bash
# Generate a key pair for your service account
./scripts/generate_key_pair.sh

# Apply all pending migrations
python scripts/apply_migrations.py --dry-run    # preview
python scripts/apply_migrations.py              # apply

# Verify connection
python python/connectors/test_connection.py
```

## Adding scripts

Operational scripts live here. Build/deploy scripts that belong to a specific boilerplate (e.g., dbt deploy, Snowpark deploy) live inside that boilerplate.
