#!/usr/bin/env bash
# ============================================================================
# Generate an RSA key pair for Snowflake key-pair authentication.
#
# Usage:
#   ./scripts/generate_key_pair.sh
#
# This produces:
#   ~/.snowflake/rsa_key.p8       — encrypted private key (keep secret!)
#   ~/.snowflake/rsa_key.pub      — public key (paste into Snowflake)
#
# After generating, register the public key with your Snowflake user:
#   ALTER USER my_user SET RSA_PUBLIC_KEY='<contents of rsa_key.pub minus headers>';
# ============================================================================

set -euo pipefail

KEY_DIR="${HOME}/.snowflake"
PRIVATE_KEY="${KEY_DIR}/rsa_key.p8"
PUBLIC_KEY="${KEY_DIR}/rsa_key.pub"

mkdir -p "${KEY_DIR}"
chmod 700 "${KEY_DIR}"

if [[ -f "${PRIVATE_KEY}" ]]; then
    echo "⚠️  Private key already exists at ${PRIVATE_KEY}"
    read -p "Overwrite? (y/N) " -r
    [[ $REPLY =~ ^[Yy]$ ]] || exit 0
fi

echo "🔑 Generating encrypted PKCS#8 private key (you'll be prompted for a passphrase)..."
openssl genrsa 2048 \
    | openssl pkcs8 -topk8 -inform PEM -out "${PRIVATE_KEY}" -v2 aes-256-cbc

chmod 600 "${PRIVATE_KEY}"

echo "🔓 Generating matching public key..."
openssl rsa -in "${PRIVATE_KEY}" -pubout -out "${PUBLIC_KEY}"
chmod 644 "${PUBLIC_KEY}"

echo ""
echo "✅ Done!"
echo ""
echo "Private key: ${PRIVATE_KEY}"
echo "Public key:  ${PUBLIC_KEY}"
echo ""
echo "Next steps:"
echo "1. Update your .env file:"
echo "   SNOWFLAKE_PRIVATE_KEY_PATH=${PRIVATE_KEY}"
echo "   SNOWFLAKE_PRIVATE_KEY_PASSPHRASE=<your passphrase>"
echo ""
echo "2. Register the public key in Snowflake (strip the BEGIN/END lines):"
echo ""
grep -v -- "-----" "${PUBLIC_KEY}" | tr -d '\n'
echo ""
echo ""
echo "   Run as a user with privileges (e.g., SECURITYADMIN):"
echo "   ALTER USER your_user SET RSA_PUBLIC_KEY='<paste the key above>';"
