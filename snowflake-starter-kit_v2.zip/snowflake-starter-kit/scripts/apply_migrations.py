"""Apply pending Snowflake migrations.

Reads sql/migrations/, compares to app_db.util.migration_log,
and runs only the new migrations in order.

Usage:
    python scripts/apply_migrations.py
    python scripts/apply_migrations.py --dry-run
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dotenv import load_dotenv

from python.connectors.snowflake_conn import snowflake_connection

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

MIGRATIONS_DIR = Path(__file__).resolve().parents[1] / "sql" / "migrations"


def list_migrations() -> list[Path]:
    """Return forward migration files in order, excluding rollbacks."""
    return sorted(
        p for p in MIGRATIONS_DIR.glob("V*.sql")
        if not p.name.endswith(".rollback.sql")
    )


def get_applied_versions(cursor) -> set[str]:
    """Read migration_log; create the table if it doesn't exist."""
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS app_db.util.migration_log (
            version       VARCHAR        NOT NULL,
            description   VARCHAR        NOT NULL,
            applied_at    TIMESTAMP_NTZ  NOT NULL,
            applied_by    VARCHAR        NOT NULL,
            CONSTRAINT pk_migration_log PRIMARY KEY (version)
        )
    """)
    cursor.execute("SELECT version FROM app_db.util.migration_log")
    return {row[0] for row in cursor.fetchall()}


def extract_version(path: Path) -> str:
    """Extract V0042 from V0042__add_email.sql."""
    return path.name.split("__", 1)[0]


def apply_migration(cursor, path: Path) -> None:
    sql = path.read_text()
    # Naive split on semicolons; works for most migrations
    statements = [s.strip() for s in sql.split(";") if s.strip() and not s.strip().startswith("--")]
    for stmt in statements:
        logger.info("  Executing: %s", stmt[:80].replace("\n", " "))
        cursor.execute(stmt)


def main() -> int:
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    all_migrations = list_migrations()
    if not all_migrations:
        logger.info("No migration files found in %s", MIGRATIONS_DIR)
        return 0

    with snowflake_connection() as conn, conn.cursor() as cur:
        applied = get_applied_versions(cur)
        pending = [p for p in all_migrations if extract_version(p) not in applied]

        if not pending:
            logger.info("All %d migrations already applied", len(all_migrations))
            return 0

        logger.info("Pending migrations: %d", len(pending))
        for path in pending:
            logger.info("  - %s", path.name)

        if args.dry_run:
            logger.info("Dry run — exiting without applying")
            return 0

        for path in pending:
            version = extract_version(path)
            logger.info("Applying %s...", path.name)
            try:
                apply_migration(cur, path)
                logger.info("✅ %s applied", version)
            except Exception:
                logger.exception("❌ %s failed", version)
                logger.error("Aborting — fix the migration or run rollback before retry")
                return 1

    logger.info("All pending migrations applied successfully")
    return 0


if __name__ == "__main__":
    sys.exit(main())
