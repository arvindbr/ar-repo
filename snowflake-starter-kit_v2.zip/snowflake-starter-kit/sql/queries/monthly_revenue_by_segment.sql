/*
 * File:        monthly_revenue_by_segment.sql
 * Purpose:     Monthly revenue and order counts grouped by customer segment.
 *              Suitable for executive dashboards and trend analysis.
 * Owner:       analytics-team
 * Dependencies: APP_DB.ANALYTICS.FCT_ORDERS, APP_DB.ANALYTICS.DIM_CUSTOMERS
 * Last modified: 2026-05-03
 */

WITH orders_with_segment AS (
    SELECT
        o.order_id,
        o.order_date,
        DATE_TRUNC('month', o.order_date) AS order_month,
        o.total_amount,
        c.customer_segment,
        c.country_code
    FROM APP_DB.ANALYTICS.FCT_ORDERS o
    INNER JOIN APP_DB.ANALYTICS.DIM_CUSTOMERS c
        ON o.customer_id = c.customer_id
        -- Use the dimension version that was active when the order was placed
        AND o.order_timestamp >= c.valid_from
        AND (o.order_timestamp < c.valid_to OR c.valid_to IS NULL)
    WHERE o.order_status = 'DELIVERED'
      AND o.order_date >= DATEADD(month, -12, CURRENT_DATE())
)
SELECT
    order_month,
    customer_segment,
    COUNT(DISTINCT order_id)              AS order_count,
    SUM(total_amount)                     AS revenue,
    AVG(total_amount)                     AS avg_order_value,
    -- Period-over-period using window functions
    LAG(SUM(total_amount)) OVER (
        PARTITION BY customer_segment
        ORDER BY order_month
    )                                     AS prev_month_revenue,
    SUM(total_amount) - LAG(SUM(total_amount)) OVER (
        PARTITION BY customer_segment
        ORDER BY order_month
    )                                     AS revenue_delta
FROM orders_with_segment
GROUP BY order_month, customer_segment
ORDER BY order_month DESC, revenue DESC;
