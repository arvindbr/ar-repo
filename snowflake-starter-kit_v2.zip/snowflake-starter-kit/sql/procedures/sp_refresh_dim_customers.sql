/*
 * File:        sp_refresh_dim_customers.sql
 * Purpose:     End-to-end refresh of dim_customers. Logs to audit table on
 *              success/failure and surfaces meaningful error messages.
 * Owner:       data-platform-team
 * Dependencies: APP_DB.STAGING.STG_CUSTOMERS, APP_DB.ANALYTICS.DIM_CUSTOMERS, APP_DB.UTIL.AUDIT_LOG
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE PROCEDURE APP_DB.UTIL.SP_REFRESH_DIM_CUSTOMERS(
    P_RUN_ID VARCHAR DEFAULT UUID_STRING()
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
COMMENT = 'Refreshes APP_DB.ANALYTICS.DIM_CUSTOMERS from staging. Returns a status message.'
AS
$$
DECLARE
    v_rows_affected NUMBER DEFAULT 0;
    v_error_msg     VARCHAR;
    v_started_at    TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
BEGIN
    -- Log start
    INSERT INTO APP_DB.UTIL.AUDIT_LOG (run_id, procedure_name, status, message, logged_at)
    VALUES (:P_RUN_ID, 'SP_REFRESH_DIM_CUSTOMERS', 'STARTED', 'Refresh started', CURRENT_TIMESTAMP());

    -- Validate that staging has fresh data
    LET v_staging_count NUMBER := (
        SELECT COUNT(*) FROM APP_DB.STAGING.STG_CUSTOMERS
    );
    IF (v_staging_count = 0) THEN
        v_error_msg := 'Staging table STG_CUSTOMERS is empty; aborting refresh.';
        INSERT INTO APP_DB.UTIL.AUDIT_LOG (run_id, procedure_name, status, message, logged_at)
        VALUES (:P_RUN_ID, 'SP_REFRESH_DIM_CUSTOMERS', 'FAILED', :v_error_msg, CURRENT_TIMESTAMP());
        RETURN 'FAILED: ' || v_error_msg;
    END IF;

    -- Run the merge (truncated example — full logic in sql/dml/merge_customers.sql)
    MERGE INTO APP_DB.ANALYTICS.DIM_CUSTOMERS target
    USING APP_DB.STAGING.STG_CUSTOMERS source
        ON target.customer_id = source.customer_id AND target.is_current = TRUE
    WHEN MATCHED THEN UPDATE SET target.email = source.email
    WHEN NOT MATCHED THEN INSERT (customer_id, email, valid_from, is_current)
        VALUES (source.customer_id, source.email, CURRENT_TIMESTAMP(), TRUE);

    v_rows_affected := SQLROWCOUNT;

    -- Log success
    INSERT INTO APP_DB.UTIL.AUDIT_LOG (run_id, procedure_name, status, message, rows_affected, logged_at)
    VALUES (
        :P_RUN_ID,
        'SP_REFRESH_DIM_CUSTOMERS',
        'SUCCESS',
        'Refresh completed in ' || DATEDIFF(second, :v_started_at, CURRENT_TIMESTAMP()) || ' seconds',
        :v_rows_affected,
        CURRENT_TIMESTAMP()
    );

    RETURN 'SUCCESS: ' || v_rows_affected || ' rows affected';

EXCEPTION
    WHEN OTHER THEN
        v_error_msg := 'Error: ' || SQLERRM || ' (code: ' || SQLCODE || ')';
        INSERT INTO APP_DB.UTIL.AUDIT_LOG (run_id, procedure_name, status, message, logged_at)
        VALUES (:P_RUN_ID, 'SP_REFRESH_DIM_CUSTOMERS', 'FAILED', :v_error_msg, CURRENT_TIMESTAMP());
        RETURN 'FAILED: ' || v_error_msg;
END;
$$;

-- Sample usage:
-- CALL APP_DB.UTIL.SP_REFRESH_DIM_CUSTOMERS();
-- CALL APP_DB.UTIL.SP_REFRESH_DIM_CUSTOMERS('manual-run-2026-05-03');
