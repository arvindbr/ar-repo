/*
 * File:        merge_customers.sql
 * Purpose:     Idempotent upsert from staging into the customer dimension.
 *              Designed to be re-run safely; uses a hash to detect changes.
 * Owner:       data-platform-team
 * Dependencies: APP_DB.STAGING.STG_CUSTOMERS, APP_DB.ANALYTICS.DIM_CUSTOMERS
 * Last modified: 2026-05-03
 */

MERGE INTO APP_DB.ANALYTICS.DIM_CUSTOMERS target
USING (
    SELECT
        customer_id,
        email,
        first_name,
        last_name,
        phone,
        country_code,
        customer_segment,
        signup_date,
        -- Hash of mutable attributes lets us detect actual changes
        HASH(email, first_name, last_name, phone, country_code, customer_segment) AS attr_hash
    FROM APP_DB.STAGING.STG_CUSTOMERS
    WHERE customer_id IS NOT NULL
) source
ON target.customer_id = source.customer_id
   AND target.is_current = TRUE
WHEN MATCHED
     AND HASH(target.email, target.first_name, target.last_name,
              target.phone, target.country_code, target.customer_segment) <> source.attr_hash
     THEN UPDATE SET
        target.is_current = FALSE,
        target.valid_to   = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT (
    customer_sk,
    customer_id,
    email,
    first_name,
    last_name,
    phone,
    country_code,
    customer_segment,
    signup_date,
    valid_from,
    valid_to,
    is_current,
    created_at
) VALUES (
    APP_DB.UTIL.SEQ_DIM_CUSTOMERS.NEXTVAL,
    source.customer_id,
    source.email,
    source.first_name,
    source.last_name,
    source.phone,
    source.country_code,
    source.customer_segment,
    source.signup_date,
    CURRENT_TIMESTAMP(),
    NULL,
    TRUE,
    CURRENT_TIMESTAMP()
);

-- After expiring rows above, insert new versions for changed customers
INSERT INTO APP_DB.ANALYTICS.DIM_CUSTOMERS (
    customer_sk, customer_id, email, first_name, last_name, phone,
    country_code, customer_segment, signup_date,
    valid_from, valid_to, is_current, created_at
)
SELECT
    APP_DB.UTIL.SEQ_DIM_CUSTOMERS.NEXTVAL,
    s.customer_id,
    s.email,
    s.first_name,
    s.last_name,
    s.phone,
    s.country_code,
    s.customer_segment,
    s.signup_date,
    CURRENT_TIMESTAMP(),
    NULL,
    TRUE,
    CURRENT_TIMESTAMP()
FROM APP_DB.STAGING.STG_CUSTOMERS s
WHERE EXISTS (
    SELECT 1
    FROM APP_DB.ANALYTICS.DIM_CUSTOMERS d
    WHERE d.customer_id = s.customer_id
      AND d.is_current = FALSE
      AND d.valid_to >= DATEADD(minute, -1, CURRENT_TIMESTAMP())
);
