/*
 * File:        dim_date.sql
 * Purpose:     Conformed date dimension covering 2000-01-01 through 2050-12-31.
 *              Generated once and never updated. Used by every fact table.
 * Owner:       data-platform-team
 * Dependencies: None
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE TABLE app_db.analytics.dim_date (
    date_key            NUMBER(8,0)    NOT NULL  COMMENT 'YYYYMMDD as integer',
    full_date           DATE           NOT NULL  COMMENT 'The date itself',
    day_of_week_number  NUMBER(1,0)    NOT NULL  COMMENT '1=Monday, 7=Sunday (ISO 8601)',
    day_of_week_name    VARCHAR(9)     NOT NULL  COMMENT 'Monday, Tuesday, ...',
    day_of_month        NUMBER(2,0)    NOT NULL,
    day_of_year         NUMBER(3,0)    NOT NULL,
    week_of_year        NUMBER(2,0)    NOT NULL  COMMENT 'ISO 8601 week number',
    month_number        NUMBER(2,0)    NOT NULL,
    month_name          VARCHAR(9)     NOT NULL,
    quarter_number      NUMBER(1,0)    NOT NULL,
    year_number         NUMBER(4,0)    NOT NULL,
    is_weekend          BOOLEAN        NOT NULL,
    is_us_holiday       BOOLEAN        NOT NULL  DEFAULT FALSE,
    fiscal_year         NUMBER(4,0)    NOT NULL  COMMENT 'Fiscal year starting Feb 1',
    fiscal_quarter      NUMBER(1,0)    NOT NULL,
    iso_year_week       VARCHAR(8)     NOT NULL  COMMENT 'YYYY-Www',
    relative_day_label  VARCHAR(20)    NOT NULL  COMMENT 'Today, Yesterday, etc.',

    CONSTRAINT pk_dim_date PRIMARY KEY (date_key)
)
CLUSTER BY (year_number, month_number)
COMMENT = 'Conformed date dimension. Join on date_key (YYYYMMDD) or full_date.';

-- Populate via a recursive generator
INSERT INTO app_db.analytics.dim_date
WITH dates AS (
    SELECT DATEADD(day, ROW_NUMBER() OVER (ORDER BY 0) - 1, DATE '2000-01-01')::DATE AS d
    FROM TABLE(GENERATOR(ROWCOUNT => 18628))    -- ~51 years
)
SELECT
    TO_NUMBER(TO_CHAR(d, 'YYYYMMDD'))                       AS date_key,
    d                                                       AS full_date,
    DAYOFWEEKISO(d)                                         AS day_of_week_number,
    DAYNAME(d)                                              AS day_of_week_name,
    DAY(d)                                                  AS day_of_month,
    DAYOFYEAR(d)                                            AS day_of_year,
    WEEKISO(d)                                              AS week_of_year,
    MONTH(d)                                                AS month_number,
    MONTHNAME(d)                                            AS month_name,
    QUARTER(d)                                              AS quarter_number,
    YEAR(d)                                                 AS year_number,
    DAYOFWEEKISO(d) IN (6, 7)                               AS is_weekend,
    FALSE                                                   AS is_us_holiday,    -- populate via a separate UPDATE
    CASE WHEN MONTH(d) >= 2 THEN YEAR(d) ELSE YEAR(d) - 1 END AS fiscal_year,
    CASE
        WHEN MONTH(d) IN (2, 3, 4)   THEN 1
        WHEN MONTH(d) IN (5, 6, 7)   THEN 2
        WHEN MONTH(d) IN (8, 9, 10)  THEN 3
        ELSE 4
    END                                                     AS fiscal_quarter,
    YEAROFWEEKISO(d) || '-W' || LPAD(WEEKISO(d)::VARCHAR, 2, '0') AS iso_year_week,
    CASE
        WHEN d = CURRENT_DATE() THEN 'Today'
        WHEN d = DATEADD(day, -1, CURRENT_DATE()) THEN 'Yesterday'
        WHEN d = DATEADD(day, 1, CURRENT_DATE())  THEN 'Tomorrow'
        WHEN d BETWEEN DATEADD(day, -7, CURRENT_DATE()) AND CURRENT_DATE() THEN 'Last 7 days'
        WHEN d BETWEEN DATEADD(day, -30, CURRENT_DATE()) AND CURRENT_DATE() THEN 'Last 30 days'
        ELSE TO_CHAR(d, 'YYYY-MM-DD')
    END                                                     AS relative_day_label
FROM dates;
