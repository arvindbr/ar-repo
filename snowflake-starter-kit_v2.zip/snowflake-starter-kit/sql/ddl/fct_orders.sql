/*
 * File:        fct_orders.sql
 * Purpose:     Fact table for completed customer orders.
 *              One row per order; line-item detail lives in fct_order_items.
 * Owner:       data-platform-team
 * Dependencies: dim_customers, dim_products
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE TABLE APP_DB.ANALYTICS.FCT_ORDERS (
    order_id            NUMBER(38,0)    NOT NULL  COMMENT 'Surrogate key',
    order_natural_key   VARCHAR         NOT NULL  COMMENT 'Source-system order ID',
    customer_id         NUMBER(38,0)    NOT NULL  COMMENT 'FK to dim_customers',
    order_date          DATE            NOT NULL  COMMENT 'Date the order was placed',
    order_timestamp     TIMESTAMP_NTZ   NOT NULL  COMMENT 'Exact moment of order placement',
    order_status        VARCHAR(20)     NOT NULL  COMMENT 'PENDING|CONFIRMED|SHIPPED|DELIVERED|CANCELLED',
    currency_code       VARCHAR(3)      NOT NULL  COMMENT 'ISO 4217 currency code',
    subtotal_amount     NUMBER(18,4)    NOT NULL  COMMENT 'Sum of line items, pre-tax',
    tax_amount          NUMBER(18,4)    NOT NULL  COMMENT 'Total tax applied',
    shipping_amount     NUMBER(18,4)    NOT NULL  COMMENT 'Shipping charges',
    discount_amount     NUMBER(18,4)    NOT NULL  DEFAULT 0  COMMENT 'Discounts applied',
    total_amount        NUMBER(18,4)    NOT NULL  COMMENT 'Grand total charged to customer',
    payment_method      VARCHAR(30)               COMMENT 'CARD|PAYPAL|BANK_TRANSFER|...',
    shipping_country    VARCHAR(2)                COMMENT 'ISO 3166-1 alpha-2',
    is_first_order      BOOLEAN         NOT NULL  DEFAULT FALSE  COMMENT 'TRUE if this customer''s first order',
    source_system       VARCHAR(50)     NOT NULL  COMMENT 'System of record identifier',
    -- Audit columns
    created_at          TIMESTAMP_NTZ   NOT NULL  DEFAULT CURRENT_TIMESTAMP()  COMMENT 'Row creation time in this table',
    updated_at          TIMESTAMP_NTZ   NOT NULL  DEFAULT CURRENT_TIMESTAMP()  COMMENT 'Row last modified time',
    loaded_by_run_id    VARCHAR                  COMMENT 'ETL run identifier for lineage',

    CONSTRAINT pk_fct_orders PRIMARY KEY (order_id)
)
CLUSTER BY (order_date, customer_id)
COMMENT = 'Fact table of customer orders. One row per order header. Grain: order_id.';
