/*
 * File:        audit_log.sql
 * Purpose:     Central audit log for ETL runs and stored procedure executions.
 *              Every pipeline writes start/success/failure events here.
 * Owner:       data-platform-team
 * Dependencies: APP_DB.UTIL schema
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE TABLE APP_DB.UTIL.AUDIT_LOG (
    log_id              NUMBER(38,0)   IDENTITY(1,1)  COMMENT 'Auto-generated row ID',
    run_id              VARCHAR        NOT NULL  COMMENT 'Logical run identifier (UUID or business ID)',
    procedure_name      VARCHAR        NOT NULL  COMMENT 'Name of the procedure or pipeline',
    status              VARCHAR(20)    NOT NULL  COMMENT 'STARTED|SUCCESS|FAILED|WARNING',
    message             VARCHAR        NOT NULL  COMMENT 'Human-readable description',
    rows_affected       NUMBER(38,0)             COMMENT 'Optional row count metric',
    duration_seconds    NUMBER(18,3)             COMMENT 'Optional execution time',
    logged_at           TIMESTAMP_NTZ  NOT NULL  DEFAULT CURRENT_TIMESTAMP()  COMMENT 'When this event was logged',
    logged_by           VARCHAR        NOT NULL  DEFAULT CURRENT_USER()  COMMENT 'Snowflake user that wrote the row',

    CONSTRAINT pk_audit_log PRIMARY KEY (log_id)
)
CLUSTER BY (logged_at, procedure_name)
COMMENT = 'Audit trail for all ETL runs. Query by run_id to trace a single pipeline execution.';
