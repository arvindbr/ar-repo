/*
 * File:        masking_policies.sql
 * Purpose:     Reusable dynamic data masking policies for PII columns.
 *              Apply via ALTER TABLE ... MODIFY COLUMN ... SET MASKING POLICY.
 * Owner:       security-team
 * Dependencies: APP_DB.UTIL schema, role APP_PII_READER
 * Last modified: 2026-05-03
 */

-- ============================================================================
-- Email — show full to authorized roles, mask local-part otherwise
-- ============================================================================
CREATE OR REPLACE MASKING POLICY app_db.util.mask_email AS (val VARCHAR) RETURNS VARCHAR ->
    CASE
        WHEN CURRENT_ROLE() IN ('ACCOUNTADMIN', 'APP_ADMIN', 'APP_PII_READER') THEN val
        WHEN val IS NULL THEN NULL
        WHEN POSITION('@' IN val) > 0 THEN '*****' || SUBSTR(val, POSITION('@' IN val))
        ELSE '*****'
    END;

-- ============================================================================
-- Phone — show last 4 digits otherwise
-- ============================================================================
CREATE OR REPLACE MASKING POLICY app_db.util.mask_phone AS (val VARCHAR) RETURNS VARCHAR ->
    CASE
        WHEN CURRENT_ROLE() IN ('ACCOUNTADMIN', 'APP_ADMIN', 'APP_PII_READER') THEN val
        WHEN val IS NULL THEN NULL
        WHEN LENGTH(val) >= 4 THEN '***-***-' || RIGHT(val, 4)
        ELSE '****'
    END;

-- ============================================================================
-- Full name — show only first initial otherwise
-- ============================================================================
CREATE OR REPLACE MASKING POLICY app_db.util.mask_name AS (val VARCHAR) RETURNS VARCHAR ->
    CASE
        WHEN CURRENT_ROLE() IN ('ACCOUNTADMIN', 'APP_ADMIN', 'APP_PII_READER') THEN val
        WHEN val IS NULL THEN NULL
        ELSE LEFT(val, 1) || '.'
    END;

-- ============================================================================
-- Credit card — show only last 4 digits, never the full number
-- ============================================================================
CREATE OR REPLACE MASKING POLICY app_db.util.mask_credit_card AS (val VARCHAR) RETURNS VARCHAR ->
    CASE
        WHEN val IS NULL THEN NULL
        WHEN LENGTH(REGEXP_REPLACE(val, '[^0-9]', '')) >= 4
            THEN 'XXXX-XXXX-XXXX-' || RIGHT(REGEXP_REPLACE(val, '[^0-9]', ''), 4)
        ELSE 'XXXX'
    END;
-- Note: even ACCOUNTADMIN cannot see full PAN — store only last 4 digits at rest

-- ============================================================================
-- Apply policies to existing columns
-- ============================================================================
-- ALTER TABLE app_db.analytics.dim_customers MODIFY COLUMN email SET MASKING POLICY app_db.util.mask_email;
-- ALTER TABLE app_db.analytics.dim_customers MODIFY COLUMN phone SET MASKING POLICY app_db.util.mask_phone;
-- ALTER TABLE app_db.analytics.dim_customers MODIFY COLUMN first_name SET MASKING POLICY app_db.util.mask_name;
-- ALTER TABLE app_db.analytics.dim_customers MODIFY COLUMN last_name SET MASKING POLICY app_db.util.mask_name;
