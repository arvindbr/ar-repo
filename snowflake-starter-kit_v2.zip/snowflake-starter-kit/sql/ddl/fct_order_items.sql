/*
 * File:        fct_order_items.sql
 * Purpose:     Line-item grain fact table.
 *              One row per item per order; total quantities and amounts.
 * Owner:       data-platform-team
 * Dependencies: fct_orders, dim_products, dim_customers
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE TABLE app_db.analytics.fct_order_items (
    order_item_id       NUMBER(38,0)   NOT NULL  COMMENT 'Surrogate key',
    order_id            NUMBER(38,0)   NOT NULL  COMMENT 'FK to fct_orders',
    customer_id         NUMBER(38,0)   NOT NULL  COMMENT 'FK to dim_customers (denormalized for performance)',
    product_id          NUMBER(38,0)   NOT NULL  COMMENT 'FK to dim_products',
    line_number         NUMBER(10,0)   NOT NULL  COMMENT 'Position of the item within the order, starting at 1',
    order_date          DATE           NOT NULL  COMMENT 'Order date (denormalized for partition pruning)',
    quantity            NUMBER(18,4)   NOT NULL  COMMENT 'Units ordered',
    unit_price          NUMBER(18,4)   NOT NULL  COMMENT 'Price per unit at time of order (excludes tax)',
    line_subtotal       NUMBER(18,4)   NOT NULL  COMMENT 'quantity * unit_price',
    line_discount       NUMBER(18,4)   NOT NULL  DEFAULT 0  COMMENT 'Discount applied to this line',
    line_tax            NUMBER(18,4)   NOT NULL  DEFAULT 0  COMMENT 'Tax on this line',
    line_total          NUMBER(18,4)   NOT NULL  COMMENT 'subtotal - discount + tax',
    currency_code       VARCHAR(3)     NOT NULL  COMMENT 'ISO 4217 currency code',
    is_gift             BOOLEAN        NOT NULL  DEFAULT FALSE,
    -- Audit
    created_at          TIMESTAMP_NTZ  NOT NULL  DEFAULT CURRENT_TIMESTAMP(),
    updated_at          TIMESTAMP_NTZ  NOT NULL  DEFAULT CURRENT_TIMESTAMP(),
    loaded_by_run_id    VARCHAR,

    CONSTRAINT pk_fct_order_items PRIMARY KEY (order_item_id),
    CONSTRAINT uk_fct_order_items UNIQUE (order_id, line_number)
)
CLUSTER BY (order_date, product_id)
COMMENT = 'Line-item grain orders fact. Sum line_total to reconcile with fct_orders.subtotal_amount.';
