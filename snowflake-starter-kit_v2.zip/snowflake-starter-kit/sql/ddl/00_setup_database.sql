/*
 * File:        00_setup_database.sql
 * Purpose:     Create the database, schemas, warehouses, and roles for this project.
 *              Run this ONCE as ACCOUNTADMIN when bootstrapping a new environment.
 * Owner:       data-platform-team
 * Dependencies: None
 * Last modified: 2026-05-03
 */

USE ROLE ACCOUNTADMIN;

-- ============================================================================
-- Database & Schemas
-- ============================================================================
CREATE DATABASE IF NOT EXISTS APP_DB
    COMMENT = 'Primary application database';

USE DATABASE APP_DB;

CREATE SCHEMA IF NOT EXISTS RAW
    COMMENT = 'Raw landing zone for ingested data';

CREATE SCHEMA IF NOT EXISTS STAGING
    COMMENT = 'Cleansed and conformed data, pre-modeling';

CREATE SCHEMA IF NOT EXISTS ANALYTICS
    COMMENT = 'Curated marts for BI and reporting';

CREATE SCHEMA IF NOT EXISTS UTIL
    COMMENT = 'Utility objects: procedures, UDFs, audit tables';

-- ============================================================================
-- Warehouses (right-size for your workload — XS is fine for dev)
-- ============================================================================
CREATE WAREHOUSE IF NOT EXISTS APP_WH_XS
    WAREHOUSE_SIZE = 'XSMALL'
    AUTO_SUSPEND = 60
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Small warehouse for interactive queries and dev';

CREATE WAREHOUSE IF NOT EXISTS APP_WH_LOAD
    WAREHOUSE_SIZE = 'SMALL'
    AUTO_SUSPEND = 60
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Dedicated warehouse for ETL loads';

-- ============================================================================
-- Roles (functional roles, not user roles)
-- ============================================================================
CREATE ROLE IF NOT EXISTS APP_DEVELOPER
    COMMENT = 'Read/write access to dev schemas';

CREATE ROLE IF NOT EXISTS APP_ANALYST
    COMMENT = 'Read-only access to ANALYTICS schema';

CREATE ROLE IF NOT EXISTS APP_LOADER
    COMMENT = 'Service account role for ETL pipelines';

-- ============================================================================
-- Grants
-- ============================================================================
GRANT USAGE ON DATABASE APP_DB TO ROLE APP_DEVELOPER;
GRANT USAGE ON ALL SCHEMAS IN DATABASE APP_DB TO ROLE APP_DEVELOPER;
GRANT ALL PRIVILEGES ON SCHEMA APP_DB.STAGING TO ROLE APP_DEVELOPER;
GRANT ALL PRIVILEGES ON SCHEMA APP_DB.ANALYTICS TO ROLE APP_DEVELOPER;
GRANT USAGE ON WAREHOUSE APP_WH_XS TO ROLE APP_DEVELOPER;

GRANT USAGE ON DATABASE APP_DB TO ROLE APP_ANALYST;
GRANT USAGE ON SCHEMA APP_DB.ANALYTICS TO ROLE APP_ANALYST;
GRANT SELECT ON ALL TABLES IN SCHEMA APP_DB.ANALYTICS TO ROLE APP_ANALYST;
GRANT SELECT ON FUTURE TABLES IN SCHEMA APP_DB.ANALYTICS TO ROLE APP_ANALYST;
GRANT USAGE ON WAREHOUSE APP_WH_XS TO ROLE APP_ANALYST;

GRANT USAGE ON DATABASE APP_DB TO ROLE APP_LOADER;
GRANT USAGE ON SCHEMA APP_DB.RAW TO ROLE APP_LOADER;
GRANT INSERT, SELECT ON ALL TABLES IN SCHEMA APP_DB.RAW TO ROLE APP_LOADER;
GRANT INSERT, SELECT ON FUTURE TABLES IN SCHEMA APP_DB.RAW TO ROLE APP_LOADER;
GRANT USAGE ON WAREHOUSE APP_WH_LOAD TO ROLE APP_LOADER;
