/*
 * File:        dim_customers.sql
 * Purpose:     Type 2 slowly-changing dimension for customers.
 *              Tracks history of customer attributes over time.
 * Owner:       data-platform-team
 * Dependencies: stg_customers
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE TABLE APP_DB.ANALYTICS.DIM_CUSTOMERS (
    customer_sk         NUMBER(38,0)    NOT NULL  COMMENT 'Surrogate key (changes per SCD2 version)',
    customer_id         NUMBER(38,0)    NOT NULL  COMMENT 'Stable business key',
    email               VARCHAR                   COMMENT 'Customer email (PII — apply masking policy)',
    first_name          VARCHAR                   COMMENT 'PII',
    last_name           VARCHAR                   COMMENT 'PII',
    phone               VARCHAR                   COMMENT 'PII — apply masking policy',
    country_code        VARCHAR(2)                COMMENT 'ISO 3166-1 alpha-2',
    customer_segment    VARCHAR(30)               COMMENT 'NEW|RETURNING|VIP|CHURNED',
    signup_date         DATE                      COMMENT 'Original signup date (does not change)',
    -- SCD2 metadata
    valid_from          TIMESTAMP_NTZ   NOT NULL  COMMENT 'When this version became active',
    valid_to            TIMESTAMP_NTZ             COMMENT 'When this version was superseded; NULL = current',
    is_current          BOOLEAN         NOT NULL  COMMENT 'TRUE for the active version of each customer',
    -- Audit
    created_at          TIMESTAMP_NTZ   NOT NULL  DEFAULT CURRENT_TIMESTAMP(),
    loaded_by_run_id    VARCHAR,

    CONSTRAINT pk_dim_customers PRIMARY KEY (customer_sk)
)
CLUSTER BY (customer_id, valid_from)
COMMENT = 'Type 2 SCD for customers. Use is_current = TRUE for point-in-time reporting.';
