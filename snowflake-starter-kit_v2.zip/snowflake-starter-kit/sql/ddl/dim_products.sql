/*
 * File:        dim_products.sql
 * Purpose:     Product dimension. Type 1 SCD (no history kept) — product
 *              catalog changes are infrequent and historical accuracy on
 *              attributes like description is not business-critical.
 * Owner:       data-platform-team
 * Dependencies: stg_products
 * Last modified: 2026-05-03
 */

CREATE OR REPLACE TABLE app_db.analytics.dim_products (
    product_id          NUMBER(38,0)   NOT NULL  COMMENT 'Stable business key',
    sku                 VARCHAR(50)    NOT NULL  COMMENT 'Stock-keeping unit',
    product_name        VARCHAR        NOT NULL  COMMENT 'Display name',
    product_description VARCHAR                  COMMENT 'Long-form description',
    category            VARCHAR(100)             COMMENT 'Top-level category',
    subcategory         VARCHAR(100)             COMMENT 'Second-level category',
    brand               VARCHAR(100)             COMMENT 'Brand name',
    list_price          NUMBER(18,4)             COMMENT 'Current list price',
    currency_code       VARCHAR(3)     NOT NULL  DEFAULT 'USD',
    weight_grams        NUMBER(18,4)             COMMENT 'Shipping weight',
    is_active           BOOLEAN        NOT NULL  DEFAULT TRUE  COMMENT 'TRUE if currently sellable',
    launched_on         DATE                     COMMENT 'Date first made available',
    discontinued_on     DATE                     COMMENT 'Date marked end-of-life; NULL if active',
    -- Audit
    created_at          TIMESTAMP_NTZ  NOT NULL  DEFAULT CURRENT_TIMESTAMP(),
    updated_at          TIMESTAMP_NTZ  NOT NULL  DEFAULT CURRENT_TIMESTAMP(),
    loaded_by_run_id    VARCHAR,

    CONSTRAINT pk_dim_products PRIMARY KEY (product_id),
    CONSTRAINT uk_dim_products_sku UNIQUE (sku)
)
COMMENT = 'Product catalog. Type 1 SCD — overwrites in place.';

-- Unknown member row
INSERT INTO app_db.analytics.dim_products (
    product_id, sku, product_name, currency_code, is_active
)
VALUES (-1, 'UNKNOWN', '(unknown product)', 'USD', FALSE);
