/*
 * File:        resource_monitors.sql
 * Purpose:     Resource monitors to enforce credit caps and prevent runaway costs.
 *              One per workload, plus an account-level safety net.
 * Owner:       finops-team
 * Dependencies: warehouses created in 00_setup_database.sql
 * Last modified: 2026-05-03
 */

USE ROLE ACCOUNTADMIN;

-- ============================================================================
-- Account-level safety net — last line of defense
-- ============================================================================
CREATE OR REPLACE RESOURCE MONITOR rm_account_monthly
    WITH CREDIT_QUOTA = 50000
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    NOTIFY_USERS = ('finops_admin')
    TRIGGERS
        ON 75  PERCENT DO NOTIFY
        ON 90  PERCENT DO NOTIFY
        ON 100 PERCENT DO NOTIFY;
-- Note: account-level monitor cannot SUSPEND. Use per-warehouse monitors for that.

ALTER ACCOUNT SET RESOURCE_MONITOR = rm_account_monthly;

-- ============================================================================
-- ETL workload — predictable, suspend at hard cap
-- ============================================================================
CREATE OR REPLACE RESOURCE MONITOR rm_etl_monthly
    WITH CREDIT_QUOTA = 5000
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    NOTIFY_USERS = ('data_platform_admin')
    TRIGGERS
        ON 75  PERCENT DO NOTIFY
        ON 90  PERCENT DO NOTIFY
        ON 100 PERCENT DO SUSPEND
        ON 110 PERCENT DO SUSPEND_IMMEDIATE;

ALTER WAREHOUSE app_wh_load SET RESOURCE_MONITOR = rm_etl_monthly;

-- ============================================================================
-- BI / interactive — bursty, notify but don't suspend
-- ============================================================================
CREATE OR REPLACE RESOURCE MONITOR rm_bi_monthly
    WITH CREDIT_QUOTA = 8000
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    NOTIFY_USERS = ('analytics_admin')
    TRIGGERS
        ON 80  PERCENT DO NOTIFY
        ON 100 PERCENT DO NOTIFY;

ALTER WAREHOUSE app_wh_xs SET RESOURCE_MONITOR = rm_bi_monthly;

-- ============================================================================
-- Dev sandbox — suspend at cap, low quota
-- ============================================================================
CREATE OR REPLACE RESOURCE MONITOR rm_dev_monthly
    WITH CREDIT_QUOTA = 500
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    NOTIFY_USERS = ('data_platform_admin')
    TRIGGERS
        ON 75  PERCENT DO NOTIFY
        ON 100 PERCENT DO SUSPEND_IMMEDIATE;

-- Apply to any sandbox warehouses you create
-- ALTER WAREHOUSE my_sandbox_wh SET RESOURCE_MONITOR = rm_dev_monthly;
