# Contributing

Thanks for considering contributing! This kit is meant to be forked and customized — but if you want to upstream improvements, here's how.

## Ground rules

- All contributions must work with the conventions in `.github/copilot-instructions.md`. If your change requires breaking a convention, discuss in an issue first.
- New skills, agents, or boilerplates need a clear use case described in the PR.
- Documentation is required for new public features. Code without docs gets rejected.

## Workflow

1. Open an issue describing what you want to change
2. Fork and create a feature branch: `feature/<short-name>`
3. Make your changes
4. Run `make lint test` locally
5. Open a PR with:
   - A summary of what changed and why
   - Screenshots if UI/output changed
   - A note about backward compatibility

## Adding a new skill

1. Create `skills/<your-skill>/SKILL.md`
2. Frontmatter must include `name`, `description`, `version`
3. The `description` field is what AI assistants use to route — be specific
4. Keep skills under 500 lines; longer means it's two skills
5. Add a row to the table in `skills/README.md`
6. Reference from `CLAUDE.md` and the main README

## Adding a new agent

1. Create `agents/<your-agent>/AGENT.md`
2. Frontmatter must include `name`, `description`, `tools`, `model`
3. Document inputs, outputs, and quality bar explicitly
4. Reference relevant skills rather than duplicating their content
5. Add a row to the table in `agents/README.md`

## Adding a new boilerplate

1. Create `boilerplates/<name>/`
2. Include a `README.md` with: what it is, setup steps, conventions
3. Make it independent — should work standalone, copied out of the kit
4. Add to `boilerplates/README.md`

## Coding standards

- Python: PEP 8, type hints, Google docstrings, `make lint` clean
- SQL: project conventions in `skills/snowflake-sql-author/SKILL.md`
- Markdown: prose paragraphs, minimal nesting, no marketing language

## Testing

- Unit tests: `make test-unit` — must pass
- Integration tests: `make test-integration` — optional, requires Snowflake creds
- New features need at least one test

## What we won't merge

- Changes that hardcode credentials anywhere
- Changes that drop existing features without a migration path
- Untested code
- Skills/agents that duplicate existing ones — improve the existing one instead

## Questions

Open a discussion on GitHub.
