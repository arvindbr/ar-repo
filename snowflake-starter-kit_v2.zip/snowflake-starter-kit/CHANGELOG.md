# Changelog

All notable changes to this starter kit. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Six skill packs (`skills/`) with frontmatter for AI-assistant routing
- Five agents (`agents/`) with explicit input/output contracts
- Six boilerplates (`boilerplates/dbt`, `streamlit`, `airflow`, `snowpark-app`, `data-quality`, `cicd`)
- Path-scoped Copilot instructions (`.github/instructions/`)
- Three chat modes (`.github/chatmodes/`): DBA, analytics-engineer, FinOps
- Claude Code memory file (`CLAUDE.md`) and slash commands (`.claude/commands/`)
- File templates for fact tables, SCD2 dimensions, stored procedures, migrations, ETL pipelines, tests, DQ checks
- Sample DDL: `fct_orders`, `fct_order_items`, `dim_customers`, `dim_products`, `dim_date`
- Sample masking policies and resource monitors
- Migration runner script (`scripts/apply_migrations.py`)
- Onboarding doc, ADR template, model documentation
- Makefile with common commands
- `.editorconfig` for consistent formatting across editors
- `SECURITY.md` with secrets-handling guidance

### Changed
- Expanded README with full feature index
- Reorganized to surface AI-assistance content at the top level

## [0.1.0] - 2026-05-03

### Added
- Initial release
- Python connector helpers (password, key-pair, SSO)
- VS Code config (extensions, settings, tasks, debug)
- Basic SQL DDL examples
- pytest setup with mock fixtures
- GitHub Actions CI workflow
- Jupyter notebook template
- Key-pair generation script
