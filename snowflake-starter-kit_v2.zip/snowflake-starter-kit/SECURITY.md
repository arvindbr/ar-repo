# Security Policy

## Reporting a vulnerability

If you discover a security issue with this template, open a private security advisory rather than a public issue.

## Secrets handling

This kit is designed assuming you will **never** commit secrets. Specifically:

### What's safe to commit
- `.env.example` — template, placeholder values only
- `boilerplates/dbt/profiles.yml.example` — same
- Public keys (`*.pub`)
- Configuration that references env vars

### What must never be committed
- `.env` files (any kind)
- Private keys (`*.pem`, `*.p8`, `*.key`)
- Snowflake passwords or tokens
- Personal access tokens
- OAuth client secrets
- Service-account credentials

The included `.gitignore` excludes all of the above. If you find yourself fighting the gitignore, you are about to make a mistake.

## Authentication recommendations

For each environment:

| Environment      | Auth method                          |
|------------------|--------------------------------------|
| Local dev        | SSO (`externalbrowser`)              |
| CI               | Key-pair, key in GitHub Actions secret |
| Staging          | Key-pair                             |
| Production       | Key-pair, with mandatory key rotation |

Never use passwords for service accounts. Never share private keys between environments.

## Key rotation

- Service-account private keys: rotate every 90 days
- Use `RSA_PUBLIC_KEY_2` to overlap old and new keys during rotation
- The `.github/workflows/key-rotation-reminder.yml` workflow opens an issue 30 days before expiry

## RBAC defaults

The starter setup creates these roles:

- `APP_DEVELOPER` — read/write on dev schemas
- `APP_LOADER` — insert/select on RAW
- `APP_ANALYST` — read-only on ANALYTICS

Never grant `ACCOUNTADMIN` for daily work. Never grant privileges directly to users — always go through functional roles.

## PII protection

If you handle PII:

1. Tag PII columns with the `pii_classification` tag
2. Apply masking policies to those columns
3. Audit access via `snowflake.account_usage.access_history`
4. Restrict the `PII_READER` role to a small allowlist

See `skills/snowflake-security-auditor/SKILL.md` for the full playbook.

## CI/CD secrets

GitHub Actions secrets needed:

- `SNOWFLAKE_ACCOUNT`
- `SNOWFLAKE_USER_CI` and `SNOWFLAKE_USER_PROD`
- `SNOWFLAKE_PRIVATE_KEY_CI` and `SNOWFLAKE_PRIVATE_KEY_PROD`
- `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE_CI` and `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE_PROD`
- `SLACK_WEBHOOK_URL`

Use GitHub Environments to scope secrets to specific deploy targets, and require approval for the prod environment.

## Audit log retention

The kit creates an `app_db.util.audit_log` table that captures every procedure run. Treat this table as compliance evidence: do not truncate it without a documented retention policy.
