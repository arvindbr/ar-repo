# Onboarding: Analytics Engineer

Day-one through week-one checklist for someone joining the data platform team. Estimated time: 6–8 hours over 3 days.

## Day 1 — Get connected (2–3 hours)

- [ ] Get a Snowflake user account from the SSO admin
- [ ] Get added to `APP_DEVELOPER` role
- [ ] Clone this repo locally
- [ ] Install Python 3.11+ and create a virtual environment:
  ```bash
  python -m venv .venv && source .venv/bin/activate
  pip install -r requirements-dev.txt
  ```
- [ ] Copy `.env.example` to `.env` and fill in values (use SSO authenticator)
- [ ] Run `python python/connectors/test_connection.py` — should print session details
- [ ] Open the project in VS Code, accept recommended extensions
- [ ] Sign in to GitHub Copilot (if licensed)

## Day 2 — Read and explore (2–3 hours)

- [ ] Read `README.md` end-to-end
- [ ] Read `docs/ARCHITECTURE.md`
- [ ] Skim `skills/snowflake-sql-author/SKILL.md` and `skills/snowflake-data-modeler/SKILL.md`
- [ ] Browse the sample tables:
  ```sql
  SELECT TOP 10 * FROM app_db.analytics.fct_orders;
  SELECT TOP 10 * FROM app_db.analytics.dim_customers WHERE is_current = TRUE;
  ```
- [ ] Open `notebooks/01_explore_data.ipynb` and run all cells
- [ ] Read `docs/models/fct_orders.md` and `docs/adr/0001-star-schema.md`

## Day 3 — Make a small change (2 hours)

- [ ] Pick a small task from the team backlog (or ask your buddy for one)
- [ ] Create a feature branch: `feature/<your-name>-<short-desc>`
- [ ] Make the change following project conventions
- [ ] Run tests: `make test-unit`
- [ ] Run linters: `make lint`
- [ ] Open a PR; CI will run additional checks
- [ ] Get review from your buddy

## Week 1 — Ship a real feature

- [ ] Pick up a real ticket
- [ ] Use the appropriate agent for the task type:
  - New table → `agents/etl-pipeline-builder`
  - Schema change → `agents/schema-migrator`
  - Slow query → `agents/query-optimizer`
- [ ] Update or create model documentation in `docs/models/`
- [ ] Demo the change at the team standup

## Week 2 — On-call shadow

- [ ] Shadow whoever is on call
- [ ] Read every incident runbook in `docs/pipelines/`
- [ ] Make sure you can navigate Snowsight: query history, warehouse usage, resource monitors

## Help

- **Slack:** `#data-platform`
- **Onboarding buddy:** assigned on day 1
- **Manager 1:1:** weekly

## What you should know by end of week 2

- How to add a new column to a fact table safely (migration, dbt model, dashboard)
- How to investigate why a query is slow
- How to read the audit log
- Who owns each table in `app_db.analytics`
