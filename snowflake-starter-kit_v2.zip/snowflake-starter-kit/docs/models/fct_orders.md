# fct_orders

**Location:** `app_db.analytics.fct_orders`
**Owner:** data-platform-team
**Grain:** One row per order header
**Refresh:** Daily at 02:00 UTC via `daily_orders_load` Airflow DAG
**Tier:** critical

## Purpose

The orders fact table is the canonical source of truth for completed and in-flight customer orders. It feeds the daily revenue dashboard, customer LTV calculations, and downstream marketing systems. For line-item analysis, use `fct_order_items` instead.

## Schema

| Column             | Type            | Description                                                |
|--------------------|-----------------|------------------------------------------------------------|
| order_id           | NUMBER(38,0)    | Surrogate primary key                                      |
| order_natural_key  | VARCHAR         | Source-system order identifier                             |
| customer_id        | NUMBER(38,0)    | FK to dim_customers                                        |
| order_date         | DATE            | Date the order was placed                                  |
| order_timestamp    | TIMESTAMP_NTZ   | Exact moment of order placement                            |
| order_status       | VARCHAR(20)     | PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED          |
| currency_code      | VARCHAR(3)      | ISO 4217 currency code                                     |
| subtotal_amount    | NUMBER(18,4)    | Sum of line items, pre-tax                                 |
| tax_amount         | NUMBER(18,4)    | Total tax applied                                          |
| shipping_amount    | NUMBER(18,4)    | Shipping charges                                           |
| discount_amount    | NUMBER(18,4)    | Discounts applied                                          |
| total_amount       | NUMBER(18,4)    | Grand total charged to customer                            |
| payment_method     | VARCHAR(30)     | CARD, PAYPAL, BANK_TRANSFER, etc.                          |
| shipping_country   | VARCHAR(2)      | ISO 3166-1 alpha-2                                         |
| is_first_order     | BOOLEAN         | TRUE if this customer's first order                        |
| source_system      | VARCHAR(50)     | System of record identifier                                |
| created_at         | TIMESTAMP_NTZ   | Row creation time in this table                            |
| updated_at         | TIMESTAMP_NTZ   | Row last modified time                                     |
| loaded_by_run_id   | VARCHAR         | ETL run identifier for lineage                             |

## Upstream dependencies

- `app_db.raw.orders_daily` — landed by upstream Fivetran connector
- `app_db.staging.stg_orders` — cleansed and typed orders
- `app_db.analytics.dim_customers` — for `is_first_order` calculation

## Downstream consumers

- Streamlit dashboard: `Orders Dashboard`
- dbt model: `agg_daily_revenue`
- Airflow DAG: `cost_monitor` (for revenue-per-credit metrics)
- BI tool: Tableau workbook "Executive Summary"

## Common queries

```sql
-- Daily revenue, last 30 days
SELECT
    order_date,
    SUM(total_amount) AS revenue,
    COUNT(*)          AS orders
FROM app_db.analytics.fct_orders
WHERE order_status = 'DELIVERED'
  AND order_date >= DATEADD(day, -30, CURRENT_DATE())
GROUP BY 1
ORDER BY 1;

-- Top 10 customers by lifetime value
SELECT
    customer_id,
    SUM(total_amount) AS lifetime_value,
    COUNT(*)          AS order_count
FROM app_db.analytics.fct_orders
WHERE order_status = 'DELIVERED'
GROUP BY 1
ORDER BY 2 DESC
LIMIT 10;
```

## Known issues / quirks

- **Currency:** the table mixes currencies; `total_amount` is in the `currency_code` of that row. For consolidated revenue analysis, join to `app_db.util.exchange_rates` to convert to USD.
- **`is_first_order` is computed at load time.** Late-arriving orders for new customers may briefly show incorrect values until the next refresh.
- **Cancelled orders retain their amounts.** Don't `SUM(total_amount)` without filtering on `order_status = 'DELIVERED'` if you want realized revenue.

## Change log

- 2026-05-03 — initial version
- 2026-04-15 — added `discount_amount` column (migration V0038)
- 2026-03-01 — extended `payment_method` enum with `APPLE_PAY` and `GOOGLE_PAY`
