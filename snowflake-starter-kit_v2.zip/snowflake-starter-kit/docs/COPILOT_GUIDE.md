# Working with GitHub Copilot in This Project

This kit is configured to give GitHub Copilot rich context about Snowflake conventions, so it produces high-quality SQL and Python suggestions out of the box.

## How Copilot picks up project context

GitHub Copilot reads `.github/copilot-instructions.md` automatically when you use Copilot Chat in this workspace. Those instructions cover our naming conventions, security rules, and Snowflake-specific best practices, so suggestions stay consistent with the project.

The custom prompt files in `.github/prompts/` are reusable instructions you can invoke in Copilot Chat. To use one, type `/` in Chat and pick from the list, or just describe what you want and Copilot will often pick the right one.

## Recommended workflows

### Writing a new SQL file
1. Create the file in the appropriate folder (`sql/ddl/`, `sql/queries/`, etc.)
2. Start with a header comment block — Copilot will infer the rest from context
3. Type the first few keywords (`CREATE TABLE`, `WITH ...`, etc.) and let Copilot suggest

### Writing Python that calls Snowflake
1. Import from `python.connectors.snowflake_conn` — Copilot already knows the helpers
2. Use the `snowflake_connection()` context manager pattern
3. For DataFrames, use `python.utils.query_helpers.run_query`

### Asking Copilot Chat for help
- `@workspace explain how dim_customers handles SCD2` — uses project context
- `#file:sql/ddl/fct_orders.sql write a query that...` — references a specific file
- `/optimize-query` — runs the optimization prompt against your selection

### Inline Copilot tricks
- Type a comment describing what you want, then press Enter — Copilot writes the code
- Press `Alt + ]` / `Alt + [` to cycle through alternative suggestions
- Press `Ctrl + Enter` (Windows/Linux) or `Cmd + Enter` (Mac) to see all suggestions in a panel

## Examples that work well

```python
# Fetch the top 10 customers by lifetime value, including their first order date
```
Copilot will write a parameterized SQL query using the project's helpers.

```sql
-- Aggregate daily revenue with a 7-day rolling average, partitioned by region
```
Copilot will write a window-function query that follows project conventions (UPPERCASE keywords, snake_case identifiers, etc.).

## When Copilot gets it wrong

If Copilot suggests something that violates project conventions:
1. Check `.github/copilot-instructions.md` — is the rule clearly stated there?
2. If not, add it. The instructions file is the source of truth.
3. Reject the suggestion (Esc) and try a more specific prompt.

## Privacy reminders

- Never paste production data into Copilot Chat
- Don't commit `.env` files — Copilot can see your open files when generating suggestions
- Review every generated SQL statement before running it against production
