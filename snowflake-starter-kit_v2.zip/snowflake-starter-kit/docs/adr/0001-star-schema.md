# ADR 0001: Star schema with conformed dimensions

**Status:** Accepted
**Date:** 2026-05-03
**Decision-makers:** data-platform-team

## Context

We need a modeling approach for the analytics layer. Candidates:

- **Star schema** — facts surrounded by conformed dimensions
- **Data Vault 2.0** — hubs, links, satellites; very flexible but verbose
- **One Big Table** — denormalized, optimized for specific use cases
- **Snowflake schema** — normalized dimensions

Our consumers are mainly analysts using SQL and BI tools. Sources are well-defined (no expected proliferation of upstream systems). Engineering team is small (4 people), so we can't afford the overhead of Data Vault.

## Decision

Use a **star schema with conformed dimensions** as the analytics-layer modeling approach. Specifics:

- Facts and dimensions live in `app_db.analytics`
- Type 2 SCDs for dimensions where history matters (`dim_customers`)
- Type 1 SCDs for dimensions where it doesn't (`dim_products`, `dim_date`)
- One conformed `dim_date` shared across all facts
- Surrogate keys generated via Snowflake sequences
- Naming: `dim_*` and `fct_*` prefixes

## Alternatives considered

- **Data Vault 2.0** — rejected; overhead too high for current team size and source stability. Reconsider if we cross 5+ source systems.
- **One Big Table** — rejected; harder to extend, doesn't compose well with BI tools that expect star joins.
- **Snowflake schema** — rejected; normalized dimensions add joins for marginal storage savings that don't matter on Snowflake anyway.

## Consequences

- ✅ Analysts can write intuitive joins
- ✅ BI tools (Tableau, Looker) understand star joins natively
- ✅ Easy to onboard new engineers
- ⚠️ Type 2 SCDs require careful joins (`order_timestamp BETWEEN valid_from AND valid_to`)
- ⚠️ Surrogate keys add complexity vs. natural keys
- ❌ Less flexible than Data Vault for ingesting unexpected new sources

## References

- [Kimball's Data Warehouse Toolkit (3rd ed.)](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/books/data-warehouse-dw-toolkit/)
- `skills/snowflake-data-modeler/SKILL.md` for project-specific patterns
