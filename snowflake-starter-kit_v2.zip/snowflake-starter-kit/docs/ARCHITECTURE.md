# Architecture Overview

## Data Flow

```
  Source systems
       │
       ▼
   ┌──────────┐
   │   RAW    │  Landing zone — minimal transformation, retain source format
   │  schema  │
   └────┬─────┘
        │  (sp_load_raw, COPY INTO from stage)
        ▼
   ┌──────────┐
   │ STAGING  │  Cleansed, conformed, typed; one row per source record
   │  schema  │
   └────┬─────┘
        │  (sp_refresh_dim_*, sp_refresh_fct_*)
        ▼
   ┌──────────┐
   │ANALYTICS │  Star-schema marts; dimensions + facts
   │  schema  │
   └──────────┘
        │
        ▼
     BI tools, dashboards, ML features
```

## Schema Conventions

| Schema      | Purpose                              | Who reads        | Who writes        |
|-------------|--------------------------------------|------------------|-------------------|
| `RAW`       | Untouched source data                | Loaders only     | `APP_LOADER`      |
| `STAGING`   | Cleansed, deduped, typed             | Pipelines        | `APP_DEVELOPER`   |
| `ANALYTICS` | Curated marts for BI/ML              | Analysts, BI     | Pipelines         |
| `UTIL`      | Procedures, UDFs, audit logs         | Pipelines        | `APP_DEVELOPER`   |

## Naming Conventions

| Object type       | Prefix    | Example                      |
|-------------------|-----------|------------------------------|
| Staging table     | `stg_`    | `stg_customers`              |
| Dimension         | `dim_`    | `dim_customers`              |
| Fact              | `fct_`    | `fct_orders`                 |
| View              | `v_`      | `v_active_customers`         |
| Stored procedure  | `sp_`     | `sp_refresh_dim_customers`   |
| User-defined fn   | `udf_`    | `udf_format_phone`           |
| Sequence          | `seq_`    | `seq_dim_customers`          |
| Audit log table   | `audit_`  | `audit_log`                  |

## Authentication Strategy

- **Developers**: SSO via external browser (`SNOWFLAKE_AUTHENTICATOR=externalbrowser`)
- **Service accounts (ETL)**: Key-pair authentication, keys rotated quarterly
- **CI/CD**: Key-pair authentication, key stored in GitHub Actions secrets

Passwords are only acceptable for local dev sandboxes and never for shared environments.

## Cost Controls

1. All warehouses have `AUTO_SUSPEND=60` (one minute)
2. Statement timeouts set per-session via `SNOWFLAKE_STATEMENT_TIMEOUT_SECONDS`
3. Resource monitors enforce daily/monthly credit caps at the account level
4. Query tags identify workloads for chargeback (`ALTER SESSION SET QUERY_TAG='etl-load'`)

## Time Travel & Recovery

- Permanent tables: 1-day retention (default)
- Critical analytics tables: extended to 7 days via `DATA_RETENTION_TIME_IN_DAYS=7`
- Use `AT(TIMESTAMP => ...)` or `AT(OFFSET => ...)` to query historical state
- Zero-copy clones (`CREATE TABLE x CLONE y`) for cheap dev/test snapshots
