"""
Builds parameterized SQL for the WIDE-format fact_performance_returns table.

Nothing here hardcodes a column name or a period list -- both come from
table_config.yaml via table_config.py. Adding a period, renaming a column, or
repointing to a different table is a config edit, not a code change.

Hard rule unchanged from the long-format version: every value that
originates from the *caller* (entity ids, category, currency, as_of_date)
goes in via a bind parameter, never via string interpolation. Column names
come from table_config.py, which validates them as strict SQL identifiers at
load time before they're ever available to be interpolated.
"""
from __future__ import annotations

from dataclasses import dataclass

from models import Category, EntityType, GetReturnsRequest
from table_config import TableConfig, get_table_config


@dataclass(frozen=True)
class BuiltQuery:
    sql: str
    params: dict
    # period token -> the SELECT alias used for that column in this query,
    # so the caller can pull values back out of each returned record.
    period_aliases: dict[str, str]


def _period_alias(period: str) -> str:
    # Deterministic, collision-free alias derived from the period token
    # itself (tokens are already validated against config, so this is safe
    # to use directly as an identifier).
    return f"PERIOD_{period}"


def _primary_entity(req: GetReturnsRequest) -> tuple[EntityType, str]:
    if req.account_id:
        return EntityType.ACCOUNT, req.account_id
    if req.fund_class_id:
        return EntityType.FUND_CLASS, req.fund_class_id
    return EntityType.BENCHMARK, req.benchmark_id  # type: ignore[return-value]


def build_get_returns_query(
    req: GetReturnsRequest,
    max_rows: int,
    config: TableConfig | None = None,
) -> BuiltQuery:
    cfg = config or get_table_config()
    cols = cfg.columns
    table_fqn = cfg.table.fqn

    entity_type, entity_id = _primary_entity(req)

    period_aliases = {p: _period_alias(p) for p in req.periods}
    period_select_list = ",\n            ".join(
        f"{cfg.column_for_period(p)} AS {alias}" for p, alias in period_aliases.items()
    )

    select_cols = f"""
            {cols.entity_type} AS ENTITY_TYPE,
            {cols.entity_id} AS ENTITY_ID,
            {cols.category_id} AS CATEGORY_ID,
            {cols.currency} AS CURRENCY,
            {cols.as_of_date} AS AS_OF_DATE,
            {period_select_list}
    """.strip()

    where_clauses = [
        f"{cols.entity_type} = %(entity_type)s",
        f"{cols.entity_id} = %(entity_id)s",
        f"{cols.currency} = %(currency)s",
    ]
    params: dict = {
        "entity_type": entity_type.value,
        "entity_id": entity_id,
        "currency": req.currency,
    }

    # Benchmarks typically aren't split by Gross/Net -- only filter on
    # category when the primary entity is fee-bearing.
    is_fee_bearing_entity = bool(req.account_id or req.fund_class_id)
    if is_fee_bearing_entity:
        where_clauses.append(f"({cols.category_id} = %(category_id)s OR {cols.category_id} IS NULL)")
        params["category_id"] = req.category.category_id

    if req.as_of_date:
        where_clauses.append(f"{cols.as_of_date} = %(as_of_date)s")
        params["as_of_date"] = req.as_of_date
    else:
        # Wide format: one row per (entity, category, currency, as_of_date),
        # so "latest" is a single correlated MAX, not per-period like the
        # long-format version.
        inner_where = [
            f"t2.{cols.entity_type} = t1.{cols.entity_type}",
            f"t2.{cols.entity_id} = t1.{cols.entity_id}",
            f"t2.{cols.currency} = t1.{cols.currency}",
        ]
        if is_fee_bearing_entity:
            inner_where.append(f"(t2.{cols.category_id} = t1.{cols.category_id} OR t2.{cols.category_id} IS NULL)")
        where_clauses.append(
            f"t1.{cols.as_of_date} = (SELECT MAX(t2.{cols.as_of_date}) FROM {table_fqn} t2 "
            f"WHERE {' AND '.join(inner_where)})"
        )

    sql = f"""
        SELECT
            {select_cols}
        FROM {table_fqn} t1
        WHERE {' AND '.join(where_clauses)}
        LIMIT {int(max_rows)}
    """.strip()

    return BuiltQuery(sql=sql, params=params, period_aliases=period_aliases)


def build_benchmark_lookup_query(
    primary_entity_type: EntityType,
    entity_id: str,
    periods: list[str],
    currency: str,
    max_rows: int,
    config: TableConfig | None = None,
) -> BuiltQuery:
    """
    Fetches the linked benchmark's wide row for the same as_of_date/currency
    as the primary entity, via the configured benchmark_link_id column.
    """
    cfg = config or get_table_config()
    cols = cfg.columns
    table_fqn = cfg.table.fqn

    period_aliases = {p: _period_alias(p) for p in periods}
    period_select_list = ",\n            ".join(
        f"bm.{cfg.column_for_period(p)} AS {alias}" for p, alias in period_aliases.items()
    )

    sql = f"""
        SELECT
            bm.{cols.entity_type} AS ENTITY_TYPE,
            bm.{cols.entity_id} AS ENTITY_ID,
            bm.{cols.category_id} AS CATEGORY_ID,
            bm.{cols.currency} AS CURRENCY,
            bm.{cols.as_of_date} AS AS_OF_DATE,
            {period_select_list}
        FROM {table_fqn} src
        JOIN {table_fqn} bm
          ON bm.{cols.entity_type} = %(bm_entity_type)s
         AND bm.{cols.entity_id} = src.{cols.benchmark_link_id}
         AND bm.{cols.as_of_date} = src.{cols.as_of_date}
         AND bm.{cols.currency} = src.{cols.currency}
        WHERE src.{cols.entity_type} = %(src_entity_type)s
          AND src.{cols.entity_id} = %(src_entity_id)s
          AND src.{cols.currency} = %(currency)s
        LIMIT {int(max_rows)}
    """.strip()

    params = {
        "bm_entity_type": EntityType.BENCHMARK.value,
        "src_entity_type": primary_entity_type.value,
        "src_entity_id": entity_id,
        "currency": currency,
    }
    return BuiltQuery(sql=sql, params=params, period_aliases=period_aliases)
