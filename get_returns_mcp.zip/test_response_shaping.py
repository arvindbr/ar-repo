import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from datetime import date

from models import Category, GetReturnsRequest
from query_builder import build_get_returns_query
from response_shaping import unpivot_records as _unpivot_records


def test_unpivot_expands_wide_row_into_one_row_per_period():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO", "3MO", "YTD"])
    query = build_get_returns_query(req, max_rows=1000)

    # Simulate a single wide record as Snowflake would return it.
    record = {
        "ENTITY_TYPE": "ACCOUNT",
        "ENTITY_ID": "ACC1",
        "CATEGORY_ID": 2,  # NET
        "CURRENCY": "USD",
        "AS_OF_DATE": date(2026, 6, 30),
        "PERIOD_1MO": 0.0124,
        "PERIOD_3MO": 0.0355,
        "PERIOD_YTD": 0.0810,
    }

    rows = _unpivot_records([record], query)
    assert len(rows) == 3
    by_period = {r.period_type: r for r in rows}
    assert by_period["1MO"].return_value == 0.0124
    assert by_period["3MO"].return_value == 0.0355
    assert by_period["YTD"].return_value == 0.0810
    assert all(r.category == Category.NET for r in rows)
    assert all(r.entity_id == "ACC1" for r in rows)


def test_unpivot_skips_null_period_values():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO", "10YR"])
    query = build_get_returns_query(req, max_rows=1000)

    record = {
        "ENTITY_TYPE": "ACCOUNT",
        "ENTITY_ID": "ACC1",
        "CATEGORY_ID": 1,
        "CURRENCY": "USD",
        "AS_OF_DATE": date(2026, 6, 30),
        "PERIOD_1MO": 0.01,
        "PERIOD_10YR": None,  # account too young to have a 10YR return
    }

    rows = _unpivot_records([record], query)
    assert len(rows) == 1
    assert rows[0].period_type == "1MO"
