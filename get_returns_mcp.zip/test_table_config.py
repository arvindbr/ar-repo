import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from table_config import TableConfigError, load_table_config

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def test_loads_shipped_config():
    cfg = load_table_config()
    assert cfg.table.name == "FACT_PERFORMANCE_RETURNS"
    assert "1MO" in cfg.valid_periods
    assert "10YR" in cfg.valid_periods
    assert "MTD" in cfg.valid_periods
    assert cfg.column_for_period("1MO") == "RETURN_1MO"


def test_rejects_invalid_identifier(tmp_path):
    bad_config = tmp_path / "bad.yaml"
    bad_config.write_text(
        """
table:
  database: PUBLISH
  schema: PERF
  name: "FACT; DROP TABLE X"
columns:
  entity_type: ENTITY_TYPE
  entity_id: ENTITY_ID
  benchmark_link_id: BENCHMARK_LINK_ID
  category_id: CATEGORY_ID
  currency: CURRENCY
  as_of_date: AS_OF_DATE
periods:
  1MO: RETURN_1MO
"""
    )
    with pytest.raises(TableConfigError):
        load_table_config(str(bad_config))


def test_rejects_empty_periods(tmp_path):
    bad_config = tmp_path / "bad.yaml"
    bad_config.write_text(
        """
table:
  database: PUBLISH
  schema: PERF
  name: FACT_PERFORMANCE_RETURNS
columns:
  entity_type: ENTITY_TYPE
  entity_id: ENTITY_ID
  benchmark_link_id: BENCHMARK_LINK_ID
  category_id: CATEGORY_ID
  currency: CURRENCY
  as_of_date: AS_OF_DATE
periods: {}
"""
    )
    with pytest.raises(TableConfigError):
        load_table_config(str(bad_config))


def test_missing_file_raises():
    with pytest.raises(TableConfigError):
        load_table_config("/nonexistent/path/table_config.yaml")


def test_period_tokens_normalized_to_uppercase(tmp_path):
    cfg_path = tmp_path / "cfg.yaml"
    cfg_path.write_text(
        """
table:
  database: PUBLISH
  schema: PERF
  name: FACT_PERFORMANCE_RETURNS
columns:
  entity_type: ENTITY_TYPE
  entity_id: ENTITY_ID
  benchmark_link_id: BENCHMARK_LINK_ID
  category_id: CATEGORY_ID
  currency: CURRENCY
  as_of_date: AS_OF_DATE
periods:
  mtd: RETURN_MTD
"""
    )
    cfg = load_table_config(str(cfg_path))
    assert "MTD" in cfg.valid_periods
    assert cfg.column_for_period("MTD") == "RETURN_MTD"
