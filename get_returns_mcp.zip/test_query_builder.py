import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from models import Category, EntityType, GetReturnsRequest
from query_builder import build_benchmark_lookup_query, build_get_returns_query
from table_config import get_table_config

CFG = get_table_config()


def test_select_list_only_includes_requested_periods():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO", "YTD"], category=Category.GROSS)
    q = build_get_returns_query(req, max_rows=1000)
    assert "RETURN_1MO AS PERIOD_1MO" in q.sql
    assert "RETURN_MTD" not in q.sql  # not requested, should not appear
    assert set(q.period_aliases.keys()) == {"1MO", "YTD"}


def test_account_query_filters_by_category():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO"], category=Category.GROSS)
    q = build_get_returns_query(req, max_rows=1000)
    assert "CATEGORY_ID = %(category_id)s" in q.sql
    assert q.params["category_id"] == 1  # GROSS
    assert q.params["entity_type"] == EntityType.ACCOUNT.value
    assert q.params["entity_id"] == "ACC1"


def test_benchmark_only_query_skips_category_filter():
    req = GetReturnsRequest(benchmark_id="BM1", periods=["1YR"])
    q = build_get_returns_query(req, max_rows=1000)
    assert "CATEGORY_ID = %(category_id)s" not in q.sql
    assert "category_id" not in q.params
    assert q.params["entity_type"] == EntityType.BENCHMARK.value


def test_no_as_of_date_uses_latest_snapshot_subquery():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO"])
    q = build_get_returns_query(req, max_rows=1000)
    assert "MAX(t2.AS_OF_DATE)" in q.sql
    assert "as_of_date" not in q.params


def test_explicit_as_of_date_is_bound_param():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO"], as_of_date="2026-06-30")
    q = build_get_returns_query(req, max_rows=1000)
    assert "%(as_of_date)s" in q.sql
    assert str(q.params["as_of_date"]) == "2026-06-30"


def test_no_user_values_interpolated_directly_into_sql_text():
    """Guard against regressions where a value leaks into the SQL string
    instead of going through a bind param."""
    req = GetReturnsRequest(account_id="'; DROP TABLE FACT_PERFORMANCE_RETURNS; --", periods=["1MO"])
    q = build_get_returns_query(req, max_rows=1000)
    assert "DROP TABLE" not in q.sql
    assert q.params["entity_id"] == "'; DROP TABLE FACT_PERFORMANCE_RETURNS; --"


def test_benchmark_lookup_query_joins_on_link_id():
    q = build_benchmark_lookup_query(EntityType.ACCOUNT, "ACC1", ["1MO", "3MO"], "USD", max_rows=1000)
    assert "BENCHMARK_LINK_ID" in q.sql
    assert q.params["src_entity_id"] == "ACC1"
    assert "RETURN_1MO AS PERIOD_1MO" in q.sql
    assert "RETURN_3MO AS PERIOD_3MO" in q.sql


def test_row_limit_is_applied():
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO"])
    q = build_get_returns_query(req, max_rows=42)
    assert "LIMIT 42" in q.sql


def test_column_mapping_comes_from_config_not_hardcoded():
    """Changing table_config.yaml's column for a period should change the
    generated SQL without touching query_builder.py."""
    req = GetReturnsRequest(account_id="ACC1", periods=["1MO"])
    q = build_get_returns_query(req, max_rows=1000, config=CFG)
    expected_col = CFG.column_for_period("1MO")
    assert expected_col in q.sql
