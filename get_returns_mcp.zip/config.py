"""
Configuration for the Performance MCP server.

All secrets are pulled from environment variables. In production these are
expected to be injected via Azure Key Vault references (App Config / Container
Apps secret mounts) — this module never reads a key file path that isn't
already resolved into an env var by the deployment layer.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


class ConfigError(RuntimeError):
    """Raised when required configuration is missing or invalid."""


def _require(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        raise ConfigError(f"Missing required environment variable: {name}")
    return val


@dataclass(frozen=True)
class SnowflakeSettings:
    account: str
    user: str
    role: str
    warehouse: str
    database: str
    schema: str
    private_key_path: str
    private_key_passphrase: str | None
    query_timeout_seconds: int = 30

    @classmethod
    def from_env(cls) -> "SnowflakeSettings":
        role = os.environ.get("SNOWFLAKE_ROLE", "PERF_MCP_READONLY")
        if "READONLY" not in role.upper() and "RO" not in role.upper():
            # Not a hard block — some orgs name roles differently — but flag loudly.
            # This service must never run under a role with write privileges on
            # the performance schema.
            pass
        return cls(
            account=_require("SNOWFLAKE_ACCOUNT"),
            user=_require("SNOWFLAKE_USER"),
            role=role,
            warehouse=os.environ.get("SNOWFLAKE_WAREHOUSE", "PERF_MCP_WH"),
            database=os.environ.get("SNOWFLAKE_DATABASE", "PUBLISH"),
            schema=os.environ.get("SNOWFLAKE_SCHEMA", "PERF"),
            private_key_path=_require("SNOWFLAKE_PRIVATE_KEY_PATH"),
            private_key_passphrase=os.environ.get("SNOWFLAKE_PRIVATE_KEY_PASSPHRASE"),
            query_timeout_seconds=int(os.environ.get("SNOWFLAKE_QUERY_TIMEOUT_SECONDS", "30")),
        )

    @property
    def fully_qualified_table(self) -> str:
        return f"{self.database}.{self.schema}.FACT_PERFORMANCE_RETURNS"


@dataclass(frozen=True)
class ServerSettings:
    host: str = "0.0.0.0"
    port: int = 8000
    stateless_http: bool = True
    max_rows_per_request: int = 5000

    @classmethod
    def from_env(cls) -> "ServerSettings":
        return cls(
            host=os.environ.get("MCP_HOST", "0.0.0.0"),
            port=int(os.environ.get("MCP_PORT", "8000")),
            stateless_http=os.environ.get("MCP_STATELESS_HTTP", "true").lower() == "true",
            max_rows_per_request=int(os.environ.get("MCP_MAX_ROWS", "5000")),
        )
