"""
Domain models for the Performance MCP server.

Table shape: WIDE-format fact_performance_returns -- one row per
(entity_type, entity_id, category_id, currency, as_of_date), with each
period's return in its own column (RETURN_1MO, RETURN_3MO, ... RETURN_10YR,
RETURN_MTD, RETURN_YTD). The exact column names and which period tokens are
supported are configured in table_config.yaml, not hardcoded here -- see
table_config.py.
"""
from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator

from table_config import get_table_config


class EntityType(str, Enum):
    ACCOUNT = "ACCOUNT"
    FUND_CLASS = "FUND_CLASS"
    BENCHMARK = "BENCHMARK"


class Category(str, Enum):
    """Maps to CATEGORY_ID in the warehouse. Gross=1, Net=2."""
    GROSS = "GROSS"
    NET = "NET"

    @property
    def category_id(self) -> int:
        return {"GROSS": 1, "NET": 2}[self.value]


class GetReturnsRequest(BaseModel):
    """Input schema for the get_returns tool."""

    account_id: Optional[str] = Field(
        default=None, description="Canonical account ID. Required unless fund_class_id or benchmark_id is supplied."
    )
    fund_class_id: Optional[str] = Field(default=None, description="Canonical fund share-class ID.")
    benchmark_id: Optional[str] = Field(default=None, description="Canonical benchmark ID.")

    periods: list[str] = Field(
        description="One or more period tokens, as configured in table_config.yaml (e.g. 1MO..12MO, 1YR..10YR, MTD, YTD)."
    )
    category: Category = Field(
        default=Category.NET,
        description="Gross or Net of Fee. Ignored for pure benchmark-only lookups where the warehouse has no fee concept.",
    )
    currency: str = Field(default="USD", description="ISO 4217 currency code for the return.")
    as_of_date: Optional[date] = Field(
        default=None,
        description="Period end date to price returns through. Defaults to the latest available as_of_date per entity.",
    )
    include_benchmark: bool = Field(
        default=False,
        description="When true and account_id/fund_class_id is set, also return the linked benchmark's return for the same periods.",
    )

    @field_validator("periods")
    @classmethod
    def _validate_periods(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("periods must contain at least one value")
        normalized = [p.strip().upper() for p in v]
        valid_periods = get_table_config().valid_periods
        invalid = [p for p in normalized if p not in valid_periods]
        if invalid:
            raise ValueError(
                f"Invalid period(s): {invalid}. Valid values (from table_config.yaml): "
                f"{sorted(valid_periods)}"
            )
        return normalized

    @field_validator("currency")
    @classmethod
    def _validate_currency(cls, v: str) -> str:
        v = v.strip().upper()
        if len(v) != 3 or not v.isalpha():
            raise ValueError("currency must be a 3-letter ISO 4217 code, e.g. USD")
        return v

    def model_post_init(self, __context) -> None:
        if not any([self.account_id, self.fund_class_id, self.benchmark_id]):
            raise ValueError("At least one of account_id, fund_class_id, benchmark_id is required")


class ReturnRow(BaseModel):
    entity_type: EntityType
    entity_id: str
    period_type: str
    category: Optional[Category] = None
    currency: str
    as_of_date: date
    return_value: float


class GetReturnsResponse(BaseModel):
    rows: list[ReturnRow]
    row_count: int
    query_params: GetReturnsRequest
    warnings: list[str] = Field(default_factory=list)
