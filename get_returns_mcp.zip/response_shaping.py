"""
Reshapes wide-format Snowflake query results back into per-period ReturnRow
records. Kept separate from server.py so this logic (and its tests) don't
depend on the mcp/snowflake_client packages being installed.
"""
from __future__ import annotations

from models import Category, EntityType, ReturnRow
from query_builder import BuiltQuery


def unpivot_records(records: list[dict], query: BuiltQuery) -> list[ReturnRow]:
    """Each wide record holds N period columns; expand into one ReturnRow per
    (record, period) pair, skipping periods that are NULL for that record."""
    rows: list[ReturnRow] = []
    for record in records:
        category = None
        if record.get("CATEGORY_ID") is not None:
            category = Category.NET if record["CATEGORY_ID"] == 2 else Category.GROSS

        for period, alias in query.period_aliases.items():
            value = record.get(alias)
            if value is None:
                continue
            rows.append(
                ReturnRow(
                    entity_type=EntityType(record["ENTITY_TYPE"]),
                    entity_id=record["ENTITY_ID"],
                    period_type=period,
                    category=category,
                    currency=record["CURRENCY"],
                    as_of_date=record["AS_OF_DATE"],
                    return_value=float(value),
                )
            )
    return rows
