"""
Performance MCP Server

Exposes performance-domain tools backed by the WIDE-format
fact_performance_returns table (one row per entity/category/currency/
as_of_date, with a column per period). Which columns map to which period
tokens, and which columns are the entity/filter keys, is entirely
configured in table_config.yaml -- see table_config.py.

Deployed the same way as the other domain MCP servers in the platform:
FastMCP with stateless_http=True, fronted by the Azure APIM AI Gateway for
auth/rate-limiting/audit, callable from the Dynamic Router stage of the
Intent Resolver -> Router -> Domain MCP -> Aggregator pipeline.
"""
from __future__ import annotations

import logging

from mcp.server.fastmcp import FastMCP
from pydantic import ValidationError

from config import ServerSettings, SnowflakeSettings
from models import Category, EntityType, GetReturnsRequest, GetReturnsResponse, ReturnRow
from query_builder import build_benchmark_lookup_query, build_get_returns_query
from response_shaping import unpivot_records
from snowflake_client import SnowflakeClient, SnowflakeQueryError
from table_config import get_table_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("performance_mcp.server")

server_settings = ServerSettings.from_env()
sf_settings = SnowflakeSettings.from_env()
sf_client = SnowflakeClient(sf_settings)
table_config = get_table_config()

mcp = FastMCP(
    "performance-mcp",
    stateless_http=server_settings.stateless_http,
    host=server_settings.host,
    port=server_settings.port,
)


@mcp.tool()
def get_returns(
    account_id: str | None = None,
    fund_class_id: str | None = None,
    benchmark_id: str | None = None,
    periods: list[str] | None = None,
    category: str = "NET",
    currency: str = "USD",
    as_of_date: str | None = None,
    include_benchmark: bool = False,
) -> dict:
    """
    Retrieve performance returns for an account, fund share class, or
    benchmark across one or more standard periods.

    Args:
        account_id: Canonical account ID. Only one of account_id /
            fund_class_id / benchmark_id is required.
        fund_class_id: Canonical fund share-class ID.
        benchmark_id: Canonical benchmark ID.
        periods: List of period tokens. Valid values are defined in
            table_config.yaml (typically 1MO..12MO, 1YR..10YR, MTD, YTD).
        category: "GROSS" or "NET" (of fee). Defaults to NET. Ignored when
            the primary entity is a pure benchmark.
        currency: ISO 4217 currency code. Defaults to USD.
        as_of_date: ISO date (YYYY-MM-DD) to price returns through. Defaults
            to the latest available row for the entity.
        include_benchmark: If true, also returns the linked benchmark's
            return series for the same periods (account/fund_class lookups
            only).

    Returns:
        dict with keys: rows, row_count, query_params, warnings.
    """
    try:
        req = GetReturnsRequest(
            account_id=account_id,
            fund_class_id=fund_class_id,
            benchmark_id=benchmark_id,
            periods=periods or [],
            category=Category(category.upper()),
            currency=currency,
            as_of_date=as_of_date,
            include_benchmark=include_benchmark,
        )
    except (ValidationError, ValueError) as e:
        return {"error": "validation_error", "message": str(e)}

    warnings: list[str] = []
    rows: list[ReturnRow] = []

    primary_query = build_get_returns_query(req, server_settings.max_rows_per_request, table_config)
    try:
        records = sf_client.execute_query(primary_query.sql, primary_query.params)
    except SnowflakeQueryError as e:
        logger.error("get_returns primary query failed: %s", e)
        return {"error": "query_failed", "message": str(e)}

    rows.extend(unpivot_records(records, primary_query))

    if not rows:
        warnings.append(
            "No rows returned for the given entity/period/category/currency/as_of_date combination."
        )

    if req.include_benchmark and (req.account_id or req.fund_class_id):
        entity_type = EntityType.ACCOUNT if req.account_id else EntityType.FUND_CLASS
        entity_id = req.account_id or req.fund_class_id
        bm_query = build_benchmark_lookup_query(
            entity_type, entity_id, req.periods, req.currency,
            server_settings.max_rows_per_request, table_config,
        )
        try:
            bm_records = sf_client.execute_query(bm_query.sql, bm_query.params)
            bm_rows = unpivot_records(bm_records, bm_query)
            rows.extend(bm_rows)
            if not bm_rows:
                warnings.append("include_benchmark was set but no linked benchmark data was found.")
        except SnowflakeQueryError as e:
            logger.warning("Benchmark lookup failed, continuing without it: %s", e)
            warnings.append(f"Benchmark lookup failed: {e}")

    response = GetReturnsResponse(
        rows=rows,
        row_count=len(rows),
        query_params=req,
        warnings=warnings,
    )
    return response.model_dump(mode="json")


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
