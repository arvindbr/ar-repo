# Performance MCP Server

A FastMCP server exposing a `get_returns` tool over a **wide-format**
`fact_performance_returns`, following the same conventions as the other
domain MCP servers in the platform: `stateless_http=True`, read-only
Snowflake role, sits behind the Azure APIM AI Gateway, callable from the
Dynamic Router stage.

## Schema assumption

One row per `(entity_type, entity_id, category_id, currency, as_of_date)`,
with each period's return in its own column: `RETURN_1MO` ... `RETURN_12MO`,
`RETURN_1YR` ... `RETURN_10YR`, `RETURN_MTD`, `RETURN_YTD`. See
`schema_reference.sql` for the exact assumed DDL.

**Column names and the supported period list are not in the Python code.**
They live in `table_config.yaml` and are loaded/validated at startup by
`table_config.py`. To add a period, rename a column, or repoint at a
different table/schema, edit `table_config.yaml` — no changes to
`query_builder.py`, `models.py`, or `server.py` are needed. Every identifier
from the YAML is checked against a strict `[A-Za-z_][A-Za-z0-9_]*` pattern
before it can ever appear in generated SQL, so a bad edit fails loudly at
startup rather than becoming a query-construction risk.

The query builder only ever `SELECT`s the columns for the periods actually
requested in a given call — it doesn't pull all 24 period columns and filter
in Python.

## Files

| File | Purpose |
|---|---|
| `server.py` | FastMCP app + `get_returns` tool |
| `models.py` | Pydantic request/response schemas; period validation reads the allowlist from `table_config.py` |
| `table_config.yaml` | **Configurable** filter/select column names + period→column mapping |
| `table_config.py` | Loads and validates `table_config.yaml` as SQL identifiers |
| `query_builder.py` | Builds parameterized SQL dynamically from the config (dynamic SELECT + WHERE) |
| `response_shaping.py` | Unpivots a wide result row into one `ReturnRow` per requested period |
| `snowflake_client.py` | Key-pair auth connection, read-only guard, bind-param execution |
| `config.py` | Env-driven settings (Snowflake connection + server) |
| `schema_reference.sql` | Documents the assumed table shape + suggested grants |
| `tests/` | Unit tests — validation, query construction, config loading, unpivot logic (23 tests, no live DB needed) |

## Tool: `get_returns`

```python
get_returns(
    account_id: str | None = None,       # one of account_id / fund_class_id / benchmark_id required
    fund_class_id: str | None = None,
    benchmark_id: str | None = None,
    periods: list[str],                  # e.g. ["1MO", "3MO", "YTD", "1YR"]
    category: str = "NET",               # "GROSS" or "NET"
    currency: str = "USD",
    as_of_date: str | None = None,       # defaults to latest available per period
    include_benchmark: bool = False,     # also pull the linked benchmark's series
)
```

Returns:
```json
{
  "rows": [
    {"entity_type": "ACCOUNT", "entity_id": "ACC123", "period_type": "1MO",
     "category": "NET", "currency": "USD", "as_of_date": "2026-07-31", "return_value": 0.0124}
  ],
  "row_count": 1,
  "query_params": { ... echoed request ... },
  "warnings": []
}
```

Validation errors (bad period token, missing entity, bad currency code)
return `{"error": "validation_error", "message": "..."}` rather than raising,
so the calling agent/orchestrator gets a structured response either way.

## Config (env vars)

| Var | Default | Notes |
|---|---|---|
| `SNOWFLAKE_ACCOUNT` | required | |
| `SNOWFLAKE_USER` | required | |
| `SNOWFLAKE_ROLE` | `PERF_MCP_READONLY` | should carry SELECT-only grants |
| `SNOWFLAKE_WAREHOUSE` | `PERF_MCP_WH` | |
| `SNOWFLAKE_DATABASE` | `PUBLISH` | |
| `SNOWFLAKE_SCHEMA` | `PERF` | |
| `SNOWFLAKE_PRIVATE_KEY_PATH` | required | resolved from Key Vault by the deployment layer |
| `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE` | optional | |
| `MCP_PORT` | `8000` | |
| `MCP_STATELESS_HTTP` | `true` | |
| `MCP_MAX_ROWS` | `5000` | hard cap per request |

## Running locally

```bash
pip install -r requirements.txt
export SNOWFLAKE_ACCOUNT=... SNOWFLAKE_USER=... SNOWFLAKE_PRIVATE_KEY_PATH=...
python server.py
```

## Testing

```bash
pip install pydantic pytest
pytest tests/ -v
```

The test suite covers request validation (period allowlist, currency format,
required-entity check) and SQL construction (bind params only, category
filter applied/skipped correctly, no injection via entity IDs). It doesn't
require a live Snowflake connection — `snowflake_client.py` and `mcp` itself
aren't imported by the tests.

## Configuring `table_config.yaml`

```yaml
table:
  database: PUBLISH
  schema: PERF
  name: FACT_PERFORMANCE_RETURNS

columns:
  entity_type: ENTITY_TYPE
  entity_id: ENTITY_ID
  benchmark_link_id: BENCHMARK_LINK_ID
  category_id: CATEGORY_ID
  currency: CURRENCY
  as_of_date: AS_OF_DATE

periods:
  1MO: RETURN_1MO
  3MO: RETURN_3MO
  # ...
  YTD: RETURN_YTD
```

- To point at a different table or database/schema, edit `table:`.
- To rename a filter column (e.g. your currency column is `CCY` not
  `CURRENCY`), edit `columns:`.
- To add/remove a supported period, add/remove a line under `periods:` — the
  key becomes the token callers pass in (`GetReturnsRequest.periods`), the
  value is the actual wide-format column name.
- `PERF_TABLE_CONFIG_PATH` env var overrides the config file location if you
  want per-environment configs instead of editing the shipped file directly.

Config is loaded once per process (`get_table_config()` singleton).
`reload_table_config()` is available for tests or hot-reload scenarios.

## Open questions to confirm against the real table

1. **Benchmark linkage** — `build_benchmark_lookup_query` assumes a
   `benchmark_link_id` column (configurable) on account/fund-class rows. If
   linkage instead lives in a separate mapping table (like the
   `DIM_BENCHMARK_MAPPING` pattern used elsewhere in the platform), the join
   in `query_builder.py` needs to change — the config alone can't express a
   second table.
2. **Category on benchmarks** — assumed benchmark rows have `CATEGORY_ID
   IS NULL`; if benchmarks actually carry a category value too, the `OR
   CATEGORY_ID IS NULL` fallback can be tightened.
3. **NULL handling for young accounts** — `response_shaping.py` silently
   skips periods where the column is NULL (e.g. a `10YR` column for a
   3-year-old account) rather than returning a `null` value. Flag if you'd
   rather see explicit nulls in the response.
