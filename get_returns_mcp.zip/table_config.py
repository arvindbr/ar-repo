"""
Loads and validates table_config.yaml.

This is the single source of truth for:
  - fixed filter/select columns (entity_type, entity_id, category_id, etc.)
  - the period-token -> wide-column mapping

Every identifier pulled from the YAML is validated against a strict
[A-Za-z_][A-Za-z0-9_]* pattern before being exposed. This config file is
trusted input (it ships with the service, isn't user-supplied per-request),
but validating at load time means a typo or accidental paste of something
unexpected fails loudly at startup instead of silently becoming query text.
"""
from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path

import yaml

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

_DEFAULT_CONFIG_PATH = os.environ.get(
    "PERF_TABLE_CONFIG_PATH",
    str(Path(__file__).resolve().parent / "table_config.yaml"),
)


class TableConfigError(RuntimeError):
    pass


def _validate_identifier(name: str, value: str) -> str:
    if not isinstance(value, str) or not _IDENTIFIER_RE.match(value):
        raise TableConfigError(
            f"Invalid SQL identifier for '{name}': {value!r}. "
            "Must match [A-Za-z_][A-Za-z0-9_]*."
        )
    return value


@dataclass(frozen=True)
class ColumnConfig:
    entity_type: str
    entity_id: str
    benchmark_link_id: str
    category_id: str
    currency: str
    as_of_date: str


@dataclass(frozen=True)
class TableIdentity:
    database: str
    schema: str
    name: str

    @property
    def fqn(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"


@dataclass(frozen=True)
class TableConfig:
    table: TableIdentity
    columns: ColumnConfig
    # period token (e.g. "1MO") -> wide-format column name (e.g. "RETURN_1MO")
    period_columns: dict[str, str] = field(default_factory=dict)

    @property
    def valid_periods(self) -> frozenset[str]:
        return frozenset(self.period_columns.keys())

    def column_for_period(self, period: str) -> str:
        try:
            return self.period_columns[period]
        except KeyError:
            raise TableConfigError(f"Unknown period token: {period!r}") from None


def _load_raw(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        raise TableConfigError(f"Table config file not found: {path}")
    with p.open("r") as f:
        data = yaml.safe_load(f)
    if not data:
        raise TableConfigError(f"Table config file is empty: {path}")
    return data


def load_table_config(path: str | None = None) -> TableConfig:
    path = path or _DEFAULT_CONFIG_PATH
    raw = _load_raw(path)

    try:
        table_raw = raw["table"]
        columns_raw = raw["columns"]
        periods_raw = raw["periods"]
    except KeyError as e:
        raise TableConfigError(f"Missing required top-level key in table config: {e}") from None

    table = TableIdentity(
        database=_validate_identifier("table.database", table_raw["database"]),
        schema=_validate_identifier("table.schema", table_raw["schema"]),
        name=_validate_identifier("table.name", table_raw["name"]),
    )

    columns = ColumnConfig(
        entity_type=_validate_identifier("columns.entity_type", columns_raw["entity_type"]),
        entity_id=_validate_identifier("columns.entity_id", columns_raw["entity_id"]),
        benchmark_link_id=_validate_identifier("columns.benchmark_link_id", columns_raw["benchmark_link_id"]),
        category_id=_validate_identifier("columns.category_id", columns_raw["category_id"]),
        currency=_validate_identifier("columns.currency", columns_raw["currency"]),
        as_of_date=_validate_identifier("columns.as_of_date", columns_raw["as_of_date"]),
    )

    if not periods_raw:
        raise TableConfigError("table_config.yaml 'periods' map must not be empty")

    period_columns: dict[str, str] = {}
    for token, col in periods_raw.items():
        token_norm = str(token).strip().upper()
        period_columns[token_norm] = _validate_identifier(f"periods.{token_norm}", col)

    return TableConfig(table=table, columns=columns, period_columns=period_columns)


# Module-level singleton, loaded once at import time and reusable across
# requests. Tests can call load_table_config(path) directly to load an
# alternate fixture without touching this singleton.
_lock = threading.Lock()
_config: TableConfig | None = None


def get_table_config() -> TableConfig:
    global _config
    if _config is None:
        with _lock:
            if _config is None:
                _config = load_table_config()
    return _config


def reload_table_config(path: str | None = None) -> TableConfig:
    """Force a reload — useful for tests or picking up a config change without a restart."""
    global _config
    with _lock:
        _config = load_table_config(path)
    return _config
