-- Reference DDL for FACT_PERFORMANCE_RETURNS as assumed by this MCP server.
-- This is NOT meant to be run — it documents the shape query_builder.py expects.
-- Diff against the real table and adjust query_builder.py / models.py if it
-- differs (e.g. if periods are wide columns instead of a PERIOD_TYPE row key,
-- or if benchmark linkage lives in a separate dimension table).

CREATE TABLE IF NOT EXISTS PUBLISH.PERF.FACT_PERFORMANCE_RETURNS (
    ENTITY_TYPE         VARCHAR(20)   NOT NULL,  -- 'ACCOUNT' | 'FUND_CLASS' | 'BENCHMARK'
    ENTITY_ID           VARCHAR(64)   NOT NULL,
    BENCHMARK_LINK_ID    VARCHAR(64),             -- populated for ACCOUNT/FUND_CLASS rows only
    CATEGORY_ID         NUMBER(1),               -- 1 = Gross of Fee, 2 = Net of Fee, NULL for benchmarks
    CURRENCY            VARCHAR(3)    NOT NULL,
    AS_OF_DATE          DATE          NOT NULL,
    PERIOD_TYPE         VARCHAR(10)   NOT NULL,  -- 1MO..12MO, 1YR..10YR, MTD, YTD
    RETURN_VALUE         FLOAT         NOT NULL,
    LOAD_TS              TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_SYSTEM         VARCHAR(50)
)
CLUSTER BY (ENTITY_TYPE, ENTITY_ID, AS_OF_DATE);

-- Suggested read-only role for this MCP server's Snowflake user:
--   GRANT USAGE ON DATABASE PUBLISH TO ROLE PERF_MCP_READONLY;
--   GRANT USAGE ON SCHEMA PUBLISH.PERF TO ROLE PERF_MCP_READONLY;
--   GRANT SELECT ON TABLE PUBLISH.PERF.FACT_PERFORMANCE_RETURNS TO ROLE PERF_MCP_READONLY;
--   GRANT USAGE ON WAREHOUSE PERF_MCP_WH TO ROLE PERF_MCP_READONLY;
