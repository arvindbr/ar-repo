import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from pydantic import ValidationError

from models import Category, GetReturnsRequest
from table_config import get_table_config


def test_valid_periods_cover_expected_ranges():
    valid_periods = get_table_config().valid_periods
    assert "1MO" in valid_periods and "12MO" in valid_periods
    assert "1YR" in valid_periods and "10YR" in valid_periods
    assert "MTD" in valid_periods and "YTD" in valid_periods
    assert "13MO" not in valid_periods
    assert "11YR" not in valid_periods


def test_request_requires_at_least_one_entity():
    with pytest.raises(ValidationError):
        GetReturnsRequest(periods=["1MO"])


def test_request_accepts_account_only():
    req = GetReturnsRequest(account_id="ACC123", periods=["1MO", "YTD"])
    assert req.category == Category.NET
    assert req.currency == "USD"


def test_invalid_period_rejected():
    with pytest.raises(ValidationError):
        GetReturnsRequest(account_id="ACC123", periods=["13MO"])


def test_invalid_currency_rejected():
    with pytest.raises(ValidationError):
        GetReturnsRequest(account_id="ACC123", periods=["1MO"], currency="US")


def test_periods_normalized_to_uppercase():
    req = GetReturnsRequest(account_id="ACC123", periods=["mtd", "1mo"])
    assert req.periods == ["MTD", "1MO"]


def test_empty_periods_rejected():
    with pytest.raises(ValidationError):
        GetReturnsRequest(account_id="ACC123", periods=[])
