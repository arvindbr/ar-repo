"""
Thin read-only Snowflake client wrapper.

- Key-pair auth (private key path resolved from Key Vault by the deployment
  layer into SNOWFLAKE_PRIVATE_KEY_PATH).
- Session is pinned to a warehouse/role/schema at connect time; the role is
  expected to carry SELECT-only grants on the performance schema.
- Every query goes through execute_query() with bind params — no raw string
  SQL execution is exposed to callers.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Iterator

import snowflake.connector
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from snowflake.connector import DictCursor

from config import SnowflakeSettings

logger = logging.getLogger("performance_mcp.snowflake")


class SnowflakeQueryError(RuntimeError):
    pass


def _load_private_key(path: str, passphrase: str | None) -> bytes:
    with open(path, "rb") as f:
        p_key = serialization.load_pem_private_key(
            f.read(),
            password=passphrase.encode() if passphrase else None,
            backend=default_backend(),
        )
    return p_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


class SnowflakeClient:
    def __init__(self, settings: SnowflakeSettings):
        self._settings = settings
        self._pkb = _load_private_key(settings.private_key_path, settings.private_key_passphrase)

    @contextmanager
    def _connection(self) -> Iterator[snowflake.connector.SnowflakeConnection]:
        conn = snowflake.connector.connect(
            account=self._settings.account,
            user=self._settings.user,
            private_key=self._pkb,
            role=self._settings.role,
            warehouse=self._settings.warehouse,
            database=self._settings.database,
            schema=self._settings.schema,
            session_parameters={
                "QUERY_TAG": "performance_mcp",
                # Belt-and-suspenders: block anything that isn't a read,
                # even though the role itself should already be SELECT-only.
                "STATEMENT_TIMEOUT_IN_SECONDS": self._settings.query_timeout_seconds,
            },
        )
        try:
            yield conn
        finally:
            conn.close()

    def execute_query(self, sql: str, params: dict[str, Any]) -> list[dict[str, Any]]:
        _guard_read_only(sql)
        with self._connection() as conn:
            with conn.cursor(DictCursor) as cur:
                try:
                    cur.execute(sql, params)
                    return cur.fetchall()
                except snowflake.connector.errors.ProgrammingError as e:
                    logger.error("Snowflake query failed: %s", e)
                    raise SnowflakeQueryError(str(e)) from e


_DISALLOWED_KEYWORDS = (
    "INSERT ", "UPDATE ", "DELETE ", "MERGE ", "DROP ", "ALTER ", "CREATE ",
    "TRUNCATE ", "GRANT ", "REVOKE ", "COPY INTO", "CALL ",
)


def _guard_read_only(sql: str) -> None:
    upper = sql.strip().upper()
    if not upper.startswith("SELECT") and not upper.startswith("WITH"):
        raise SnowflakeQueryError("Only SELECT/WITH statements are permitted through this client.")
    for kw in _DISALLOWED_KEYWORDS:
        if kw in upper:
            raise SnowflakeQueryError(f"Disallowed keyword '{kw.strip()}' detected in query.")
