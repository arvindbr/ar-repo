"""
Snowflake MCP API — FastAPI + Azure Container Apps
Async Snowflake execution  ·  Redis caching  ·  Production-ready
"""
import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.logging import setup_logging
from app.db.redis_client import redis_manager
from app.db.snowflake_pool import snowflake_pool
from app.middleware.request_id import RequestIDMiddleware
from app.middleware.metrics import MetricsMiddleware

setup_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown lifecycle."""
    logger.info("🚀 Starting Snowflake MCP API — env=%s", settings.ENVIRONMENT)

    # Initialise connection pool + Redis
    await snowflake_pool.initialise()
    await redis_manager.connect()

    logger.info("✅ All connections ready")
    yield

    # Graceful shutdown
    logger.info("🛑 Shutting down — draining connections")
    await redis_manager.disconnect()
    await snowflake_pool.close()
    logger.info("✅ Shutdown complete")


app = FastAPI(
    title="Snowflake MCP API",
    description=(
        "Async FastAPI service for invoking Snowflake stored procedures and SQL. "
        "Deployed as Azure Container App with Redis caching."
    ),
    version="1.0.0",
    docs_url="/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT != "production" else None,
    openapi_url="/openapi.json" if settings.ENVIRONMENT != "production" else None,
    lifespan=lifespan,
)

# ── Middleware (order matters — outermost first) ─────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(MetricsMiddleware)
app.add_middleware(RequestIDMiddleware)

# ── Routers ──────────────────────────────────────────────────────────────────
app.include_router(api_router, prefix="/api/v1")


# ── Global exception handler ─────────────────────────────────────────────────
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception: %s %s", request.method, request.url)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "message": "An unexpected error occurred.",
            "request_id": getattr(request.state, "request_id", None),
        },
    )


# ── Health / liveness probes (no auth required) ─────────────────────────────
@app.get("/healthz", tags=["Health"], include_in_schema=False)
async def liveness():
    return {"status": "ok", "timestamp": time.time()}


@app.get("/readyz", tags=["Health"], include_in_schema=False)
async def readiness():
    sf_ok = await snowflake_pool.ping()
    redis_ok = await redis_manager.ping()
    status = "ok" if (sf_ok and redis_ok) else "degraded"
    return {
        "status": status,
        "snowflake": "ok" if sf_ok else "unavailable",
        "redis": "ok" if redis_ok else "unavailable",
    }
