// ── Azure Container Apps — Snowflake MCP API ─────────────────────────────────
// Deploys:
//   • Container Apps Environment  (shared)
//   • Container App               (API)
//   • Azure Cache for Redis        (Basic / Standard)
//   • Azure Container Registry     (image store)
//   • User-Assigned Managed Identity
//   • Key Vault reference wiring   (Snowflake secrets)
// ─────────────────────────────────────────────────────────────────────────────

@description('Deployment environment')
@allowed(['development', 'staging', 'production'])
param environment string = 'development'

@description('Azure region')
param location string = resourceGroup().location

@description('Application name prefix')
param appName string = 'sf-mcp-api'

@description('Container image tag')
param imageTag string = 'latest'

@description('Minimum replica count')
param minReplicas int = 1

@description('Maximum replica count')
param maxReplicas int = 10

@description('Snowflake account identifier')
@secure()
param snowflakeAccount string

@description('Snowflake user')
@secure()
param snowflakeUser string

@description('Snowflake password')
@secure()
param snowflakePassword string

@description('Snowflake database')
param snowflakeDatabase string

@description('Snowflake warehouse')
param snowflakeWarehouse string

@description('API key for endpoint auth')
@secure()
param apiKey string

// ── Variables ─────────────────────────────────────────────────────────────────
var tags = {
  environment: environment
  application: appName
  managedBy: 'bicep'
}
var redisSku = environment == 'production' ? 'Standard' : 'Basic'
var redisFamily = environment == 'production' ? 'C' : 'C'
var redisCap = environment == 'production' ? 1 : 0

// ── User-assigned Managed Identity ───────────────────────────────────────────
resource identity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: '${appName}-identity'
  location: location
  tags: tags
}

// ── Azure Container Registry ──────────────────────────────────────────────────
resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: replace('${appName}acr', '-', '')
  location: location
  tags: tags
  sku: { name: environment == 'production' ? 'Premium' : 'Basic' }
  properties: {
    adminUserEnabled: false
    anonymousPullEnabled: false
  }
}

// Grant AcrPull to the managed identity
resource acrPullRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(acr.id, identity.id, 'AcrPull')
  scope: acr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '7f951dda-4ed3-4680-a7ca-43fe172d538d')
    principalId: identity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// ── Azure Cache for Redis ─────────────────────────────────────────────────────
resource redis 'Microsoft.Cache/redis@2024-03-01' = {
  name: '${appName}-redis'
  location: location
  tags: tags
  properties: {
    sku: {
      name: redisSku
      family: redisFamily
      capacity: redisCap
    }
    enableNonSslPort: false
    minimumTlsVersion: '1.2'
    redisConfiguration: {
      'maxmemory-policy': 'allkeys-lru'
    }
  }
}

// ── Key Vault (store Snowflake + Redis secrets) ───────────────────────────────
resource kv 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: '${appName}-kv'
  location: location
  tags: tags
  properties: {
    sku: { family: 'A', name: 'standard' }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
  }
}

resource kvSecretSnowflakeAccount 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'snowflake-account'
  properties: { value: snowflakeAccount }
}

resource kvSecretSnowflakeUser 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'snowflake-user'
  properties: { value: snowflakeUser }
}

resource kvSecretSnowflakePassword 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'snowflake-password'
  properties: { value: snowflakePassword }
}

resource kvSecretApiKey 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'api-key'
  properties: { value: apiKey }
}

resource kvSecretRedisUrl 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'redis-url'
  properties: {
    value: 'rediss://:${redis.listKeys().primaryKey}@${redis.properties.hostName}:6380/0'
  }
}

// Grant Key Vault Secrets User to managed identity
resource kvRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(kv.id, identity.id, 'KeyVaultSecretsUser')
  scope: kv
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '4633458b-17de-408a-b874-0445c86b69e6')
    principalId: identity.properties.principalId
    principalType: 'ServicePrincipal'
  }
}

// ── Log Analytics Workspace ───────────────────────────────────────────────────
resource logWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: '${appName}-logs'
  location: location
  tags: tags
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: environment == 'production' ? 90 : 30
  }
}

// ── Container Apps Environment ────────────────────────────────────────────────
resource caEnv 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: '${appName}-env'
  location: location
  tags: tags
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logWorkspace.properties.customerId
        sharedKey: logWorkspace.listKeys().primarySharedKey
      }
    }
    workloadProfiles: [
      {
        name: 'Consumption'
        workloadProfileType: 'Consumption'
      }
    ]
  }
}

// ── Container App ─────────────────────────────────────────────────────────────
resource containerApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: appName
  location: location
  tags: tags
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identity.id}': {}
    }
  }
  properties: {
    environmentId: caEnv.id
    workloadProfileName: 'Consumption'
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: {
        external: true
        targetPort: 8000
        transport: 'http'
        corsPolicy: {
          allowedOrigins: ['*']
          allowedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']
          allowedHeaders: ['*']
        }
        traffic: [{ latestRevision: true, weight: 100 }]
      }
      registries: [
        {
          server: acr.properties.loginServer
          identity: identity.id
        }
      ]
      // Key Vault secret references — injected as env vars at runtime
      secrets: [
        {
          name: 'snowflake-account'
          keyVaultUrl: kvSecretSnowflakeAccount.properties.secretUri
          identity: identity.id
        }
        {
          name: 'snowflake-user'
          keyVaultUrl: kvSecretSnowflakeUser.properties.secretUri
          identity: identity.id
        }
        {
          name: 'snowflake-password'
          keyVaultUrl: kvSecretSnowflakePassword.properties.secretUri
          identity: identity.id
        }
        {
          name: 'api-key'
          keyVaultUrl: kvSecretApiKey.properties.secretUri
          identity: identity.id
        }
        {
          name: 'redis-url'
          keyVaultUrl: kvSecretRedisUrl.properties.secretUri
          identity: identity.id
        }
      ]
    }
    template: {
      revisionSuffix: imageTag
      containers: [
        {
          name: appName
          image: '${acr.properties.loginServer}/${appName}:${imageTag}'
          resources: {
            cpu: json(environment == 'production' ? '1.0' : '0.5')
            memory: environment == 'production' ? '2Gi' : '1Gi'
          }
          env: [
            { name: 'ENVIRONMENT',          value: environment }
            { name: 'LOG_LEVEL',            value: environment == 'production' ? 'INFO' : 'DEBUG' }
            { name: 'SNOWFLAKE_ACCOUNT',    secretRef: 'snowflake-account' }
            { name: 'SNOWFLAKE_USER',       secretRef: 'snowflake-user' }
            { name: 'SNOWFLAKE_PASSWORD',   secretRef: 'snowflake-password' }
            { name: 'SNOWFLAKE_DATABASE',   value: snowflakeDatabase }
            { name: 'SNOWFLAKE_WAREHOUSE',  value: snowflakeWarehouse }
            { name: 'REDIS_URL',            secretRef: 'redis-url' }
            { name: 'API_KEYS',             secretRef: 'api-key' }
            { name: 'GUNICORN_WORKERS',     value: environment == 'production' ? '4' : '2' }
          ]
          probes: [
            {
              type: 'Liveness'
              httpGet: { path: '/healthz', port: 8000 }
              initialDelaySeconds: 15
              periodSeconds: 30
            }
            {
              type: 'Readiness'
              httpGet: { path: '/readyz', port: 8000 }
              initialDelaySeconds: 10
              periodSeconds: 15
            }
          ]
        }
      ]
      scale: {
        minReplicas: minReplicas
        maxReplicas: maxReplicas
        rules: [
          {
            name: 'http-scaling'
            http: { metadata: { concurrentRequests: '50' } }
          }
        ]
      }
    }
  }
}

// ── Outputs ───────────────────────────────────────────────────────────────────
output apiUrl string = 'https://${containerApp.properties.configuration.ingress.fqdn}'
output acrLoginServer string = acr.properties.loginServer
output redisHostName string = redis.properties.hostName
output managedIdentityClientId string = identity.properties.clientId
output keyVaultName string = kv.name
