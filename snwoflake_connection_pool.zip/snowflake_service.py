"""
SnowflakeService — business logic layer.
Orchestrates between SnowflakeConnectionPool and CacheManager.
All methods are async and return serialisable data.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, Union

from app.core.config import settings
from app.db.redis_client import cache_key, cache_manager, redis_manager
from app.db.snowflake_pool import snowflake_pool
from app.schemas.snowflake import (
    BatchDMLRequest,
    CacheTTLPreset,
    DMLRequest,
    ProcedureRequest,
    SQLQueryRequest,
)

logger = logging.getLogger(__name__)

# TTL preset → seconds
TTL_MAP: Dict[CacheTTLPreset, Optional[int]] = {
    CacheTTLPreset.NONE:    None,
    CacheTTLPreset.SHORT:   settings.CACHE_TTL_SHORT,
    CacheTTLPreset.DEFAULT: settings.CACHE_TTL_DEFAULT,
    CacheTTLPreset.LONG:    settings.CACHE_TTL_LONG,
    CacheTTLPreset.STATIC:  settings.CACHE_TTL_STATIC,
}


class SnowflakeService:

    # ── SELECT queries ────────────────────────────────────────────────────────

    async def execute_query(
        self,
        request: SQLQueryRequest,
        *,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        ttl = TTL_MAP.get(request.cache_ttl, settings.CACHE_TTL_DEFAULT)
        sql = self._inject_context(
            request.sql,
            database=request.database,
            schema=request.schema_name,
        )
        key = cache_key("query", sql, str(request.params), str(request.limit))

        # ── Cache read ───────────────────────────────────────────────────────
        if ttl and not request.force_refresh:
            cached = await redis_manager.get(key)
            if cached:
                remaining = await redis_manager.ttl(key)
                logger.info("Cache HIT query request_id=%s", request_id)
                cached["cached"] = True
                cached["cache_ttl_remaining"] = remaining
                cached["request_id"] = request_id
                return cached

        # ── Snowflake execution ──────────────────────────────────────────────
        start = time.monotonic()
        rows = await snowflake_pool.execute_query(
            sql,
            params=request.params,
            as_dict=True,
            limit=request.limit,
        )
        elapsed_ms = (time.monotonic() - start) * 1000

        columns = list(rows[0].keys()) if rows else []
        result = {
            "success": True,
            "rows": rows,
            "row_count": len(rows),
            "columns": columns,
            "execution_time_ms": round(elapsed_ms, 2),
            "cached": False,
            "cache_ttl_remaining": None,
            "request_id": request_id,
        }

        # ── Cache write ──────────────────────────────────────────────────────
        if ttl:
            await redis_manager.set(key, result, ttl=ttl)

        return result

    # ── Stored procedures ─────────────────────────────────────────────────────

    async def execute_procedure(
        self,
        request: ProcedureRequest,
        *,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        ttl = TTL_MAP.get(request.cache_ttl, settings.CACHE_TTL_DEFAULT)
        key = cache_key("proc", request.procedure, *request.args)

        # ── Cache read ───────────────────────────────────────────────────────
        if ttl and not request.force_refresh:
            cached = await redis_manager.get(key)
            if cached:
                remaining = await redis_manager.ttl(key)
                cached["cached"] = True
                cached["cache_ttl_remaining"] = remaining
                cached["request_id"] = request_id
                logger.info("Cache HIT procedure=%s request_id=%s", request.procedure, request_id)
                return cached

        # ── Snowflake execution ──────────────────────────────────────────────
        start = time.monotonic()
        raw = await snowflake_pool.execute_procedure(
            procedure=request.procedure,
            args=request.args,
            database=request.database,
            schema=request.schema_name,
        )
        elapsed_ms = (time.monotonic() - start) * 1000

        result = {
            "success": True,
            "procedure": request.procedure,
            "result": raw,
            "execution_time_ms": round(elapsed_ms, 2),
            "cached": False,
            "cache_ttl_remaining": None,
            "request_id": request_id,
        }

        # ── Cache write ──────────────────────────────────────────────────────
        if ttl:
            await redis_manager.set(key, result, ttl=ttl)

        return result

    # ── DML ───────────────────────────────────────────────────────────────────

    async def execute_dml(
        self,
        request: DMLRequest,
        *,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        start = time.monotonic()
        raw = await snowflake_pool.execute_dml(request.sql, params=request.params)
        elapsed_ms = (time.monotonic() - start) * 1000
        return {
            "success": True,
            "rows_affected": raw["rows_affected"],
            "query_id": raw.get("query_id"),
            "execution_time_ms": round(elapsed_ms, 2),
            "cached": False,
            "request_id": request_id,
        }

    # ── Batch DML ─────────────────────────────────────────────────────────────

    async def execute_batch_dml(
        self,
        request: BatchDMLRequest,
        *,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        start = time.monotonic()
        raw = await snowflake_pool.execute_many(
            request.sql,
            request.params_list,
            chunk_size=request.chunk_size,
        )
        elapsed_ms = (time.monotonic() - start) * 1000
        chunks = -(-len(request.params_list) // request.chunk_size)  # ceiling div
        return {
            "success": True,
            "rows_affected": raw["rows_affected"],
            "chunks_processed": chunks,
            "execution_time_ms": round(elapsed_ms, 2),
            "cached": False,
            "request_id": request_id,
        }

    # ── Multi-query fan-out (cross-domain) ────────────────────────────────────

    async def execute_parallel(
        self,
        queries: List[Dict[str, Any]],
        *,
        request_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Execute multiple queries concurrently using asyncio.gather.
        Each item in queries: {"sql": "...", "params": ..., "label": "...", "limit": ...}
        Returns results in the same order.
        """
        import asyncio

        async def _run_one(q: Dict[str, Any]) -> Dict[str, Any]:
            req = SQLQueryRequest(
                sql=q["sql"],
                params=q.get("params"),
                limit=q.get("limit", 1000),
                cache_ttl=CacheTTLPreset(q.get("cache_ttl", CacheTTLPreset.DEFAULT)),
            )
            result = await self.execute_query(req, request_id=request_id)
            result["label"] = q.get("label", "unnamed")
            return result

        start = time.monotonic()
        results = await asyncio.gather(*[_run_one(q) for q in queries], return_exceptions=True)
        elapsed_ms = (time.monotonic() - start) * 1000

        processed = []
        for r in results:
            if isinstance(r, Exception):
                processed.append({"success": False, "error": str(r)})
            else:
                processed.append(r)

        logger.info(
            "Parallel execution: %d queries in %.1fms (request_id=%s)",
            len(queries),
            elapsed_ms,
            request_id,
        )
        return processed

    # ── Session info ─────────────────────────────────────────────────────────

    async def get_session_info(self) -> Dict[str, Any]:
        sql = """
        SELECT
            CURRENT_DATABASE()  AS current_database,
            CURRENT_SCHEMA()    AS current_schema,
            CURRENT_WAREHOUSE() AS current_warehouse,
            CURRENT_ROLE()      AS current_role,
            CURRENT_USER()      AS current_user,
            CURRENT_VERSION()   AS snowflake_version,
            CURRENT_SESSION()   AS session_id
        """
        rows = await snowflake_pool.execute_query(sql, limit=1)
        return rows[0] if rows else {}

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _inject_context(
        sql: str,
        *,
        database: Optional[str],
        schema: Optional[str],
    ) -> str:
        """Prefix SQL with USE statements if overrides provided."""
        prefix_parts = []
        if database:
            prefix_parts.append(f"USE DATABASE {database};")
        if schema:
            prefix_parts.append(f"USE SCHEMA {schema};")
        if prefix_parts:
            return " ".join(prefix_parts) + " " + sql
        return sql


# Singleton
snowflake_service = SnowflakeService()
