"""Session info endpoint."""
from fastapi import APIRouter, Depends

from app.api.v1.deps import get_request_id, verify_api_key
from app.schemas.snowflake import SnowflakeInfoResponse
from app.services.snowflake_service import snowflake_service

router = APIRouter(dependencies=[Depends(verify_api_key)])


@router.get("/session", response_model=SnowflakeInfoResponse, summary="Snowflake session metadata")
async def session_info(request_id: str = Depends(get_request_id)) -> SnowflakeInfoResponse:
    info = await snowflake_service.get_session_info()
    return SnowflakeInfoResponse(success=True, request_id=request_id, **info)
