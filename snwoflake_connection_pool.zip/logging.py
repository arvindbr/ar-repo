"""Structured JSON logging for production; pretty for development."""
import logging
import sys

from app.core.config import settings


def setup_logging() -> None:
    fmt = (
        '{"time":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","msg":%(message)s}'
        if settings.ENVIRONMENT == "production"
        else "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    )
    logging.basicConfig(
        stream=sys.stdout,
        level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
        format=fmt,
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    # Silence noisy libraries
    for noisy in ("snowflake.connector", "urllib3", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
