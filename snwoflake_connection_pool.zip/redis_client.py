"""
Async Redis client — powered by redis.asyncio.
Provides:
  • RedisManager  — connection lifecycle + low-level get/set/delete
  • CacheManager  — high-level typed caching with TTL strategies
  • @cache()       — decorator for endpoint / service-level caching
  • cache_key()    — deterministic cache key builder
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar

import redis.asyncio as aioredis
from redis.asyncio.retry import Retry
from redis.backoff import ExponentialBackoff
from redis.exceptions import ConnectionError, RedisError, TimeoutError

from app.core.config import settings

logger = logging.getLogger(__name__)

T = TypeVar("T")


# ── Serialisation helpers ────────────────────────────────────────────────────

def _serialize(value: Any) -> str:
    return json.dumps(value, default=str)


def _deserialize(raw: str) -> Any:
    return json.loads(raw)


# ── Cache key builder ────────────────────────────────────────────────────────

def cache_key(*parts: Any, prefix: str = "sf") -> str:
    """
    Build a deterministic Redis key.
    e.g. cache_key("query", sql, params) → sf:query:<sha256>
    """
    raw = "|".join(str(p) for p in parts)
    digest = hashlib.sha256(raw.encode()).hexdigest()[:16]
    return f"{prefix}:{digest}"


def namespace_key(namespace: str, identifier: str) -> str:
    """Human-readable key: sf:procedures:get_nav_history"""
    return f"sf:{namespace}:{identifier}"


# ── Redis connection manager ─────────────────────────────────────────────────

class RedisManager:
    def __init__(self) -> None:
        self._client: Optional[aioredis.Redis] = None

    async def connect(self) -> None:
        retry = Retry(ExponentialBackoff(cap=10, base=0.5), retries=3)
        self._client = aioredis.from_url(
            settings.REDIS_URL,
            password=settings.REDIS_PASSWORD,
            max_connections=settings.REDIS_MAX_CONNECTIONS,
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=5,
            retry=retry,
            retry_on_error=[ConnectionError, TimeoutError],
            health_check_interval=30,
        )
        await self.ping()
        logger.info("Redis connected — %s", settings.REDIS_URL.split("@")[-1])

    async def disconnect(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None
        logger.info("Redis disconnected")

    @property
    def client(self) -> aioredis.Redis:
        if not self._client:
            raise RuntimeError("Redis not initialised — call connect() first")
        return self._client

    async def ping(self) -> bool:
        try:
            return await self._client.ping()
        except RedisError as exc:
            logger.warning("Redis ping failed: %s", exc)
            return False

    # ── Raw operations ───────────────────────────────────────────────────────

    async def get(self, key: str) -> Optional[Any]:
        try:
            raw = await self.client.get(key)
            return _deserialize(raw) if raw is not None else None
        except RedisError as exc:
            logger.warning("Redis GET %s failed: %s", key, exc)
            return None

    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
    ) -> bool:
        try:
            await self.client.set(
                key,
                _serialize(value),
                ex=ttl or settings.CACHE_TTL_DEFAULT,
            )
            return True
        except RedisError as exc:
            logger.warning("Redis SET %s failed: %s", key, exc)
            return False

    async def delete(self, key: str) -> int:
        try:
            return await self.client.delete(key)
        except RedisError as exc:
            logger.warning("Redis DEL %s failed: %s", key, exc)
            return 0

    async def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching a glob pattern — use sparingly in prod."""
        try:
            keys = await self.client.keys(pattern)
            if keys:
                return await self.client.delete(*keys)
            return 0
        except RedisError as exc:
            logger.warning("Redis pattern delete %s failed: %s", pattern, exc)
            return 0

    async def exists(self, key: str) -> bool:
        try:
            return bool(await self.client.exists(key))
        except RedisError:
            return False

    async def ttl(self, key: str) -> int:
        """Returns remaining TTL in seconds (-1 = no expiry, -2 = not found)."""
        try:
            return await self.client.ttl(key)
        except RedisError:
            return -2

    async def increment(self, key: str, amount: int = 1, ttl: Optional[int] = None) -> int:
        """Atomic increment — useful for rate limiting / counters."""
        try:
            pipe = self.client.pipeline()
            pipe.incr(key, amount)
            if ttl:
                pipe.expire(key, ttl)
            results = await pipe.execute()
            return results[0]
        except RedisError as exc:
            logger.warning("Redis INCR %s failed: %s", key, exc)
            return 0

    # ── Hash operations (for structured result sets) ─────────────────────────

    async def hset(self, key: str, mapping: Dict[str, Any], ttl: Optional[int] = None) -> bool:
        try:
            serialised = {k: _serialize(v) for k, v in mapping.items()}
            await self.client.hset(key, mapping=serialised)
            if ttl:
                await self.client.expire(key, ttl)
            return True
        except RedisError as exc:
            logger.warning("Redis HSET %s failed: %s", key, exc)
            return False

    async def hget(self, key: str, field: str) -> Optional[Any]:
        try:
            raw = await self.client.hget(key, field)
            return _deserialize(raw) if raw is not None else None
        except RedisError:
            return None

    async def hgetall(self, key: str) -> Dict[str, Any]:
        try:
            raw = await self.client.hgetall(key)
            return {k: _deserialize(v) for k, v in raw.items()}
        except RedisError:
            return {}


# ── High-level Cache Manager ─────────────────────────────────────────────────

class CacheManager:
    """
    Typed caching layer on top of RedisManager.
    Uses read-through pattern: check cache → miss → fetch → populate.
    """

    def __init__(self, redis: RedisManager) -> None:
        self._redis = redis

    async def get_or_set(
        self,
        key: str,
        fetcher: Callable,
        ttl: Optional[int] = None,
        *,
        force_refresh: bool = False,
    ) -> Any:
        """
        Read-through cache.
        fetcher must be an async callable returning the fresh value.
        """
        if not force_refresh:
            cached = await self._redis.get(key)
            if cached is not None:
                logger.debug("Cache HIT  — %s", key)
                return cached
        logger.debug("Cache MISS — %s", key)
        value = await fetcher()
        if value is not None:
            await self._redis.set(key, value, ttl=ttl)
        return value

    async def invalidate_namespace(self, namespace: str) -> int:
        """Invalidate all cached entries under a namespace prefix."""
        count = await self._redis.delete_pattern(f"sf:{namespace}:*")
        logger.info("Cache invalidated — namespace=%s, keys=%d", namespace, count)
        return count

    async def cache_procedure_result(
        self,
        procedure: str,
        args: List[Any],
        result: Any,
        ttl: Optional[int] = None,
    ) -> None:
        key = cache_key("proc", procedure, *args)
        await self._redis.set(key, result, ttl=ttl or settings.CACHE_TTL_DEFAULT)

    async def get_procedure_cache(
        self,
        procedure: str,
        args: List[Any],
    ) -> Optional[Any]:
        key = cache_key("proc", procedure, *args)
        return await self._redis.get(key)

    async def cache_query_result(
        self,
        sql: str,
        params: Any,
        result: Any,
        ttl: Optional[int] = None,
    ) -> None:
        key = cache_key("query", sql, params)
        await self._redis.set(key, result, ttl=ttl or settings.CACHE_TTL_DEFAULT)

    async def get_query_cache(self, sql: str, params: Any) -> Optional[Any]:
        key = cache_key("query", sql, params)
        return await self._redis.get(key)


# ── @cache() decorator ───────────────────────────────────────────────────────

def cache(
    ttl: int = 300,
    prefix: str = "endpoint",
    key_builder: Optional[Callable] = None,
    skip_cache_header: str = "X-Skip-Cache",
):
    """
    Decorator for FastAPI endpoint or service methods.

    Usage:
        @cache(ttl=60, prefix="perf")
        async def get_returns(fund_id: str) -> dict: ...

    The decorated function must accept **kwargs or request as first arg to
    support skip_cache_header inspection.
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Build cache key
            if key_builder:
                key = key_builder(*args, **kwargs)
            else:
                key = cache_key(prefix, func.__name__, *args, *sorted(kwargs.items()))

            # Allow callers to bypass cache via header
            request = kwargs.get("request") or (args[0] if args else None)
            skip = False
            if hasattr(request, "headers"):
                skip = request.headers.get(skip_cache_header, "").lower() == "true"

            if not skip:
                cached = await redis_manager.get(key)
                if cached is not None:
                    logger.debug("Decorator cache HIT — %s", key)
                    return cached

            result = await func(*args, **kwargs)
            if result is not None:
                await redis_manager.set(key, result, ttl=ttl)
            return result

        return wrapper
    return decorator


# ── Singletons ────────────────────────────────────────────────────────────────
redis_manager = RedisManager()
cache_manager = CacheManager(redis_manager)
