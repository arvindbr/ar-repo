"""
Centralised configuration — reads from environment variables / Azure Key Vault refs.
All sensitive values are injected at runtime via Azure Container Apps secrets.
"""
from __future__ import annotations

from functools import lru_cache
from typing import List, Optional

from pydantic import AnyHttpUrl, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    # ── App ──────────────────────────────────────────────────────────────────
    ENVIRONMENT: str = Field(default="development", description="development | staging | production")
    LOG_LEVEL: str = Field(default="INFO")
    CORS_ORIGINS: List[str] = Field(default=["*"])

    # ── Snowflake ─────────────────────────────────────────────────────────────
    SNOWFLAKE_ACCOUNT: str = Field(..., description="e.g. myorg-myaccount")
    SNOWFLAKE_USER: str = Field(...)
    SNOWFLAKE_PASSWORD: str = Field(...)
    SNOWFLAKE_DATABASE: str = Field(...)
    SNOWFLAKE_SCHEMA: str = Field(default="PUBLIC")
    SNOWFLAKE_WAREHOUSE: str = Field(...)
    SNOWFLAKE_ROLE: str = Field(default="SYSADMIN")

    # Pool config
    SNOWFLAKE_POOL_MIN_SIZE: int = Field(default=2)
    SNOWFLAKE_POOL_MAX_SIZE: int = Field(default=10)
    SNOWFLAKE_QUERY_TIMEOUT: int = Field(default=300, description="Seconds")

    # ── Redis ─────────────────────────────────────────────────────────────────
    REDIS_URL: str = Field(default="redis://localhost:6379/0", description="redis://host:port/db or rediss:// for TLS")
    REDIS_PASSWORD: Optional[str] = Field(default=None)
    REDIS_MAX_CONNECTIONS: int = Field(default=20)

    # Cache TTLs (seconds)
    CACHE_TTL_DEFAULT: int = Field(default=300,   description="5 minutes")
    CACHE_TTL_SHORT:   int = Field(default=60,    description="1 minute")
    CACHE_TTL_LONG:    int = Field(default=3600,  description="1 hour")
    CACHE_TTL_STATIC:  int = Field(default=86400, description="24 hours")

    # ── Azure Container Apps ──────────────────────────────────────────────────
    AZURE_TENANT_ID:        Optional[str] = None
    AZURE_CLIENT_ID:        Optional[str] = None  # Managed Identity client ID
    APPLICATIONINSIGHTS_CONNECTION_STRING: Optional[str] = None

    # ── Security ─────────────────────────────────────────────────────────────
    API_KEY_HEADER:  str = Field(default="X-API-Key")
    API_KEYS:        List[str] = Field(default=[], description="Comma-separated valid API keys")
    MAX_QUERY_ROWS:  int = Field(default=10_000, description="Hard cap on result rows")

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors(cls, v):
        if isinstance(v, str):
            return [o.strip() for o in v.split(",")]
        return v

    @field_validator("API_KEYS", mode="before")
    @classmethod
    def parse_api_keys(cls, v):
        if isinstance(v, str):
            return [k.strip() for k in v.split(",") if k.strip()]
        return v


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
