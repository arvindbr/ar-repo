"""
Pydantic v2 schemas for all API request/response payloads.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator


# ── Enums ────────────────────────────────────────────────────────────────────

class CacheTTLPreset(str, Enum):
    NONE   = "none"
    SHORT  = "short"    # 60s
    DEFAULT = "default" # 300s
    LONG   = "long"     # 3600s
    STATIC = "static"   # 86400s


class OutputFormat(str, Enum):
    JSON  = "json"
    CSV   = "csv"


# ── Base ─────────────────────────────────────────────────────────────────────

class BaseResponse(BaseModel):
    success: bool
    request_id: Optional[str] = None
    cached: bool = False
    cache_ttl_remaining: Optional[int] = None  # seconds


# ── SQL Query ─────────────────────────────────────────────────────────────────

class SQLQueryRequest(BaseModel):
    sql: str = Field(..., min_length=5, max_length=50_000, description="SQL SELECT statement")
    params: Optional[Union[List[Any], Dict[str, Any]]] = Field(
        default=None, description="Bind parameters — list for positional, dict for named"
    )
    database: Optional[str] = Field(default=None, description="Override default database")
    schema_name: Optional[str] = Field(default=None, alias="schema", description="Override default schema")
    limit: Optional[int] = Field(default=1000, ge=1, le=10_000)
    cache_ttl: CacheTTLPreset = Field(default=CacheTTLPreset.DEFAULT)
    force_refresh: bool = Field(default=False, description="Bypass cache and re-execute")
    output_format: OutputFormat = Field(default=OutputFormat.JSON)

    @field_validator("sql")
    @classmethod
    def no_dml_in_query(cls, v: str) -> str:
        lowered = v.strip().lower()
        forbidden = ("insert ", "update ", "delete ", "drop ", "truncate ", "create ", "alter ", "merge ")
        for word in forbidden:
            if lowered.startswith(word):
                raise ValueError(f"SQLQueryRequest only allows SELECT — use /dml for writes. Found: {word.strip()}")
        return v

    model_config = {"populate_by_name": True}


class SQLQueryResponse(BaseResponse):
    rows: List[Dict[str, Any]]
    row_count: int
    columns: List[str]
    execution_time_ms: float
    query_id: Optional[str] = None


# ── Stored Procedure ─────────────────────────────────────────────────────────

class ProcedureRequest(BaseModel):
    procedure: str = Field(
        ...,
        pattern=r"^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)*$",
        description="Procedure name — optionally schema-qualified, e.g. FINANCE.GET_NAV",
    )
    args: List[Any] = Field(default=[], description="Positional arguments for the procedure")
    database: Optional[str] = None
    schema_name: Optional[str] = Field(default=None, alias="schema")
    cache_ttl: CacheTTLPreset = Field(default=CacheTTLPreset.DEFAULT)
    force_refresh: bool = False

    model_config = {"populate_by_name": True}


class ProcedureResponse(BaseResponse):
    procedure: str
    result: Any
    execution_time_ms: float


# ── DML ───────────────────────────────────────────────────────────────────────

class DMLRequest(BaseModel):
    sql: str = Field(..., min_length=5, max_length=50_000)
    params: Optional[Union[List[Any], Dict[str, Any]]] = None

    @field_validator("sql")
    @classmethod
    def must_be_dml(cls, v: str) -> str:
        lowered = v.strip().lower()
        allowed = ("insert ", "update ", "delete ", "merge ", "call ")
        if not any(lowered.startswith(w) for w in allowed):
            raise ValueError("DMLRequest requires INSERT/UPDATE/DELETE/MERGE/CALL")
        return v


class DMLResponse(BaseResponse):
    rows_affected: int
    query_id: Optional[str] = None
    execution_time_ms: float


# ── Batch DML ─────────────────────────────────────────────────────────────────

class BatchDMLRequest(BaseModel):
    sql: str = Field(..., description="Parameterised DML — executed for each params entry")
    params_list: List[Union[List[Any], Dict[str, Any]]] = Field(
        ..., min_length=1, max_length=50_000
    )
    chunk_size: int = Field(default=1000, ge=100, le=5000)


class BatchDMLResponse(BaseResponse):
    rows_affected: int
    chunks_processed: int
    execution_time_ms: float


# ── Cache management ─────────────────────────────────────────────────────────

class CacheInvalidateRequest(BaseModel):
    namespace: Optional[str] = Field(default=None, description="Invalidate all keys under this namespace")
    keys: Optional[List[str]] = Field(default=None, description="Specific cache keys to delete")

    @model_validator(mode="after")
    def at_least_one(self) -> CacheInvalidateRequest:
        if not self.namespace and not self.keys:
            raise ValueError("Provide at least 'namespace' or 'keys'")
        return self


class CacheInvalidateResponse(BaseResponse):
    keys_deleted: int


class CacheStatsResponse(BaseResponse):
    redis_connected: bool
    used_memory_human: str
    total_keys: int
    hit_rate: Optional[float] = None


# ── Error ─────────────────────────────────────────────────────────────────────

class ErrorDetail(BaseModel):
    error: str
    message: str
    request_id: Optional[str] = None


# ── Metadata ─────────────────────────────────────────────────────────────────

class SnowflakeInfoResponse(BaseResponse):
    current_database: str
    current_schema: str
    current_warehouse: str
    current_role: str
    current_user: str
    snowflake_version: str
    session_id: str
