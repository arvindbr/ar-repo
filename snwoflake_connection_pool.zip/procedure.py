"""Stored procedure endpoints."""
from fastapi import APIRouter, Depends, HTTPException, status

from app.api.v1.deps import get_request_id, verify_api_key
from app.schemas.snowflake import ProcedureRequest, ProcedureResponse
from app.services.snowflake_service import snowflake_service

router = APIRouter(dependencies=[Depends(verify_api_key)])


@router.post(
    "/call",
    response_model=ProcedureResponse,
    summary="Call a Snowflake stored procedure",
    description=(
        "Invoke any stored procedure via `CALL <proc>(<args>)`. "
        "Procedure results are cached based on `cache_ttl`. "
        "Write-side procedures should use `cache_ttl: none`."
    ),
)
async def call_procedure(
    body: ProcedureRequest,
    request_id: str = Depends(get_request_id),
) -> ProcedureResponse:
    try:
        result = await snowflake_service.execute_procedure(body, request_id=request_id)
        return ProcedureResponse(**result)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "procedure_failed", "message": str(exc)},
        ) from exc


@router.post(
    "/call/{procedure_name}",
    response_model=ProcedureResponse,
    summary="Call a procedure by path param",
)
async def call_procedure_by_name(
    procedure_name: str,
    args: list = None,
    request_id: str = Depends(get_request_id),
) -> ProcedureResponse:
    """Convenience endpoint — procedure name in URL path, args in body."""
    body = ProcedureRequest(procedure=procedure_name, args=args or [])
    try:
        result = await snowflake_service.execute_procedure(body, request_id=request_id)
        return ProcedureResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
