"""API v1 router — aggregates all domain endpoint routers."""
from fastapi import APIRouter

from app.api.v1.endpoints import query, procedure, dml, cache, info

api_router = APIRouter()

api_router.include_router(query.router,     prefix="/query",     tags=["SQL Queries"])
api_router.include_router(procedure.router, prefix="/procedure", tags=["Stored Procedures"])
api_router.include_router(dml.router,       prefix="/dml",       tags=["DML / Writes"])
api_router.include_router(cache.router,     prefix="/cache",     tags=["Cache Management"])
api_router.include_router(info.router,      prefix="/info",      tags=["Session Info"])
