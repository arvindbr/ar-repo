"""FastAPI dependency injection utilities."""
from fastapi import Header, HTTPException, Request, Security, status
from fastapi.security.api_key import APIKeyHeader

from app.core.config import settings

_api_key_header = APIKeyHeader(name=settings.API_KEY_HEADER, auto_error=False)


async def verify_api_key(api_key: str = Security(_api_key_header)) -> str:
    """Validate API key from request header. Skip if no keys configured (dev mode)."""
    if not settings.API_KEYS:
        return "dev"  # Open in development
    if not api_key or api_key not in settings.API_KEYS:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "unauthorized", "message": "Invalid or missing API key"},
            headers={"WWW-Authenticate": "ApiKey"},
        )
    return api_key


async def get_request_id(request: Request) -> str:
    """Extract request ID injected by RequestIDMiddleware."""
    return getattr(request.state, "request_id", "unknown")
