"""Cache management endpoints."""
from fastapi import APIRouter, Depends, HTTPException

from app.api.v1.deps import get_request_id, verify_api_key
from app.db.redis_client import cache_manager, redis_manager
from app.schemas.snowflake import CacheInvalidateRequest, CacheInvalidateResponse, CacheStatsResponse

router = APIRouter(dependencies=[Depends(verify_api_key)])


@router.post("/invalidate", response_model=CacheInvalidateResponse, summary="Invalidate cache entries")
async def invalidate_cache(
    body: CacheInvalidateRequest,
    request_id: str = Depends(get_request_id),
) -> CacheInvalidateResponse:
    deleted = 0
    try:
        if body.namespace:
            deleted += await cache_manager.invalidate_namespace(body.namespace)
        if body.keys:
            for k in body.keys:
                deleted += await redis_manager.delete(k)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return CacheInvalidateResponse(success=True, keys_deleted=deleted, request_id=request_id)


@router.get("/stats", response_model=CacheStatsResponse, summary="Redis cache statistics")
async def cache_stats(request_id: str = Depends(get_request_id)) -> CacheStatsResponse:
    try:
        info = await redis_manager.client.info("memory")
        keyspace = await redis_manager.client.info("keyspace")
        total_keys = sum(
            int(v.split(",")[0].split("=")[1])
            for v in keyspace.values()
            if isinstance(v, str) and "keys=" in v
        )
        stats_info = await redis_manager.client.info("stats")
        hits = int(stats_info.get("keyspace_hits", 0))
        misses = int(stats_info.get("keyspace_misses", 0))
        hit_rate = round(hits / (hits + misses), 4) if (hits + misses) > 0 else None
        return CacheStatsResponse(
            success=True,
            redis_connected=True,
            used_memory_human=info.get("used_memory_human", "N/A"),
            total_keys=total_keys,
            hit_rate=hit_rate,
            request_id=request_id,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
