"""
Test suite for Snowflake MCP API.
Uses pytest-asyncio + httpx AsyncClient.
Snowflake calls are mocked; Redis uses a real in-process fakeredis.
"""
from __future__ import annotations

import json
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

# ── App bootstrap (patch heavy dependencies before import) ────────────────────

@pytest.fixture(scope="session", autouse=True)
def patch_lifespan():
    """
    Prevent real Snowflake + Redis connections during tests.
    We patch pool/redis at the module level before the app is imported.
    """
    with (
        patch("app.db.snowflake_pool.SnowflakeConnectionPool.initialise", new_callable=AsyncMock),
        patch("app.db.snowflake_pool.SnowflakeConnectionPool.close",      new_callable=AsyncMock),
        patch("app.db.redis_client.RedisManager.connect",                 new_callable=AsyncMock),
        patch("app.db.redis_client.RedisManager.disconnect",              new_callable=AsyncMock),
        patch("app.db.redis_client.RedisManager.ping",                    new_callable=AsyncMock, return_value=True),
        patch("app.db.snowflake_pool.SnowflakeConnectionPool.ping",       new_callable=AsyncMock, return_value=True),
    ):
        yield


@pytest_asyncio.fixture
async def client():
    from app.main import app
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


# ── Helpers ───────────────────────────────────────────────────────────────────

def _mock_redis_miss():
    """Redis returns None (cache miss) for all gets."""
    m = AsyncMock()
    m.get = AsyncMock(return_value=None)
    m.set = AsyncMock(return_value=True)
    m.ttl = AsyncMock(return_value=-2)
    m.delete = AsyncMock(return_value=1)
    m.ping = AsyncMock(return_value=True)
    return m


SAMPLE_ROWS = [
    {"FUND_ID": "F001", "NAV": 100.5, "DATE": "2024-01-01"},
    {"FUND_ID": "F002", "NAV": 98.2,  "DATE": "2024-01-01"},
]


# ── Health endpoints ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_liveness(client):
    resp = await client.get("/healthz")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert "timestamp" in data


@pytest.mark.asyncio
async def test_readiness(client):
    resp = await client.get("/readyz")
    assert resp.status_code == 200
    data = resp.json()
    assert data["snowflake"] in ("ok", "unavailable")
    assert data["redis"] in ("ok", "unavailable")


# ── Query endpoint ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_execute_query_success(client):
    with (
        patch("app.db.redis_client.redis_manager.get",  new_callable=AsyncMock, return_value=None),
        patch("app.db.redis_client.redis_manager.set",  new_callable=AsyncMock, return_value=True),
        patch("app.db.redis_client.redis_manager.ttl",  new_callable=AsyncMock, return_value=-2),
        patch(
            "app.db.snowflake_pool.snowflake_pool.execute_query",
            new_callable=AsyncMock,
            return_value=SAMPLE_ROWS,
        ),
    ):
        resp = await client.post(
            "/api/v1/query/execute",
            json={"sql": "SELECT * FROM nav_history", "limit": 100},
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["row_count"] == 2
    assert body["rows"] == SAMPLE_ROWS
    assert body["cached"] is False
    assert "execution_time_ms" in body


@pytest.mark.asyncio
async def test_execute_query_cache_hit(client):
    cached_payload = {
        "success": True,
        "rows": SAMPLE_ROWS,
        "row_count": 2,
        "columns": ["FUND_ID", "NAV", "DATE"],
        "execution_time_ms": 5.0,
        "cached": False,
    }
    with (
        patch("app.db.redis_client.redis_manager.get",  new_callable=AsyncMock, return_value=cached_payload),
        patch("app.db.redis_client.redis_manager.ttl",  new_callable=AsyncMock, return_value=250),
    ):
        resp = await client.post(
            "/api/v1/query/execute",
            json={"sql": "SELECT * FROM nav_history", "limit": 100},
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["cached"] is True
    assert body["cache_ttl_remaining"] == 250


@pytest.mark.asyncio
async def test_execute_query_rejects_dml(client):
    resp = await client.post(
        "/api/v1/query/execute",
        json={"sql": "DELETE FROM nav_history WHERE 1=1"},
    )
    assert resp.status_code == 422  # pydantic validation error


@pytest.mark.asyncio
async def test_execute_query_limit_enforced(client):
    """Limit above 10_000 should be rejected by schema."""
    resp = await client.post(
        "/api/v1/query/execute",
        json={"sql": "SELECT 1", "limit": 99999},
    )
    assert resp.status_code == 422


# ── Procedure endpoint ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_call_procedure_success(client):
    proc_result = {"RESULT": json.dumps({"status": "ok", "nav": 105.2})}
    with (
        patch("app.db.redis_client.redis_manager.get",  new_callable=AsyncMock, return_value=None),
        patch("app.db.redis_client.redis_manager.set",  new_callable=AsyncMock, return_value=True),
        patch("app.db.redis_client.redis_manager.ttl",  new_callable=AsyncMock, return_value=-2),
        patch(
            "app.db.snowflake_pool.snowflake_pool.execute_procedure",
            new_callable=AsyncMock,
            return_value=proc_result,
        ),
    ):
        resp = await client.post(
            "/api/v1/procedure/call",
            json={
                "procedure": "FINANCE.GET_NAV_HISTORY",
                "args": ["F001", "2024-01-01"],
                "cache_ttl": "default",
            },
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["success"] is True
    assert body["procedure"] == "FINANCE.GET_NAV_HISTORY"
    assert body["result"] == proc_result


@pytest.mark.asyncio
async def test_call_procedure_invalid_name(client):
    resp = await client.post(
        "/api/v1/procedure/call",
        json={"procedure": "DROP TABLE users; --", "args": []},
    )
    assert resp.status_code == 422


# ── DML endpoint ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_execute_dml_success(client):
    with patch(
        "app.db.snowflake_pool.snowflake_pool.execute_dml",
        new_callable=AsyncMock,
        return_value={"rows_affected": 5, "query_id": "abc123", "status": "success"},
    ):
        resp = await client.post(
            "/api/v1/dml/execute",
            json={"sql": "INSERT INTO audit_log (event) VALUES (%s)", "params": ["login"]},
        )
    assert resp.status_code == 200
    body = resp.json()
    assert body["rows_affected"] == 5
    assert body["query_id"] == "abc123"


@pytest.mark.asyncio
async def test_dml_rejects_select(client):
    resp = await client.post(
        "/api/v1/dml/execute",
        json={"sql": "SELECT 1"},
    )
    assert resp.status_code == 422


# ── Parallel query ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_parallel_queries(client):
    with (
        patch("app.db.redis_client.redis_manager.get",  new_callable=AsyncMock, return_value=None),
        patch("app.db.redis_client.redis_manager.set",  new_callable=AsyncMock, return_value=True),
        patch("app.db.redis_client.redis_manager.ttl",  new_callable=AsyncMock, return_value=-2),
        patch(
            "app.db.snowflake_pool.snowflake_pool.execute_query",
            new_callable=AsyncMock,
            return_value=SAMPLE_ROWS,
        ),
    ):
        resp = await client.post(
            "/api/v1/query/parallel",
            json=[
                {"sql": "SELECT * FROM perf",  "label": "perf",  "limit": 10},
                {"sql": "SELECT * FROM aum",   "label": "aum",   "limit": 10},
                {"sql": "SELECT * FROM risk",  "label": "risk",  "limit": 10},
            ],
        )
    assert resp.status_code == 200
    results = resp.json()
    assert len(results) == 3
    for r in results:
        assert r["success"] is True
        assert r["row_count"] == 2


@pytest.mark.asyncio
async def test_parallel_queries_max_limit(client):
    queries = [{"sql": "SELECT 1", "label": f"q{i}"} for i in range(21)]
    resp = await client.post("/api/v1/query/parallel", json=queries)
    assert resp.status_code == 400


# ── Request ID propagation ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_request_id_header_propagated(client):
    with (
        patch("app.db.redis_client.redis_manager.get",  new_callable=AsyncMock, return_value=None),
        patch("app.db.redis_client.redis_manager.set",  new_callable=AsyncMock, return_value=True),
        patch("app.db.redis_client.redis_manager.ttl",  new_callable=AsyncMock, return_value=-2),
        patch(
            "app.db.snowflake_pool.snowflake_pool.execute_query",
            new_callable=AsyncMock,
            return_value=[],
        ),
    ):
        resp = await client.post(
            "/api/v1/query/execute",
            json={"sql": "SELECT 1"},
            headers={"X-Request-ID": "test-req-42"},
        )
    assert resp.headers.get("X-Request-ID") == "test-req-42"


# ── Cache key determinism ─────────────────────────────────────────────────────

def test_cache_key_deterministic():
    from app.db.redis_client import cache_key
    k1 = cache_key("query", "SELECT 1", None, 1000)
    k2 = cache_key("query", "SELECT 1", None, 1000)
    assert k1 == k2


def test_cache_key_different_inputs():
    from app.db.redis_client import cache_key
    k1 = cache_key("query", "SELECT 1")
    k2 = cache_key("query", "SELECT 2")
    assert k1 != k2


# ── Schema validation ─────────────────────────────────────────────────────────

def test_procedure_name_regex_blocks_injection():
    from pydantic import ValidationError
    from app.schemas.snowflake import ProcedureRequest
    with pytest.raises(ValidationError):
        ProcedureRequest(procedure="'; DROP TABLE users; --", args=[])


def test_procedure_name_allows_qualified():
    from app.schemas.snowflake import ProcedureRequest
    p = ProcedureRequest(procedure="FINANCE.GET_NAV_HISTORY", args=["F001"])
    assert p.procedure == "FINANCE.GET_NAV_HISTORY"
