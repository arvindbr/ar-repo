"""SQL query endpoints — SELECT only."""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, Request, status

from app.api.v1.deps import get_request_id, verify_api_key
from app.schemas.snowflake import SQLQueryRequest, SQLQueryResponse
from app.services.snowflake_service import snowflake_service

router = APIRouter(dependencies=[Depends(verify_api_key)])


@router.post(
    "/execute",
    response_model=SQLQueryResponse,
    summary="Execute a SELECT query",
    description=(
        "Run any read-only SQL against Snowflake. "
        "Results are cached in Redis according to `cache_ttl`. "
        "Pass `force_refresh: true` or header `X-Skip-Cache: true` to bypass."
    ),
)
async def execute_query(
    body: SQLQueryRequest,
    request: Request,
    request_id: str = Depends(get_request_id),
) -> SQLQueryResponse:
    # Allow X-Skip-Cache header to force bypass
    if request.headers.get("X-Skip-Cache", "").lower() == "true":
        body.force_refresh = True
    try:
        result = await snowflake_service.execute_query(body, request_id=request_id)
        return SQLQueryResponse(**result)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "query_failed", "message": str(exc)},
        ) from exc


@router.post(
    "/parallel",
    summary="Execute multiple queries concurrently",
    description=(
        "Fan-out multiple SELECT queries in parallel via asyncio.gather. "
        "Returns results in the same order as the input list."
    ),
)
async def execute_parallel(
    queries: List[dict],
    request_id: str = Depends(get_request_id),
):
    if not queries:
        raise HTTPException(status_code=400, detail="queries list must not be empty")
    if len(queries) > 20:
        raise HTTPException(status_code=400, detail="Maximum 20 parallel queries per request")
    try:
        return await snowflake_service.execute_parallel(queries, request_id=request_id)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
