# Snowflake MCP API

**FastAPI · Async · Azure Container Apps · Redis Caching**

Production-ready REST API for invoking Snowflake stored procedures and SQL queries,
deployed as an Azure Container App with Redis read-through caching.

---

## Architecture

```
Clients (AI Agents · Apps · Pipelines)
         │  HTTPS + X-API-Key
         ▼
┌─────────────────────────────────────────────┐
│           FastAPI  (Gunicorn + Uvicorn)      │
│                                              │
│  POST /api/v1/query/execute                  │
│  POST /api/v1/query/parallel   ──── asyncio  │
│  POST /api/v1/procedure/call   ──── gather   │
│  POST /api/v1/dml/execute                   │
│  POST /api/v1/dml/batch                     │
│  GET  /api/v1/cache/stats                   │
│  POST /api/v1/cache/invalidate              │
│  GET  /api/v1/info/session                  │
└──────────────┬──────────────────────────────┘
               │
       ┌───────┴────────┐
       ▼                ▼
  Redis Cache     Snowflake Pool
  (read-through)  (ThreadPoolExecutor)
  TTL: 60s–24h    Min 2, Max 10 conns
```

## Quick Start

```bash
cp .env.example .env   # fill in Snowflake + Redis creds
docker compose up      # spins up Redis + API
```

API docs at http://localhost:8000/docs

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/query/execute` | Execute a SELECT query |
| `POST` | `/api/v1/query/parallel` | Fan-out up to 20 queries in parallel |
| `POST` | `/api/v1/procedure/call` | Call a stored procedure via `CALL` |
| `POST` | `/api/v1/procedure/call/{name}` | Call procedure by path param |
| `POST` | `/api/v1/dml/execute` | INSERT / UPDATE / DELETE |
| `POST` | `/api/v1/dml/batch` | Batch DML with `executemany` |
| `POST` | `/api/v1/cache/invalidate` | Invalidate cache by namespace or keys |
| `GET`  | `/api/v1/cache/stats` | Redis memory + hit rate stats |
| `GET`  | `/api/v1/info/session` | Snowflake session metadata |
| `GET`  | `/healthz` | Liveness probe |
| `GET`  | `/readyz` | Readiness probe (checks SF + Redis) |

## Cache TTL Presets

| Preset | TTL | Use case |
|--------|-----|----------|
| `none` | — | Write procedures, DML |
| `short` | 60s | Rapidly changing data |
| `default` | 5min | Most queries |
| `long` | 1hr | Reference/lookup data |
| `static` | 24hr | Rarely changing config |

Override per-request with `"cache_ttl": "long"` in the request body.
Force bypass with `"force_refresh": true` or header `X-Skip-Cache: true`.

## Request Examples

### SELECT query
```bash
curl -X POST https://<app>.azurecontainerapps.io/api/v1/query/execute \
  -H "X-API-Key: your-key" \
  -H "Content-Type: application/json" \
  -d '{
    "sql": "SELECT fund_id, nav, nav_date FROM nav_history WHERE fund_id = %s",
    "params": ["F001"],
    "limit": 500,
    "cache_ttl": "default"
  }'
```

### Stored procedure
```bash
curl -X POST .../api/v1/procedure/call \
  -H "X-API-Key: your-key" \
  -d '{
    "procedure": "FINANCE.CALC_PERFORMANCE",
    "args": ["F001", "2024-01-01", "2024-12-31"],
    "cache_ttl": "long"
  }'
```

### Parallel fan-out
```bash
curl -X POST .../api/v1/query/parallel \
  -H "X-API-Key: your-key" \
  -d '[
    {"sql": "SELECT * FROM perf_summary",  "label": "performance", "limit": 100},
    {"sql": "SELECT * FROM aum_snapshot",  "label": "aum",         "limit": 100},
    {"sql": "SELECT * FROM risk_metrics",  "label": "risk",        "limit": 100}
  ]'
```

### Invalidate cache
```bash
curl -X POST .../api/v1/cache/invalidate \
  -H "X-API-Key: your-key" \
  -d '{"namespace": "proc"}'
```

## Deploy to Azure

```bash
# 1. Login
az login

# 2. Create resource group
az group create --name rg-sf-mcp-api --location eastus

# 3. Deploy infrastructure
az deployment group create \
  --resource-group rg-sf-mcp-api \
  --template-file infra/bicep/main.bicep \
  --parameters \
    environment=production \
    snowflakeAccount="myorg-myaccount" \
    snowflakeUser="svc_user" \
    snowflakePassword="<secret>" \
    snowflakeDatabase="FINANCE_DB" \
    snowflakeWarehouse="COMPUTE_WH" \
    apiKey="<generate-strong-key>"

# 4. Build & push image
ACR=$(az deployment group show -g rg-sf-mcp-api -n main \
      --query properties.outputs.acrLoginServer.value -o tsv)
az acr login --name ${ACR%%.*}
docker build -t $ACR/sf-mcp-api:latest --target runtime .
docker push $ACR/sf-mcp-api:latest
```

## Tests

```bash
pytest tests/ -v --cov=app
```

## Environment Variables

See `.env.example` for the full list.
All secrets are injected at runtime via Azure Key Vault references —
never stored in the container image.
