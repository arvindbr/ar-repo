"""
Async Snowflake connection pool.

Snowflake's Python connector is synchronous, so we wrap every blocking call
in asyncio.get_event_loop().run_in_executor() with a dedicated ThreadPoolExecutor.
This keeps the FastAPI event loop non-blocking while allowing true concurrent
Snowflake queries up to SNOWFLAKE_POOL_MAX_SIZE threads.
"""
from __future__ import annotations

import asyncio
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional, Tuple

import snowflake.connector
from snowflake.connector import DictCursor

from app.core.config import settings

logger = logging.getLogger(__name__)


class SnowflakeConnectionPool:
    """Thread-pool-backed async Snowflake connection manager."""

    def __init__(self) -> None:
        self._pool: List[snowflake.connector.SnowflakeConnection] = []
        self._lock = asyncio.Lock()
        self._executor: Optional[ThreadPoolExecutor] = None
        self._initialised = False

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def initialise(self) -> None:
        if self._initialised:
            return
        self._executor = ThreadPoolExecutor(
            max_workers=settings.SNOWFLAKE_POOL_MAX_SIZE,
            thread_name_prefix="sf-worker",
        )
        # Pre-warm minimum connections
        loop = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(self._executor, self._create_connection)
            for _ in range(settings.SNOWFLAKE_POOL_MIN_SIZE)
        ]
        connections = await asyncio.gather(*tasks, return_exceptions=True)
        for conn in connections:
            if isinstance(conn, Exception):
                logger.warning("Pre-warm connection failed: %s", conn)
            else:
                self._pool.append(conn)
        self._initialised = True
        logger.info(
            "Snowflake pool initialised — %d/%d connections ready",
            len(self._pool),
            settings.SNOWFLAKE_POOL_MAX_SIZE,
        )

    async def close(self) -> None:
        loop = asyncio.get_event_loop()
        close_tasks = [
            loop.run_in_executor(self._executor, conn.close)
            for conn in self._pool
        ]
        await asyncio.gather(*close_tasks, return_exceptions=True)
        self._pool.clear()
        if self._executor:
            self._executor.shutdown(wait=True)
        logger.info("Snowflake pool closed")

    # ── Internal ─────────────────────────────────────────────────────────────

    def _create_connection(self) -> snowflake.connector.SnowflakeConnection:
        return snowflake.connector.connect(
            account=settings.SNOWFLAKE_ACCOUNT,
            user=settings.SNOWFLAKE_USER,
            password=settings.SNOWFLAKE_PASSWORD,
            database=settings.SNOWFLAKE_DATABASE,
            schema=settings.SNOWFLAKE_SCHEMA,
            warehouse=settings.SNOWFLAKE_WAREHOUSE,
            role=settings.SNOWFLAKE_ROLE,
            network_timeout=30,
            login_timeout=30,
            query_tag="snowflake-mcp-api",
        )

    def _is_alive(self, conn: snowflake.connector.SnowflakeConnection) -> bool:
        try:
            conn.cursor().execute("SELECT 1")
            return True
        except Exception:
            return False

    async def _acquire(self) -> snowflake.connector.SnowflakeConnection:
        async with self._lock:
            # Reuse healthy pooled connection
            while self._pool:
                conn = self._pool.pop()
                loop = asyncio.get_event_loop()
                alive = await loop.run_in_executor(self._executor, self._is_alive, conn)
                if alive:
                    return conn
                logger.debug("Discarding dead connection, creating new one")

            # Pool empty — create on demand (up to max)
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(self._executor, self._create_connection)

    async def _release(self, conn: snowflake.connector.SnowflakeConnection) -> None:
        async with self._lock:
            if len(self._pool) < settings.SNOWFLAKE_POOL_MAX_SIZE:
                self._pool.append(conn)
            else:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(self._executor, conn.close)

    @asynccontextmanager
    async def connection(self):
        """Async context manager — yields a Snowflake connection."""
        conn = await self._acquire()
        try:
            yield conn
        except Exception:
            # Don't return broken connections
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(self._executor, conn.close)
            raise
        else:
            await self._release(conn)

    # ── Query helpers ─────────────────────────────────────────────────────────

    async def execute_query(
        self,
        sql: str,
        params: Optional[Tuple | Dict] = None,
        *,
        as_dict: bool = True,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Execute a raw SQL query and return rows."""
        effective_limit = min(limit or settings.MAX_QUERY_ROWS, settings.MAX_QUERY_ROWS)

        def _run(conn):
            cursor_cls = DictCursor if as_dict else conn.cursor().__class__
            with conn.cursor(cursor_cls) as cur:
                cur.execute(sql, params)
                return cur.fetchmany(effective_limit)

        loop = asyncio.get_event_loop()
        start = time.monotonic()
        async with self.connection() as conn:
            rows = await loop.run_in_executor(self._executor, _run, conn)
        elapsed = time.monotonic() - start
        logger.debug("Query executed in %.3fs, rows=%d", elapsed, len(rows))
        return rows

    async def execute_procedure(
        self,
        procedure: str,
        args: Optional[List[Any]] = None,
        *,
        database: Optional[str] = None,
        schema: Optional[str] = None,
    ) -> Any:
        """Call a stored procedure via CALL statement."""
        args = args or []
        placeholders = ", ".join(["%s"] * len(args))
        db_prefix = ""
        if database and schema:
            db_prefix = f"{database}.{schema}."
        elif schema:
            db_prefix = f"{schema}."

        sql = f"CALL {db_prefix}{procedure}({placeholders})"

        def _run(conn):
            with conn.cursor(DictCursor) as cur:
                cur.execute(sql, args)
                return cur.fetchone()

        loop = asyncio.get_event_loop()
        start = time.monotonic()
        async with self.connection() as conn:
            result = await loop.run_in_executor(self._executor, _run, conn)
        elapsed = time.monotonic() - start
        logger.debug("Procedure %s executed in %.3fs", procedure, elapsed)
        return result

    async def execute_dml(
        self,
        sql: str,
        params: Optional[Tuple | Dict] = None,
    ) -> Dict[str, Any]:
        """Execute INSERT / UPDATE / DELETE and return rowcount + query_id."""

        def _run(conn):
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return {
                    "rows_affected": cur.rowcount,
                    "query_id": cur.sfqid,
                    "status": "success",
                }

        loop = asyncio.get_event_loop()
        async with self.connection() as conn:
            return await loop.run_in_executor(self._executor, _run, conn)

    async def execute_many(
        self,
        sql: str,
        params_list: List[Tuple | Dict],
        *,
        chunk_size: int = 1000,
    ) -> Dict[str, Any]:
        """Batch insert/update using executemany in chunks."""
        total_rows = 0

        def _chunk(conn, chunk):
            with conn.cursor() as cur:
                cur.executemany(sql, chunk)
                return cur.rowcount

        loop = asyncio.get_event_loop()
        async with self.connection() as conn:
            for i in range(0, len(params_list), chunk_size):
                chunk = params_list[i : i + chunk_size]
                rows = await loop.run_in_executor(self._executor, _chunk, conn, chunk)
                total_rows += rows or len(chunk)

        return {"rows_affected": total_rows, "status": "success"}

    async def ping(self) -> bool:
        """Health check — returns True if Snowflake is reachable."""
        try:
            await self.execute_query("SELECT CURRENT_TIMESTAMP AS ts", limit=1)
            return True
        except Exception as exc:
            logger.warning("Snowflake ping failed: %s", exc)
            return False


# Singleton
snowflake_pool = SnowflakeConnectionPool()
