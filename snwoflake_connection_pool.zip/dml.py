"""DML write endpoints."""
from fastapi import APIRouter, Depends, HTTPException, status

from app.api.v1.deps import get_request_id, verify_api_key
from app.schemas.snowflake import BatchDMLRequest, BatchDMLResponse, DMLRequest, DMLResponse
from app.services.snowflake_service import snowflake_service

router = APIRouter(dependencies=[Depends(verify_api_key)])


@router.post("/execute", response_model=DMLResponse, summary="Execute a DML statement")
async def execute_dml(
    body: DMLRequest,
    request_id: str = Depends(get_request_id),
) -> DMLResponse:
    try:
        result = await snowflake_service.execute_dml(body, request_id=request_id)
        return DMLResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/batch", response_model=BatchDMLResponse, summary="Batch DML with executemany")
async def execute_batch_dml(
    body: BatchDMLRequest,
    request_id: str = Depends(get_request_id),
) -> BatchDMLResponse:
    try:
        result = await snowflake_service.execute_batch_dml(body, request_id=request_id)
        return BatchDMLResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
