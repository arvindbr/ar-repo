# Snowflake Cheatsheet

A condensed reference for things you'll reach for constantly.

## Session & metadata

| Want | SQL |
|---|---|
| Who am I? | `SELECT CURRENT_USER(), CURRENT_ROLE();` |
| Where am I? | `SELECT CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_SCHEMA();` |
| Switch role | `USE ROLE ANALYST;` |
| Switch warehouse | `USE WAREHOUSE COMPUTE_WH;` |
| Switch context | `USE DATABASE ANALYTICS_PROD; USE SCHEMA DBT_MARTS;` |

## Quick exploration

| Want | SQL |
|---|---|
| List databases | `SHOW DATABASES;` |
| List schemas | `SHOW SCHEMAS IN DATABASE <db>;` |
| List tables | `SHOW TABLES IN SCHEMA <db>.<schema>;` |
| Describe table | `DESCRIBE TABLE <db>.<schema>.<table>;` |
| Sample rows | `SELECT * FROM <table> LIMIT 5;` |
| Random sample | `SELECT * FROM <table> SAMPLE (1);` (1%) |
| Row count + size | Query `INFORMATION_SCHEMA.TABLES` |

## Date & time

| Want | SQL |
|---|---|
| Today | `CURRENT_DATE` |
| Now | `CURRENT_TIMESTAMP()` |
| Truncate to month | `DATE_TRUNC('month', dt)` |
| Add 7 days | `DATEADD('day', 7, dt)` |
| Difference in days | `DATEDIFF('day', start, end)` |
| Format | `TO_CHAR(dt, 'YYYY-MM-DD')` |
| Parse string | `TO_TIMESTAMP_NTZ('2026-04-27 09:00:00')` |

## Aggregations

| Want | SQL |
|---|---|
| Distinct count (exact) | `COUNT(DISTINCT user_id)` |
| Distinct count (fast) | `APPROX_COUNT_DISTINCT(user_id)` |
| Conditional count | `COUNT_IF(status = 'paid')` |
| Median | `MEDIAN(amount)` or `PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY amount)` |
| String agg | `LISTAGG(name, ', ') WITHIN GROUP (ORDER BY name)` |
| Array agg | `ARRAY_AGG(DISTINCT tag)` |

## Window functions

```sql
ROW_NUMBER()  OVER (PARTITION BY user_id ORDER BY event_at DESC)
RANK()        OVER (PARTITION BY user_id ORDER BY revenue DESC)
LAG(value, 1) OVER (PARTITION BY user_id ORDER BY event_at)
LEAD(value)   OVER (PARTITION BY user_id ORDER BY event_at)
SUM(amount)   OVER (PARTITION BY user_id ORDER BY event_at
                   ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
```

`QUALIFY` filters on window functions (Snowflake-specific):

```sql
SELECT * FROM events
QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY ts DESC) = 1;
```

## Semi-structured (JSON / VARIANT)

| Want | SQL |
|---|---|
| Field by name | `payload:user_id` |
| Field with cast | `payload:amount::NUMBER` |
| Nested field | `payload:user.email::STRING` |
| Array element | `payload:items[0]:sku::STRING` |
| Explode array | `LATERAL FLATTEN(input => payload:items)` |
| Build JSON | `OBJECT_CONSTRUCT('a', 1, 'b', 2)` |
| Parse JSON string | `PARSE_JSON('{"a": 1}')` |

## String functions

| Want | SQL |
|---|---|
| Lowercase / uppercase | `LOWER(s)`, `UPPER(s)` |
| Trim | `TRIM(s)`, `LTRIM(s)`, `RTRIM(s)` |
| Replace | `REPLACE(s, 'old', 'new')` |
| Regex match | `REGEXP_LIKE(s, '^[A-Z]+$')` |
| Regex extract | `REGEXP_SUBSTR(s, 'pattern')` |
| Split | `SPLIT_PART(s, ',', 1)` |
| Concat | `s1 \|\| s2` or `CONCAT(s1, s2)` |

## Type casting

```sql
amount::NUMBER(18, 2)
event_at::DATE
'42'::INTEGER
TRY_CAST('abc' AS INTEGER)  -- returns NULL on failure instead of erroring
```

## Time travel

```sql
-- 1 hour ago
SELECT * FROM t AT(OFFSET => -3600);

-- specific moment
SELECT * FROM t AT(TIMESTAMP => '2026-04-26 12:00:00'::TIMESTAMP_NTZ);

-- before a destructive query
SELECT * FROM t BEFORE(STATEMENT => '<query_id>');
```

Default retention is 1 day on standard accounts, up to 90 on enterprise.

## Performance tips

- Filter on the cluster key (often a date column) to enable partition pruning.
- Use `RESULT_SCAN(LAST_QUERY_ID())` to reuse the last query's output.
- `EXPLAIN <query>` to see the plan without running it.
- `QUERY_HISTORY()` shows recent queries with cost data.
- Suspend the warehouse when idle: `ALTER WAREHOUSE compute_wh SUSPEND;` (auto-suspend handles this normally).
