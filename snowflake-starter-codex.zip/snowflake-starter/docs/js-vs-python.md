# JS vs Python tooling — when to use which

This project ships **two parallel implementations** of the launcher / resolver / connection-test:

| Concern | JavaScript | Python |
|---|---|---|
| Resolver | `scripts/resolve-env.js` | `scripts/resolve_env.py` |
| MCP launcher | `scripts/launch-mcp.js` | `scripts/launch_mcp.py` |
| Connection test | `scripts/test-connection.js` | `scripts/test_connection.py` |
| Dependencies | `package.json` (`js-yaml`, `dotenv`, `snowflake-sdk`) | `requirements.txt` (`PyYAML`, `python-dotenv`, `snowflake-connector-python`) |
| Snowflake client | `snowflake-sdk` (Node) | `snowflake-connector-python` |

Both read the same `config/environments.yml` and `.env`, support the same `externalbrowser` SSO and password modes, and produce equivalent output. **Pick one and remove the other** — running both adds maintenance burden for no gain.

## Which to pick

**Default to JS** for this project because:

- The MCP server we launch (`@isaacwasserman/mcp-snowflake-server`) is an npm package. The JS launcher `spawn`s it directly; the Python launcher has to shell out to `npx` anyway.
- The Node toolchain is already required for the MCP server. Going JS-only means one runtime, one lockfile, one "what version is installed" support burden.
- Cold start is slightly faster (~50 ms vs ~150–250 ms for Python). Not huge, but Codex spawns the launcher fresh every session.

**Switch to Python** if any of these apply:

1. **You're swapping to a Python-based MCP server** (e.g. Snowflake Labs publishes one as a `uv` / `pip` package). Same-runtime in-process calls beat cross-runtime `spawn`.
2. **You want richer auth handling** — the Python connector is more mature for key-pair rotation, OAuth refresh, and some token-cache edge cases.
3. **Your team is Python-shop** (dbt, pandas, notebooks). Maintainability beats marginal performance; the Python file will get more eyes and care.
4. **You're integrating with a dbt project** where `profiles.yml` and Python tooling already live alongside the warehouse.

## How to remove the unused side

### To go JS-only (recommended)
```bash
rm scripts/resolve_env.py scripts/launch_mcp.py scripts/test_connection.py requirements.txt
```
No further changes — `.codex/config.toml` already points at `node scripts/launch-mcp.js`.

### To go Python-only
```bash
rm scripts/resolve-env.js scripts/launch-mcp.js scripts/test-connection.js
```
Then edit `.codex/config.toml`:
```toml
[mcp_servers.snowflake]
command = "python"             # or "python3" / "uv run python"
args = ["scripts/launch_mcp.py"]
```
Update `package.json` scripts to call the Python versions, or just use `python scripts/test_connection.py uat` directly.

## Side-by-side smoke test

If you want to confirm both produce the same resolution before deciding:

```bash
# Set up both
npm install
pip install -r requirements.txt   # or: uv pip install -r requirements.txt

# Resolve dev env with each
node scripts/resolve-env.js dev
python scripts/resolve_env.py dev
```

The two should agree on every field except cosmetic table formatting.
