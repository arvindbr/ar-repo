# Project Agent Instructions

This project connects to a Snowflake data warehouse via an MCP server. Codex reads this file automatically when started in this directory and applies it as project-level instructions.

## Connection

The MCP Snowflake server is configured in `.codex/config.toml` and launched via `scripts/launch-mcp.js`, which reads `.env` for the env selector and `config/environments.yml` for per-environment settings. Use the MCP tools to query Snowflake — you do not need to ask the user for credentials.

## Authentication (SSO via externalbrowser)

This project authenticates to Snowflake using browser-based SSO (`authenticator: externalbrowser`).

- **First query of a session triggers a browser pop-up.** The Snowflake driver opens the user's default browser to complete SSO with their IdP. The MCP tool call may take 30–60 seconds the first time. Tell the user to watch for the browser window if a query seems to hang on first connect.
- **Tokens are cached locally** (`clientStoreTemporaryCredential: true`), so subsequent connections within the cache window do not re-prompt. If a query suddenly opens a browser mid-session, the cached token has expired or been invalidated — that's normal, not an error to debug.
- **Never ask the user for a password.** Do not suggest setting `SNOWFLAKE_PASSWORD`. If an SSO error occurs, suggest the user re-run `npm run test-connection:dev` to refresh the cached token, or check that their account has SSO enabled.
- **If `connectAsync` fails with "browser timeout"** the user likely missed or closed the browser tab. Suggest they retry — do not fall back to password auth.

## Environments (dev / uat)

This project supports multiple Snowflake environments via `config/environments.yml`. The active environment is chosen by the `SNOWFLAKE_ENV` variable (set in `.env` or the user's shell). Currently configured: **dev** and **uat**.

- **Always confirm which environment you are connected to** at the start of a session if it matters for the task. Run `read_query` with `SELECT CURRENT_DATABASE(), CURRENT_WAREHOUSE(), CURRENT_ROLE()` and report the result before doing anything else when the user asks for analysis or writes.
- **Treat UAT as production-like.** Do not run write queries against UAT unless the user explicitly says "in UAT" in the current message. Even then, prompt for confirmation before each `write_query`.
- **Dev is safe to experiment in.** Sample tables, run exploratory aggregations, create scratch tables if useful — but still announce what you're doing.
- If the user asks to "switch environments", they need to restart Codex with a different `SNOWFLAKE_ENV` (e.g. `SNOWFLAKE_ENV=uat codex` or `npm run codex:uat`). You cannot switch envs mid-session because the MCP server was launched with the env baked in. Tell the user this if they ask.
- If a query fails with a "database does not exist" or "insufficient privileges" error, check whether you are in the env you think you are — the user may have intended the other environment.

## Default Behavior

- **Read-only by default.** Use `read_query` for SELECTs. Do NOT call `write_query` unless the user has explicitly asked for a write operation in the current message.
- **Explore before answering.** If the user asks about data and you do not yet know the relevant tables, use `list_databases`, `list_schemas`, `list_tables`, and `describe_table` first. Don't guess column names.
- **Show your SQL.** Whenever you query the warehouse, include the SQL you ran in the response so the user can verify and reuse it.
- **Sample first on big tables.** Before running aggregations on unknown tables, run `SELECT * FROM <table> LIMIT 5` to see the shape of the data.
- **Use fully qualified names.** Prefer `DATABASE.SCHEMA.TABLE` over relying on session context.

## Performance Guardrails

- Add `LIMIT` clauses to exploratory queries (default to `LIMIT 100`).
- Avoid `SELECT *` on tables wider than ~20 columns; pick specific columns.
- For time-series questions, prefer recent windows (`WHERE event_date >= CURRENT_DATE - 30`) unless the user asks for the full history.
- Warn the user before running queries against tables larger than 1B rows or that scan unbounded date ranges.

## SQL Style

- Uppercase keywords: `SELECT`, `FROM`, `WHERE`, `JOIN`, `GROUP BY`.
- One column per line in `SELECT` lists when there are more than three columns.
- Use CTEs (`WITH ... AS`) for multi-step logic instead of nested subqueries.
- Always alias tables in joins (`FROM orders o JOIN customers c ON o.customer_id = c.id`).

## Snowflake-Specific Patterns to Reach For

- **`QUALIFY`** for filtering on window functions without a subquery (latest row per key, top-N per group).
- **`LATERAL FLATTEN`** for exploding `VARIANT`/`OBJECT`/`ARRAY` columns.
- **`APPROX_COUNT_DISTINCT()`** for cheap distinct counts on big tables.
- **`SAMPLE (n)`** for percentage sampling during exploration.
- **`DATE_TRUNC` + a generated date spine** for time-series with gaps filled.
- **Time travel** (`AT(OFFSET => -3600)`) when recovering or comparing historical state.

See `docs/snowflake-cheatsheet.md` and `sql/` for templates.

## Project-Specific Context

<!-- Database/warehouse/role per environment lives in config/environments.yml.
     This section is for context that does NOT vary by environment, like
     naming conventions and join keys. -->

- **Environments configured:** `dev` (ANALYTICS_DEV.DBT_DEV) and `uat` (ANALYTICS_UAT.DBT_MARTS) — see `config/environments.yml` for the full list and current details.
- **Naming conventions:** _e.g. fact tables prefixed `FCT_`, dimensions `DIM_`, staging `STG_`_
- **Date columns:** _e.g. always use `EVENT_DATE` (DATE) for filtering, `EVENT_AT` (TIMESTAMP_NTZ) for ordering_
- **Common joins:** _e.g. `FCT_ORDERS.CUSTOMER_KEY` → `DIM_CUSTOMERS.CUSTOMER_KEY`_
- **Things to avoid:** _e.g. don't query `RAW.*` directly, always go through the env's curated marts schema_

## Analysis Workflow

When the user asks an analytical question:

1. **Restate the question briefly** to confirm understanding. Flag ambiguity ("revenue: gross or net?").
2. **Find the right tables.** Prefer `ANALYTICS_PROD.DBT_MARTS.*` over `RAW.*`.
3. **Validate the data** with cheap sanity checks (freshness, row counts, null patterns) before reporting numbers.
4. **Compute the answer** with a CTE chain. Aim for a result small enough to read.
5. **Present findings** in plain prose first (the headline number, then context), then the table, then the SQL, then caveats.
6. **Save reusable work** to `sql/analysis/<descriptive-name>.sql` if the analysis is likely to repeat.

## Anti-Patterns

- Answering from a table name without querying it. Schemas drift.
- Reporting a number without a freshness check.
- Presenting a wall of rows and calling it analysis.
- `SELECT *` in a final query — pick the columns you actually want.
- Casting integer division without casting first (`a / b` truncates if both are ints).

## Sandbox & Approval

This project uses Codex's `on-request` approval mode for shell commands. Codex will prompt before running anything outside the workspace. MCP tool calls don't require approval per-call but inherit the safety constraints above (read-only unless `SNOWFLAKE_ALLOW_WRITES=true`).
