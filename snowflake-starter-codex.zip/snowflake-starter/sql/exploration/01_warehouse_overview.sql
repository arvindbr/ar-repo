-- exploration/01_warehouse_overview.sql
-- A first look at what's in the warehouse. Run top to bottom in order.

-- 1. What's my session?
SELECT
  CURRENT_USER()       AS user,
  CURRENT_ROLE()       AS role,
  CURRENT_WAREHOUSE()  AS warehouse,
  CURRENT_DATABASE()   AS database,
  CURRENT_SCHEMA()     AS schema;

-- 2. What databases can I see?
SHOW DATABASES;

-- 3. What schemas are in the main analytics database?
--    (replace ANALYTICS_PROD with your db name)
SHOW SCHEMAS IN DATABASE ANALYTICS_PROD;

-- 4. List tables and their row counts in a schema
SELECT
  table_schema,
  table_name,
  row_count,
  bytes / POWER(1024, 3) AS size_gb,
  last_altered
FROM ANALYTICS_PROD.INFORMATION_SCHEMA.TABLES
WHERE table_schema = 'DBT_MARTS'
ORDER BY row_count DESC NULLS LAST;

-- 5. Find tables with a column matching a pattern
SELECT
  table_schema,
  table_name,
  column_name,
  data_type
FROM ANALYTICS_PROD.INFORMATION_SCHEMA.COLUMNS
WHERE column_name ILIKE '%customer%'
ORDER BY table_schema, table_name, ordinal_position;
