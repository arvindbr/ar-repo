-- analysis/daily_revenue_trend.sql
-- Daily revenue for the last 30 days, with a 7-day trailing average.
-- Parameters (edit the params CTE):
--   days_back       number of days to look back (default 30)
--   status_filter   order status filter (default 'paid')

WITH params AS (
  SELECT
    30        AS days_back,
    'paid'    AS status_filter
),
daily AS (
  SELECT
    order_date,
    SUM(net_total) AS revenue,
    COUNT(*)       AS order_count
  FROM ANALYTICS_PROD.DBT_MARTS.FCT_ORDERS, params
  WHERE order_date >= CURRENT_DATE - days_back
    AND status = status_filter
  GROUP BY order_date
)
SELECT
  order_date,
  revenue,
  order_count,
  AVG(revenue) OVER (
    ORDER BY order_date
    ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
  ) AS revenue_7d_avg
FROM daily
ORDER BY order_date;
