-- ddl/example_table.sql
-- Example DDL showing common Snowflake table options.
-- DO NOT run this against production — it's a reference.

CREATE TABLE IF NOT EXISTS ANALYTICS_PROD.DBT_MARTS.EXAMPLE_FCT_ORDERS (
  order_id        STRING        NOT NULL,
  customer_id     STRING        NOT NULL,
  order_date      DATE          NOT NULL,
  ordered_at      TIMESTAMP_NTZ NOT NULL,
  status          STRING        NOT NULL,
  net_total       NUMBER(18, 2) NOT NULL DEFAULT 0,
  currency        STRING(3)     NOT NULL DEFAULT 'USD',
  metadata        VARIANT,
  loaded_at       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),

  CONSTRAINT pk_example_fct_orders PRIMARY KEY (order_id)
)
CLUSTER BY (order_date)
COMMENT = 'Example fact table — orders, one row per order. Clustered on order_date for efficient time-range scans.';
