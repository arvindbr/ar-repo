#!/usr/bin/env python3
"""
scripts/resolve_env.py

Python equivalent of scripts/resolve-env.js. Reads config/environments.yml,
picks the environment named by SNOWFLAKE_ENV (or default_environment),
expands ${VAR} references against environment variables (with .env loaded
via python-dotenv), and returns a dict of resolved Snowflake settings.

Used by:
  - scripts/test_connection.py    (programmatic import)
  - scripts/launch_mcp.py         (sets env vars, then execs server)
  - other tooling that needs the same resolution logic

Run directly to print the resolved env (passwords masked):
    python scripts/resolve_env.py [env]
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "environments.yml"

# Authenticators that don't need a password in .env.
PASSWORDLESS_AUTHENTICATORS = {"externalbrowser", "snowflake_jwt", "oauth"}

_VAR_RE = re.compile(r"\$\{([A-Z0-9_]+)\}", re.IGNORECASE)


def is_passwordless(authenticator: str | None) -> bool:
    if not authenticator:
        return False
    a = str(authenticator).lower()
    if a in PASSWORDLESS_AUTHENTICATORS:
        return True
    # Native Okta SSO uses the IdP URL as the authenticator value.
    if a.startswith("https://"):
        return True
    return False


def _expand(value: Any, source: str, *, optional: bool = False) -> Any:
    """Replace ${VAR} with os.environ[VAR]. Throws when missing unless optional."""
    if not isinstance(value, str):
        return value

    missing = False

    def replace(match: re.Match[str]) -> str:
        nonlocal missing
        name = match.group(1)
        val = os.environ.get(name)
        if val is None or val == "":
            if optional:
                missing = True
                return ""
            raise RuntimeError(
                f"{source}: referenced env var ${{{name}}} is not set. "
                "Add it to .env or export it in your shell."
            )
        return val

    result = _VAR_RE.sub(replace, value)
    return None if missing else result


def resolve_environment(env_name: str | None = None) -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        raise RuntimeError(f"Config file not found: {CONFIG_PATH}")

    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    selected = env_name or os.environ.get("SNOWFLAKE_ENV") or config.get("default_environment")
    if not selected:
        raise RuntimeError(
            "No environment selected and no default_environment in environments.yml"
        )

    envs = config.get("environments") or {}
    env_block = envs.get(selected)
    if env_block is None:
        available = ", ".join(envs.keys()) or "(none)"
        raise RuntimeError(f'Unknown environment "{selected}". Available: {available}')

    # Merge defaults <- env-specific. Env values win.
    merged: dict[str, Any] = {**(config.get("defaults") or {}), **env_block}

    # Resolve authenticator first to know whether password is required.
    authenticator = (
        _expand(merged.get("authenticator"), f"environments.{selected}.authenticator")
        or "snowflake"
    )
    passwordless = is_passwordless(authenticator)

    out: dict[str, Any] = {}
    for key, value in merged.items():
        is_password = key == "password"
        out[key] = _expand(
            value,
            f"environments.{selected}.{key}",
            optional=(is_password and passwordless),
        )

    # Coerce booleans to lowercase strings for env-var consumers.
    out["allow_writes"] = "true" if str(out.get("allow_writes")).lower() == "true" else "false"
    out["client_store_temporary_credential"] = (
        "true"
        if str(out.get("client_store_temporary_credential")).lower() == "true"
        else "false"
    )
    out["authenticator"] = authenticator

    return {"name": selected, "passwordless": passwordless, **out}


def to_snowflake_env(resolved: dict[str, Any]) -> dict[str, str]:
    """Convert resolved config to SNOWFLAKE_* env-var shape."""
    env = {
        "SNOWFLAKE_ACCOUNT": resolved.get("account") or "",
        "SNOWFLAKE_USER": resolved.get("user") or "",
        "SNOWFLAKE_AUTHENTICATOR": resolved.get("authenticator") or "",
        "SNOWFLAKE_WAREHOUSE": resolved.get("warehouse") or "",
        "SNOWFLAKE_DATABASE": resolved.get("database") or "",
        "SNOWFLAKE_SCHEMA": resolved.get("schema") or "",
        "SNOWFLAKE_ROLE": resolved.get("role") or "",
        "SNOWFLAKE_ALLOW_WRITES": resolved.get("allow_writes") or "false",
        "SNOWFLAKE_CLIENT_STORE_TEMPORARY_CREDENTIAL": (
            resolved.get("client_store_temporary_credential") or "true"
        ),
        "SNOWFLAKE_ENV": resolved.get("name") or "",
    }
    if resolved.get("password"):
        env["SNOWFLAKE_PASSWORD"] = resolved["password"]
    return env


def _print_resolved(resolved: dict[str, Any]) -> None:
    masked = dict(resolved)
    masked["password"] = "***" if resolved.get("password") else "(not used — passwordless auth)"
    width = max(len(k) for k in masked)
    print("Resolved environment:")
    for k, v in masked.items():
        print(f"  {k.ljust(width)}  {v}")


def main() -> None:
    load_dotenv()
    env_arg = sys.argv[1] if len(sys.argv) > 1 else None
    try:
        resolved = resolve_environment(env_arg)
    except RuntimeError as e:
        print(f"❌ {e}", file=sys.stderr)
        sys.exit(1)
    _print_resolved(resolved)


if __name__ == "__main__":
    main()
