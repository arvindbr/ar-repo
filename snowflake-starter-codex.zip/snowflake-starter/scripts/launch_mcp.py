#!/usr/bin/env python3
"""
scripts/launch_mcp.py

Python equivalent of scripts/launch-mcp.js. Loads .env, resolves the active
environment from config/environments.yml, sets SNOWFLAKE_* vars, then execs
the upstream Snowflake MCP server.

Note: the upstream MCP server is a Node package, so this script still uses
`npx` to launch it. If you swap to a Python-based Snowflake MCP server (e.g.
mcp_server_snowflake from PyPI), change the SERVER_CMD list below.

Codex spawns this script via .codex/config.toml (when configured to do so).
Logs go to stderr because stdout is the MCP transport.
"""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys

from dotenv import load_dotenv

from resolve_env import resolve_environment, to_snowflake_env

# Command to launch the underlying MCP server. Swap this if you change servers.
SERVER_CMD: list[str] = ["npx", "-y", "@isaacwasserman/mcp-snowflake-server"]


def main() -> int:
    load_dotenv()

    try:
        resolved = resolve_environment()
    except RuntimeError as e:
        # Errors must go to stderr — stdout is the MCP transport.
        print(f"[launch-mcp] {e}", file=sys.stderr)
        return 1

    snowflake_env = to_snowflake_env(resolved)

    print(
        f"[launch-mcp] env={resolved['name']} "
        f"db={snowflake_env['SNOWFLAKE_DATABASE']} "
        f"wh={snowflake_env['SNOWFLAKE_WAREHOUSE']} "
        f"role={snowflake_env['SNOWFLAKE_ROLE']} "
        f"writes={snowflake_env['SNOWFLAKE_ALLOW_WRITES']}",
        file=sys.stderr,
    )

    if not shutil.which(SERVER_CMD[0]):
        print(
            f"[launch-mcp] ❌ '{SERVER_CMD[0]}' not on PATH. "
            "Install Node.js or change SERVER_CMD in scripts/launch_mcp.py.",
            file=sys.stderr,
        )
        return 1

    child_env = {**os.environ, **snowflake_env}

    try:
        proc = subprocess.Popen(SERVER_CMD, env=child_env)
    except FileNotFoundError as e:
        print(f"[launch-mcp] ❌ failed to spawn server: {e}", file=sys.stderr)
        return 1

    # Forward termination signals so Codex can cleanly stop the server.
    def forward(signum: int, _frame: object) -> None:
        proc.send_signal(signum)

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        try:
            signal.signal(sig, forward)
        except (ValueError, OSError):
            # SIGHUP doesn't exist on Windows; ignore.
            pass

    return proc.wait()


if __name__ == "__main__":
    sys.exit(main())
