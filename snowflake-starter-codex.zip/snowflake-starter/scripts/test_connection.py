#!/usr/bin/env python3
"""
scripts/test_connection.py

Python equivalent of scripts/test-connection.js. Verifies connection to
Snowflake using the environment selected via SNOWFLAKE_ENV (or default in
environments.yml).

For externalbrowser SSO, the driver opens your default browser; complete
the SSO flow there and the script will continue. Subsequent runs reuse the
cached token (client_store_temporary_credential).

Usage:
    python scripts/test_connection.py            # uses SNOWFLAKE_ENV from .env
    python scripts/test_connection.py uat        # override env on the command line
"""

from __future__ import annotations

import sys

import snowflake.connector
from dotenv import load_dotenv

from resolve_env import resolve_environment


def main() -> int:
    load_dotenv()

    env_arg = sys.argv[1] if len(sys.argv) > 1 else None

    try:
        cfg = resolve_environment(env_arg)
    except RuntimeError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    print(f'Testing connection to "{cfg["name"]}" environment…')
    print(
        f'  database={cfg["database"]} warehouse={cfg["warehouse"]} '
        f'role={cfg["role"]} authenticator={cfg["authenticator"]}'
    )

    # snowflake-connector-python uses snake_case kwargs.
    opts: dict[str, object] = {
        "account": cfg["account"],
        "user": cfg["user"],
        "authenticator": cfg["authenticator"],
        "warehouse": cfg["warehouse"],
        "database": cfg["database"],
        "schema": cfg["schema"],
        "role": cfg["role"],
    }

    if cfg["passwordless"]:
        opts["client_store_temporary_credential"] = (
            cfg["client_store_temporary_credential"] == "true"
        )
        print("  → SSO via externalbrowser. A browser window will open if no cached token.")
    else:
        opts["password"] = cfg["password"]

    try:
        with snowflake.connector.connect(**opts) as conn:
            print("✅ Connected to Snowflake.")
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT CURRENT_USER(), CURRENT_ROLE(), "
                    "CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_VERSION()"
                )
                row = cur.fetchone()
                cols = [c[0] for c in cur.description]
            print("Session info:")
            width = max(len(c) for c in cols)
            for col, val in zip(cols, row):
                print(f"  {col.ljust(width)}  {val}")
    except Exception as e:  # noqa: BLE001
        print(f"❌ Connection failed: {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
