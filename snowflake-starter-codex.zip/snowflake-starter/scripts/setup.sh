#!/usr/bin/env bash
# First-time setup helper.
set -e

echo "Snowflake Starter (OpenAI Codex) — setup"
echo "========================================"

if [ ! -f .env ]; then
  cp .env.example .env
  echo "✓ Created .env from .env.example. Edit it with your credentials."
else
  echo "✓ .env already exists, leaving it alone."
fi

if [ ! -d node_modules ]; then
  echo "Installing npm dependencies…"
  npm install
else
  echo "✓ node_modules already present."
fi

if ! command -v codex >/dev/null 2>&1; then
  echo
  echo "ℹ Codex CLI not found on PATH. Install with:"
  echo "    npm install -g @openai/codex"
fi

echo
echo "Environment configuration:"
echo "  - Non-secret per-env config: config/environments.yml (dev, uat, …)"
echo "  - Secrets + env selector:    .env"
echo "  - Switch env by setting SNOWFLAKE_ENV (in .env or your shell)"
echo
echo "Next steps:"
echo "  1. Edit .env and fill in SNOWFLAKE_ACCOUNT / USER / PASSWORD."
echo "  2. Edit config/environments.yml with your real database/warehouse names."
echo "  3. Verify resolution:   npm run resolve-env:dev"
echo "  4. Verify connection:   npm run test-connection:dev"
echo "                          npm run test-connection:uat"
echo "  5. Authenticate Codex:  codex login"
echo "  6. Start Codex:         npm run codex:dev   (or codex:uat)"
echo "                          - Approve the project as 'trusted' on first run"
echo "                          - Verify MCP loaded: codex mcp list"
