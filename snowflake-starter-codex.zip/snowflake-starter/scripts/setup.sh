#!/usr/bin/env bash
# First-time setup helper.
set -e

echo "Snowflake Starter (OpenAI Codex) — setup"
echo "========================================"

if [ ! -f .env ]; then
  cp .env.example .env
  echo "✓ Created .env from .env.example. Edit it with your Snowflake credentials."
else
  echo "✓ .env already exists, leaving it alone."
fi

if [ ! -d node_modules ]; then
  echo "Installing npm dependencies…"
  npm install
else
  echo "✓ node_modules already present."
fi

if ! command -v codex >/dev/null 2>&1; then
  echo
  echo "ℹ Codex CLI not found on PATH. Install with:"
  echo "    npm install -g @openai/codex"
fi

echo
echo "Next steps:"
echo "  1. Edit .env and fill in your Snowflake account, user, and password."
echo "  2. Run: npm run test-connection"
echo "  3. Run: codex login   (ChatGPT or API key)"
echo "  4. Run: codex         (in this directory)"
echo "     - Approve the project as 'trusted' so .codex/config.toml is loaded"
echo "     - Verify the MCP server with: codex mcp list"
echo "  5. Try a slash command: /explore-schema ANALYTICS_PROD.DBT_MARTS"
