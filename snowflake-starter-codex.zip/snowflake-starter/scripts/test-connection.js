#!/usr/bin/env node
/**
 * Smoke test: verify the credentials in .env can connect to Snowflake using
 * the environment selected via SNOWFLAKE_ENV (or default in environments.yml).
 *
 * Usage:
 *   npm run test-connection            # uses SNOWFLAKE_ENV from .env
 *   node scripts/test-connection.js uat   # override env on the command line
 */
import 'dotenv/config';
import snowflake from 'snowflake-sdk';
import { resolveEnvironment } from './resolve-env.js';

const envArg = process.argv[2];

let cfg;
try {
  cfg = resolveEnvironment(envArg);
} catch (err) {
  console.error('❌', err.message);
  process.exit(1);
}

console.log(`Testing connection to "${cfg.name}" environment…`);
console.log(`  database=${cfg.database} warehouse=${cfg.warehouse} role=${cfg.role}`);

const connection = snowflake.createConnection({
  account: cfg.account,
  username: cfg.user,
  password: cfg.password,
  warehouse: cfg.warehouse,
  database: cfg.database,
  schema: cfg.schema,
  role: cfg.role,
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Connection failed:', err.message);
    process.exit(1);
  }
  console.log('✅ Connected to Snowflake.');

  connection.execute({
    sqlText:
      'SELECT CURRENT_USER() AS user, CURRENT_ROLE() AS role, ' +
      'CURRENT_WAREHOUSE() AS warehouse, CURRENT_DATABASE() AS database, ' +
      'CURRENT_VERSION() AS version',
    complete: (err, _stmt, rows) => {
      if (err) {
        console.error('❌ Query failed:', err.message);
        process.exit(1);
      }
      console.log('Session info:');
      console.table(rows);
      connection.destroy(() => process.exit(0));
    },
  });
});
