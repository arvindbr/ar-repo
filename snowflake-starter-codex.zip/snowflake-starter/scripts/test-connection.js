#!/usr/bin/env node
/**
 * Smoke test: verify connection to Snowflake using the environment selected
 * via SNOWFLAKE_ENV (or default in environments.yml).
 *
 * For externalbrowser SSO, the driver opens your default browser; complete
 * the SSO flow there and the script will continue. Subsequent runs reuse the
 * cached token (clientStoreTemporaryCredential).
 *
 * Usage:
 *   npm run test-connection            # uses SNOWFLAKE_ENV from .env
 *   node scripts/test-connection.js uat   # override env on the command line
 */
import 'dotenv/config';
import snowflake from 'snowflake-sdk';
import { resolveEnvironment } from './resolve-env.js';

const envArg = process.argv[2];

let cfg;
try {
  cfg = resolveEnvironment(envArg);
} catch (err) {
  console.error('❌', err.message);
  process.exit(1);
}

console.log(`Testing connection to "${cfg.name}" environment…`);
console.log(
  `  database=${cfg.database} warehouse=${cfg.warehouse} ` +
  `role=${cfg.role} authenticator=${cfg.authenticator}`
);

// Build connection options. Snowflake's driver expects camelCase keys.
const opts = {
  account: cfg.account,
  username: cfg.user,
  authenticator: cfg.authenticator,
  warehouse: cfg.warehouse,
  database: cfg.database,
  schema: cfg.schema,
  role: cfg.role,
};

if (cfg.passwordless) {
  // Cache the SSO token so the user isn't prompted on every reconnect.
  opts.clientStoreTemporaryCredential =
    cfg.client_store_temporary_credential === 'true';
  console.log('  → SSO via externalbrowser. A browser window will open if no cached token.');
} else {
  opts.password = cfg.password;
}

const connection = snowflake.createConnection(opts);

// Use connectAsync — required by the driver for externalbrowser SSO.
const connect = cfg.passwordless
  ? () =>
      new Promise((resolve, reject) =>
        connection.connectAsync((err) => (err ? reject(err) : resolve()))
      )
  : () =>
      new Promise((resolve, reject) =>
        connection.connect((err) => (err ? reject(err) : resolve()))
      );

try {
  await connect();
  console.log('✅ Connected to Snowflake.');
} catch (err) {
  console.error('❌ Connection failed:', err.message);
  process.exit(1);
}

connection.execute({
  sqlText:
    'SELECT CURRENT_USER() AS user, CURRENT_ROLE() AS role, ' +
    'CURRENT_WAREHOUSE() AS warehouse, CURRENT_DATABASE() AS database, ' +
    'CURRENT_VERSION() AS version',
  complete: (err, _stmt, rows) => {
    if (err) {
      console.error('❌ Query failed:', err.message);
      process.exit(1);
    }
    console.log('Session info:');
    console.table(rows);
    connection.destroy(() => process.exit(0));
  },
});
