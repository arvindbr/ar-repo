#!/usr/bin/env node
/**
 * Smoke test: verify the credentials in .env can connect to Snowflake.
 * Run: npm run test-connection
 */
import 'dotenv/config';
import snowflake from 'snowflake-sdk';

const required = ['SNOWFLAKE_ACCOUNT', 'SNOWFLAKE_USER', 'SNOWFLAKE_PASSWORD'];
const missing = required.filter((k) => !process.env[k]);
if (missing.length) {
  console.error(`❌ Missing env vars: ${missing.join(', ')}`);
  console.error('   Copy .env.example to .env and fill in your credentials.');
  process.exit(1);
}

const connection = snowflake.createConnection({
  account: process.env.SNOWFLAKE_ACCOUNT,
  username: process.env.SNOWFLAKE_USER,
  password: process.env.SNOWFLAKE_PASSWORD,
  warehouse: process.env.SNOWFLAKE_WAREHOUSE,
  database: process.env.SNOWFLAKE_DATABASE,
  schema: process.env.SNOWFLAKE_SCHEMA,
  role: process.env.SNOWFLAKE_ROLE,
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Connection failed:', err.message);
    process.exit(1);
  }
  console.log('✅ Connected to Snowflake.');

  connection.execute({
    sqlText: 'SELECT CURRENT_USER() AS user, CURRENT_ROLE() AS role, CURRENT_WAREHOUSE() AS warehouse, CURRENT_DATABASE() AS database, CURRENT_VERSION() AS version',
    complete: (err, _stmt, rows) => {
      if (err) {
        console.error('❌ Query failed:', err.message);
        process.exit(1);
      }
      console.log('Session info:');
      console.table(rows);
      connection.destroy(() => process.exit(0));
    },
  });
});
