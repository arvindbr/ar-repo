#!/usr/bin/env node
// scripts/launch-mcp.js
//
// Wrapper that:
//   1. Loads .env
//   2. Resolves the active environment from config/environments.yml
//   3. Exports SNOWFLAKE_* vars matching the selected environment
//   4. Execs the underlying Snowflake MCP server, passing through stdio
//
// Codex spawns this script via .codex/config.toml. Writing it as a launcher
// (instead of inlining the resolution in TOML) keeps the YAML as the single
// source of truth and makes the env switch one variable: SNOWFLAKE_ENV.

import 'dotenv/config';
import { spawn } from 'node:child_process';
import { resolveEnvironment, toSnowflakeEnv } from './resolve-env.js';

let resolved;
try {
  resolved = resolveEnvironment();
} catch (err) {
  // Errors must go to stderr — stdout is the MCP transport.
  console.error(`[launch-mcp] ${err.message}`);
  process.exit(1);
}

const snowflakeEnv = toSnowflakeEnv(resolved);

console.error(
  `[launch-mcp] env=${resolved.name} ` +
  `db=${snowflakeEnv.SNOWFLAKE_DATABASE} ` +
  `wh=${snowflakeEnv.SNOWFLAKE_WAREHOUSE} ` +
  `role=${snowflakeEnv.SNOWFLAKE_ROLE} ` +
  `writes=${snowflakeEnv.SNOWFLAKE_ALLOW_WRITES}`
);

const child = spawn(
  'npx',
  ['-y', '@isaacwasserman/mcp-snowflake-server'],
  {
    stdio: 'inherit',
    env: { ...process.env, ...snowflakeEnv },
  }
);

child.on('exit', (code, signal) => {
  if (signal) process.kill(process.pid, signal);
  else process.exit(code ?? 0);
});

// Forward termination signals so Codex can cleanly stop the server.
for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
  process.on(sig, () => child.kill(sig));
}
