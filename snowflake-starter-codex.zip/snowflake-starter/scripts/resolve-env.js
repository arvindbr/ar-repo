// scripts/resolve-env.js
//
// Reads config/environments.yml, picks the environment named by SNOWFLAKE_ENV
// (or default_environment), expands ${VAR} references against process.env
// (which dotenv has already populated from .env), and returns a flat object
// of resolved Snowflake settings.
//
// Used by:
//   - scripts/test-connection.js  (programmatic import)
//   - scripts/launch-mcp.js       (writes settings into env, then execs server)
//   - other tooling that needs the same resolution logic

import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
import yaml from 'js-yaml';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const CONFIG_PATH = path.resolve(__dirname, '..', 'config', 'environments.yml');

// Authenticators that don't need a password in .env.
const PASSWORDLESS_AUTHENTICATORS = new Set([
  'externalbrowser',
  'snowflake_jwt',
  'oauth',
]);

function isPasswordless(authenticator) {
  if (!authenticator) return false;
  const a = String(authenticator).toLowerCase();
  if (PASSWORDLESS_AUTHENTICATORS.has(a)) return true;
  // Native Okta SSO uses the IdP URL as the authenticator value.
  if (a.startsWith('https://')) return true;
  return false;
}

// Replace ${VAR} with process.env[VAR]. By default throws when a referenced
// var is unset; pass {optional: true} to leave it as undefined instead.
function expand(value, source, { optional = false } = {}) {
  if (typeof value !== 'string') return value;
  let missing = false;
  const result = value.replace(/\$\{([A-Z0-9_]+)\}/gi, (_match, name) => {
    if (process.env[name] === undefined || process.env[name] === '') {
      if (optional) {
        missing = true;
        return '';
      }
      throw new Error(
        `${source}: referenced env var \${${name}} is not set. ` +
        `Add it to .env or export it in your shell.`
      );
    }
    return process.env[name];
  });
  return missing ? undefined : result;
}

export function resolveEnvironment(envName) {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error(`Config file not found: ${CONFIG_PATH}`);
  }

  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  const config = yaml.load(raw);

  const selected = envName || process.env.SNOWFLAKE_ENV || config.default_environment;
  if (!selected) {
    throw new Error('No environment selected and no default_environment in environments.yml');
  }

  const envBlock = config.environments?.[selected];
  if (!envBlock) {
    const available = Object.keys(config.environments || {}).join(', ') || '(none)';
    throw new Error(`Unknown environment "${selected}". Available: ${available}`);
  }

  // Merge: defaults <- env-specific. Env values win.
  const merged = { ...(config.defaults || {}), ...envBlock };

  // Determine the authenticator first (after expanding it), so we know whether
  // password is required.
  const authenticator = expand(merged.authenticator, `environments.${selected}.authenticator`)
    || 'snowflake';
  const passwordless = isPasswordless(authenticator);

  // Expand all fields. Password is optional when using a passwordless auth.
  const out = {};
  for (const [k, v] of Object.entries(merged)) {
    const isPassword = k === 'password';
    out[k] = expand(v, `environments.${selected}.${k}`, {
      optional: isPassword && passwordless,
    });
  }

  // Coerce types for downstream consumers that read env vars (which are strings).
  out.allow_writes = String(out.allow_writes === true || out.allow_writes === 'true');
  out.client_store_temporary_credential = String(
    out.client_store_temporary_credential === true ||
    out.client_store_temporary_credential === 'true'
  );

  // Make sure authenticator is normalized.
  out.authenticator = authenticator;

  return { name: selected, passwordless, ...out };
}

// Convert resolved config to the SNOWFLAKE_* env-var shape the MCP server
// and connection script expect.
export function toSnowflakeEnv(resolved) {
  const env = {
    SNOWFLAKE_ACCOUNT: resolved.account,
    SNOWFLAKE_USER: resolved.user,
    SNOWFLAKE_AUTHENTICATOR: resolved.authenticator,
    SNOWFLAKE_WAREHOUSE: resolved.warehouse,
    SNOWFLAKE_DATABASE: resolved.database,
    SNOWFLAKE_SCHEMA: resolved.schema,
    SNOWFLAKE_ROLE: resolved.role,
    SNOWFLAKE_ALLOW_WRITES: resolved.allow_writes,
    SNOWFLAKE_CLIENT_STORE_TEMPORARY_CREDENTIAL: resolved.client_store_temporary_credential,
    SNOWFLAKE_ENV: resolved.name,
  };
  // Only set the password var if we actually have one.
  if (resolved.password) {
    env.SNOWFLAKE_PASSWORD = resolved.password;
  }
  return env;
}

// CLI: `node scripts/resolve-env.js [env]` prints resolved config (masked).
if (import.meta.url === `file://${process.argv[1]}`) {
  await import('dotenv/config');
  const envArg = process.argv[2];
  try {
    const r = resolveEnvironment(envArg);
    const masked = {
      ...r,
      password: r.password ? '***' : '(not used — passwordless auth)',
    };
    console.log('Resolved environment:');
    console.table(masked);
  } catch (err) {
    console.error('❌', err.message);
    process.exit(1);
  }
}
