// scripts/resolve-env.js
//
// Reads config/environments.yml, picks the environment named by SNOWFLAKE_ENV
// (or default_environment), expands ${VAR} references against process.env
// (which dotenv has already populated from .env), and returns a flat object
// of resolved Snowflake settings.
//
// Used by:
//   - scripts/test-connection.js  (programmatic import)
//   - scripts/launch-mcp.js       (writes settings into env, then execs server)
//   - other tooling that needs the same resolution logic

import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
import yaml from 'js-yaml';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const CONFIG_PATH = path.resolve(__dirname, '..', 'config', 'environments.yml');

// Replace ${VAR} with process.env[VAR]. Throws if a referenced var is unset.
function expand(value, source) {
  if (typeof value !== 'string') return value;
  return value.replace(/\$\{([A-Z0-9_]+)\}/gi, (_match, name) => {
    if (process.env[name] === undefined || process.env[name] === '') {
      throw new Error(
        `${source}: referenced env var \${${name}} is not set. ` +
        `Add it to .env or export it in your shell.`
      );
    }
    return process.env[name];
  });
}

function expandObject(obj, source) {
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    out[k] = expand(v, `${source}.${k}`);
  }
  return out;
}

export function resolveEnvironment(envName) {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error(`Config file not found: ${CONFIG_PATH}`);
  }

  const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
  const config = yaml.load(raw);

  const selected = envName || process.env.SNOWFLAKE_ENV || config.default_environment;
  if (!selected) {
    throw new Error('No environment selected and no default_environment in environments.yml');
  }

  const envBlock = config.environments?.[selected];
  if (!envBlock) {
    const available = Object.keys(config.environments || {}).join(', ') || '(none)';
    throw new Error(
      `Unknown environment "${selected}". Available: ${available}`
    );
  }

  // Merge: defaults <- env-specific. Env values win.
  const merged = { ...(config.defaults || {}), ...envBlock };

  // Expand ${VAR} placeholders.
  const resolved = expandObject(merged, `environments.${selected}`);

  // Coerce allow_writes to a strict boolean string for downstream consumers
  // that expect "true"/"false" as env vars.
  resolved.allow_writes = String(resolved.allow_writes === true || resolved.allow_writes === 'true');

  return { name: selected, ...resolved };
}

// Convert resolved config to the SNOWFLAKE_* env-var shape the MCP server
// and connection script expect.
export function toSnowflakeEnv(resolved) {
  return {
    SNOWFLAKE_ACCOUNT: resolved.account,
    SNOWFLAKE_USER: resolved.user,
    SNOWFLAKE_PASSWORD: resolved.password,
    SNOWFLAKE_WAREHOUSE: resolved.warehouse,
    SNOWFLAKE_DATABASE: resolved.database,
    SNOWFLAKE_SCHEMA: resolved.schema,
    SNOWFLAKE_ROLE: resolved.role,
    SNOWFLAKE_ALLOW_WRITES: resolved.allow_writes,
    SNOWFLAKE_ENV: resolved.name,
  };
}

// Allow CLI usage: `node scripts/resolve-env.js [env]` prints the resolved
// config (with password masked) so you can sanity-check.
if (import.meta.url === `file://${process.argv[1]}`) {
  await import('dotenv/config');
  const envArg = process.argv[2];
  try {
    const r = resolveEnvironment(envArg);
    const masked = { ...r, password: r.password ? '***' : '(unset)' };
    console.log('Resolved environment:');
    console.table(masked);
  } catch (err) {
    console.error('❌', err.message);
    process.exit(1);
  }
}
