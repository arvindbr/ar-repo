# Snowflake Starter Project (OpenAI Codex)

A starter project for working with Snowflake databases through **OpenAI Codex CLI** and the **Codex VS Code extension**, with pre-configured MCP server integration, project instructions, and reusable prompts.

## What's Included

- **MCP Snowflake server** configured in `.codex/config.toml` for database queries
- **`AGENTS.md`** — project instructions Codex reads automatically
- **Reusable prompts** in `.codex/prompts/` (available as slash commands)
- **SQL templates** in `sql/` for exploration, analysis, and DDL
- **Helper scripts** in `scripts/` for setup and connection testing

## Quick Start

1. **Install prerequisites:**
   - [Codex CLI](https://developers.openai.com/codex/cli): `npm install -g @openai/codex`
   - (Optional) [Codex VS Code extension](https://marketplace.visualstudio.com/items?itemName=openai.codex) — shares the same config
   - Node.js 18+ (for the MCP server and helper script)
   - An OpenAI API key, or a ChatGPT Plus/Pro/Business/Edu/Enterprise plan

2. **Authenticate Codex:**
   ```bash
   codex login
   ```

3. **Configure credentials and environments:**
   ```bash
   cp .env.example .env
   # Edit .env with your Snowflake account + credentials and pick SNOWFLAKE_ENV
   # Edit config/environments.yml with your real db / warehouse / role names
   ```

4. **Install local dependencies and verify config + connection:**
   ```bash
   npm install
   npm run resolve-env:dev       # show resolved env (passwords masked)
   npm run test-connection:dev   # actually connect
   npm run test-connection:uat   # try uat too
   ```

5. **Start Codex against the env you want:**
   ```bash
   npm run codex:dev    # or: npm run codex:uat
   ```

   Codex will read `AGENTS.md` automatically and load the MCP Snowflake server defined in `.codex/config.toml`.

## How Codex Finds This Configuration

Codex reads two files from this project:

- **`AGENTS.md`** — picked up automatically when Codex starts in (or under) this directory. This is the OpenAI/Codex convention for project-specific agent instructions, analogous to a project-level system prompt.
- **`.codex/config.toml`** — project-scoped Codex settings, including MCP servers. This requires the project to be **trusted** in Codex (Codex prompts you on first run; or run `codex` once and approve when asked).

Your global `~/.codex/config.toml` is layered underneath; project settings override globals.

## Project Structure

```
snowflake-starter/
├── .codex/
│   ├── config.toml           # Project-scoped Codex config + MCP launcher
│   └── prompts/              # Reusable slash-command prompts
│       ├── explore-schema.md
│       └── daily-revenue.md
├── .vscode/
│   └── settings.json         # VS Code workspace settings
├── config/
│   └── environments.yml      # Per-env Snowflake settings (dev / uat / …)
├── sql/
│   ├── exploration/          # Schema exploration queries
│   ├── analysis/             # Common analysis templates
│   └── ddl/                  # Table/view definitions
├── scripts/
│   ├── resolve-env.js        # Reads YAML, picks env, expands ${VAR}
│   ├── launch-mcp.js         # Wrapper Codex spawns to start the MCP server
│   ├── test-connection.js    # Connection smoke test (per-env)
│   └── setup.sh              # First-time setup helper
├── docs/
│   └── snowflake-cheatsheet.md
├── AGENTS.md                 # Instructions Codex reads automatically
├── .env.example              # Secrets + env selector (SNOWFLAKE_ENV)
├── .gitignore
└── package.json
```

## Environments (dev / uat)

Non-secret per-environment settings live in **`config/environments.yml`**. Each environment block defines its own `database`, `schema`, `warehouse`, `role`, and `allow_writes` flag. Secrets (account, user, password) live in **`.env`** and are referenced from the YAML with `${VAR}` interpolation.

The active environment is chosen by `SNOWFLAKE_ENV`:

```bash
# Default (reads SNOWFLAKE_ENV from .env, falls back to default_environment in YAML)
codex

# Switch on a single command
SNOWFLAKE_ENV=uat codex

# Or use the npm shortcuts
npm run codex:dev
npm run codex:uat
npm run test-connection:uat
```

Sanity-check what the resolver produces (passwords masked):

```bash
npm run resolve-env:dev
npm run resolve-env:uat
```

You cannot switch environments inside a running Codex session — the MCP server is launched once with the env baked in. Restart Codex with a different `SNOWFLAKE_ENV` to switch.

## Available MCP Tools

Once Codex starts, the Snowflake MCP server exposes tools like:

- `list_databases` — list accessible databases
- `list_schemas` — list schemas in a database
- `list_tables` — list tables in a schema
- `describe_table` — get column info for a table
- `read_query` — execute SELECT queries (read-only by default)
- `write_query` — execute INSERT/UPDATE/DELETE (gated by `SNOWFLAKE_ALLOW_WRITES`)

You can verify the server is loaded by running `codex mcp list` after starting a session in this folder.

## Safety

By default, the MCP server runs in **read-only mode**. To enable writes, set `SNOWFLAKE_ALLOW_WRITES=true` in your `.env` file. Codex's sandbox/approval modes add another layer — keep `approval_policy = "on-request"` in `.codex/config.toml` so Codex asks before destructive actions.

## Reusable Prompts

Files in `.codex/prompts/*.md` are available as slash commands inside Codex. For example, `explore-schema.md` becomes `/explore-schema`. Add your own as you build up recurring workflows.

## Customizing

- Edit `AGENTS.md` to give Codex project-specific context (your data model, naming conventions, business rules).
- Add new prompts under `.codex/prompts/` for repeated workflows.
- Drop reusable queries into `sql/` — Codex can read them with file references (`@sql/analysis/daily_revenue_trend.sql`).
