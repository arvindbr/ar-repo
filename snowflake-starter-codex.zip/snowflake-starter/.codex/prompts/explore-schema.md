# /explore-schema

Walk me through the schema of `$ARG` (a database, schema, or table — figure out which from context).

Steps:

1. If `$ARG` looks like a database name, list its schemas with `list_schemas` and show row counts where available.
2. If `$ARG` looks like a fully-qualified schema (`DATABASE.SCHEMA`), list the tables with `list_tables` along with row counts and last-updated timestamps. Highlight the largest and most-recently-updated tables.
3. If `$ARG` looks like a fully-qualified table (`DATABASE.SCHEMA.TABLE`):
   - Run `describe_table` to get the columns.
   - Run `SELECT * FROM <table> LIMIT 5` to see actual values.
   - Report row count, freshness (max of any timestamp column), and obvious patterns (looks like a fact table? dimension? event log?).
4. After gathering info, give a 3–5 bullet summary suitable for someone seeing this object for the first time. Don't dump raw output unless I ask.
