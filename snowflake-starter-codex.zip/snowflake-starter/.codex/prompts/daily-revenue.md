# /daily-revenue

Run a daily revenue check.

1. Read `sql/analysis/daily_revenue_trend.sql` to see the canonical query for this project.
2. Execute it against the warehouse.
3. Report:
   - **Headline:** today's revenue and the 7-day trailing average.
   - **Trend:** is today above/below the trailing average? By how much (% and absolute)?
   - **Anomalies:** any day in the last 30 that's >2 standard deviations from the trailing mean.
4. Include the SQL you ran and the small results table.
5. If the warehouse looks stale (max order_date is more than 1 day ago), flag that prominently before reporting numbers.
