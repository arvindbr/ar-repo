# Miro export — architecture diagram

You asked for an `.rtf` file you could import into Miro and edit. **RTF isn't
a format Miro reads as a diagram** — it only consumes RTF as the text content
of a sticky or shape, not as a board layout. So I built the four formats Miro
*does* actually accept, ordered by how editable the result is:

## 1. `architecture.mmd` — Mermaid (most editable)

This is the closest to "import and edit as a real diagram in Miro." Miro has
built-in Mermaid support via its diagramming feature.

**How to import:**
1. Open your board in Miro
2. Click the **+** in the toolbar → **Diagrams** → **Mermaid**
   *(or use the AI/diagramming icon, depending on plan)*
3. Paste the contents of `architecture.mmd`
4. Insert — Miro generates real shapes and connectors you can rewire

What you get: every component as a Miro shape, every arrow as a Miro connector.
Rearrange, restyle, regroup as you would any native board content.

## 2. `architecture_components.csv` — bulk sticky import

If you'd rather lay out the diagram by hand (some teams prefer this — the
layout *is* part of the thinking), import the CSV as stickies.

**How to import:**
1. In a Miro board, **+** → **Upload** → **Bulk sticky note import** (or
   "Import CSV" depending on plan)
2. Select `architecture_components.csv`
3. Map the columns:
   - **Title** → sticky title
   - **Description** → sticky body
   - **Category** → use as color/tag (each value gets a distinct color)
4. Import — 24 stickies appear, grouped or color-coded by category

What you get: every component as a sticky, no connectors, no layout.
You arrange them.

## 3. `architecture.svg` — vector drag-and-drop

If you just want the picture on the board to point at while talking, drag
the SVG into Miro. It renders as a single image. You can resize it, place
it anywhere, annotate around it, but the individual shapes aren't editable
from Miro — you'd need to ungroup in an SVG editor first.

## 4. `architecture.png` — raster fallback

Same as the SVG but as a PNG at 2400px wide. Use this if your Miro
plan doesn't accept SVG drops, or if you want to embed the diagram in a
Confluence/Notion/email and link back to the editable Miro board.

---

## Which one should you actually use?

- **You want to keep editing the diagram inside Miro** → use the Mermaid
  file. Highest fidelity to "import and edit."
- **Your team likes laying things out themselves** → use the CSV.
- **You just need the diagram on the board to reference** → use the SVG
  or PNG.

## A note on what's in the diagram

The Mermaid and SVG/PNG versions show the **architecture as drawn on Plate I**
of the interactive artifact:

- Consumer subscription with the four React clients (vNet-peered)
- Workload subscription with the vnet-wealth-ai-prod vNet (10.40.0.0/16) and
  its subnets: snet-edge, snet-appservice, snet-private-endpoints, snet-aca,
  snet-aks
- Foundry account & project containing Agent Service, Model deployment,
  Connections, Foundry Models catalog, and the MCP Gateway
- Domain MCP fleet split across Container Apps (Performance, AUM, Client Info,
  Transaction) and Kubernetes (Risk & Attribution, Snowflake MCP)
- Snowflake tier via PrivateLink with data products, virtual warehouses,
  row-access policies
- Monitoring (Application Insights, Azure Monitor)

The CSV is flatter (no subnet hierarchy) because Miro's bulk sticky import
doesn't take grouping metadata.
