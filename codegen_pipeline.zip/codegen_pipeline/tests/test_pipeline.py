"""Smoke test — runs the full pipeline end-to-end.

Verifies:
  - Pipeline completes without raising
  - Repair loop is exercised (attempt 1 must fail, attempt 2 must pass)
  - All outputs are produced
  - Governance and QA results land in the run state
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from codegen_pipeline import plan, read
from codegen_pipeline.codegen import run_story
from codegen_pipeline.llm import MockLLM
from codegen_pipeline.models import RunState
from codegen_pipeline.output import generate_pr_bundle, render_html, render_json
from codegen_pipeline.qa import check_spec_conformance, run_regression, validate_behavior


REQ_PATH = Path(__file__).parent.parent / "examples" / "twr_requirement.md"


def test_pipeline_end_to_end(tmp_path):
    state = RunState(run_id="test_run", started_at=datetime.now(timezone.utc))
    llm = MockLLM()

    # 01 read
    state.requirement = read.read(str(REQ_PATH))
    assert state.requirement.title == "Time-Weighted Return Calculator"
    assert len(state.requirement.acceptance_criteria) >= 4
    assert "twr.py" in state.requirement.extracted_entities.get("target_modules", [])

    # 02 plan
    state.plan = plan.plan(state.requirement)
    assert len(state.plan.stories) == 1
    assert state.plan.stories[0].target_module == "twr.py"

    # 03 codegen loop — this is the test that matters
    result = run_story(llm, state.plan.stories[0], log=lambda *a, **k: None)
    state.story_results.append(result)
    assert result.success, f"story should succeed; final diagnosis: {result.final_diagnosis}"
    assert result.attempts == 2, f"expected exactly 2 attempts (buggy then fixed); got {result.attempts}"
    assert result.test_history[0].passed is False
    assert result.test_history[1].passed is True
    assert result.governance.passed is True

    # 04 QA
    files = result.files
    state.qa_results.append(check_spec_conformance(llm, state.requirement, files))
    state.qa_results.append(validate_behavior(llm, files))
    state.qa_results.append(run_regression(files))
    assert all(q.passed for q in state.qa_results)

    # 05 outputs
    state.completed_at = datetime.now(timezone.utc)
    html = render_html(state)
    assert "PASSED" in html
    assert "Time-Weighted Return" in html

    js = json.loads(render_json(state))
    assert js["schema_version"] == "1.0.0"
    assert js["story_results"][0]["success"] is True
    assert len(js["qa_results"]) == 3

    pr = generate_pr_bundle(state)
    assert pr.branch.startswith("codegen/time-weighted-return")
    assert len(pr.commits) == 1
    assert pr.draft is False


def test_governance_blocks_secret_leak():
    """Governance should fail on hardcoded secrets — verifies the gate works."""
    from codegen_pipeline.governance import check
    from codegen_pipeline.models import GeneratedFile

    files = [GeneratedFile(
        path="bad.py",
        content='API_KEY = "sk-aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789"\n',
    )]
    result = check(files)
    assert not result.passed
    assert any(f.rule == "secret.hardcoded" for f in result.findings)


def test_repair_bails_on_low_confidence():
    """Repair should escalate rather than retry on low-confidence diagnoses."""
    from codegen_pipeline.codegen.repair import decide
    from codegen_pipeline.models import Diagnosis

    diag = Diagnosis(confidence=0.3, category="spec_gap",
                     root_cause="unclear", suggested_patch="?")
    decision = decide(diag, attempt=1, max_attempts=5)
    assert decision.should_retry is False
    assert "confidence" in decision.reason.lower()


def test_repair_detects_oscillation():
    """Same root cause twice ⇒ stop, don't keep cycling."""
    from codegen_pipeline.codegen.repair import decide
    from codegen_pipeline.models import Diagnosis

    diag = Diagnosis(confidence=0.9, category="code_bug",
                     root_cause="off-by-one in chained product", suggested_patch="x")
    prior = [diag, diag]
    decision = decide(diag, attempt=3, max_attempts=5, prior_diagnoses=prior)
    assert decision.should_retry is False
    assert "oscillation" in decision.reason.lower()
