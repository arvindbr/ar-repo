# Codegen Pipeline — Working Reference

End-to-end implementation of the agent pipeline from Plate IV: read requirements → plan → generate code (with recursive repair loop) → governance → QA → output.

Runs against a toy requirement, with a deterministic mocked LLM so you don't need API keys.

## What it does

Given a requirement (text spec, Excel, screenshot, or freeform query), the pipeline:

1. **Reads** the requirement and normalizes to a unified model
2. **Plans** — decomposes into checkpoints and stories
3. **Generates code** in a recursive loop: `plan → schema → write → test → analyze → repair`
4. **Applies governance** (PII, secrets, license, lint) on every iteration
5. **Runs QA agents** for spec conformance, behavior, regression
6. **Outputs** an HTML report, JSON payload, and PR-ready bundle

## Run it

```bash
cd /home/claude/codegen_pipeline
pip install -e .
python -m codegen_pipeline run examples/twr_requirement.md
```

The toy requirement asks for a time-weighted return calculator. The mocked LLM
deliberately produces a buggy first draft so you can watch the repair loop
recover.

## Project layout

```
src/codegen_pipeline/
  __init__.py
  cli.py              # entry point: `python -m codegen_pipeline run <spec>`
  models.py           # Requirement, Story, Plan, RunState, etc.
  read/               # band 01: input adapters
    __init__.py
    text.py
    excel.py
    ocr.py
    query.py
  plan.py             # band 02: decomposition + checkpoints
  codegen/            # band 03: the loop
    __init__.py
    loop.py           # the recursive repair driver
    plan_step.py      # plan() — decide approach
    schema.py         # get live schema (mocked INFORMATION_SCHEMA)
    write.py          # write_code()
    test.py           # run_tests() — actually runs pytest
    analyze.py        # analyze_errors()
    repair.py         # patch + retry
  governance.py       # cross-cutting: PII, secrets, license, lint
  qa/                 # band 04
    __init__.py
    spec_conformance.py
    behavior.py
    regression.py
  output/             # band 05
    __init__.py
    html_report.py
    json_payload.py
    pr.py
  llm.py              # mocked LLM (deterministic, scripted responses)
  checkpoints.py      # resumable run state
examples/
  twr_requirement.md  # the toy spec
tests/
  test_pipeline.py    # smoke test for the whole thing
```
