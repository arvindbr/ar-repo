"""Allow `python -m codegen_pipeline ...`"""
from .cli import main
import sys

if __name__ == "__main__":
    sys.exit(main())
