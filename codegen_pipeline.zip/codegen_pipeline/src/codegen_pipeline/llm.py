"""Deterministic mocked LLM.

Real codegen agents call out to Claude/GPT/etc. For a runnable reference
without API keys, we script responses keyed on (caller_id, attempt_number)
so the pipeline behaves predictably and the repair loop is exercised
honestly — the mock returns a *buggy* first draft, then a corrected one
when called again with attempt > 1.

The contract is intentionally narrow: each stage that needs the model
calls `llm.complete(caller_id, context)` and gets back a string. Swap
this module for a real client (Anthropic/OpenAI/Foundry SDK) and nothing
else in the pipeline changes.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class LLMCall:
    caller_id: str
    attempt: int
    context: dict


class MockLLM:
    """Scripted responder. Tracks attempt counts per caller_id."""

    def __init__(self):
        self._attempt_counts: dict[str, int] = {}
        self.call_log: list[LLMCall] = []

    def complete(self, caller_id: str, context: dict | None = None) -> str:
        context = context or {}
        self._attempt_counts[caller_id] = self._attempt_counts.get(caller_id, 0) + 1
        attempt = self._attempt_counts[caller_id]
        self.call_log.append(LLMCall(caller_id, attempt, context))

        handler = _RESPONSES.get(caller_id)
        if handler is None:
            raise RuntimeError(
                f"MockLLM has no scripted response for caller_id={caller_id!r}. "
                f"Add one to _RESPONSES in llm.py."
            )
        return handler(attempt, context)

    def reset(self):
        self._attempt_counts.clear()
        self.call_log.clear()


# ---------------------------------------------------------------------------
# Scripted responses
# ---------------------------------------------------------------------------
# Each handler takes (attempt_number, context) and returns a string.
# Attempt numbers are 1-indexed.

def _plan_step(attempt: int, ctx: dict) -> str:
    # The plan() step inside the loop returns a structured plan as JSON.
    # Same plan on every attempt — only write_code changes between attempts.
    return (
        '{"approach": "Implement TWR using geometric chaining of sub-period '
        'returns. Validate inputs first. One module twr.py, one test file '
        'test_twr.py with cases from acceptance criteria.", '
        '"files": ["twr.py", "test_twr.py"], '
        '"reuse": []}'
    )


def _write_code(attempt: int, ctx: dict) -> str:
    """The interesting one. First attempt has a real bug; second attempt fixes it."""
    if attempt == 1:
        # Buggy: forgets to subtract the cash flow before computing the return,
        # so a deposit shows up as fake performance. The acceptance test
        # for "deposit between two equal valuations should not show as performance"
        # will fail and the repair loop will pick it up.
        return _bundle({
            "twr.py": _BUGGY_TWR,
            "test_twr.py": _TWR_TESTS,
        })
    else:
        # Fixed: properly subtracts flow before dividing.
        return _bundle({
            "twr.py": _CORRECT_TWR,
            "test_twr.py": _TWR_TESTS,
        })


def _analyze(attempt: int, ctx: dict) -> str:
    failure = ctx.get("failure_summary", "")
    if "deposit" in failure.lower() or "flow" in failure.lower() or "AssertionError" in failure:
        return (
            '{"confidence": 0.92, "category": "code_bug", '
            '"root_cause": "sub-period return is computed without subtracting '
            'the cash flow that occurred at period start, so deposits inflate '
            'reported performance", '
            '"suggested_patch": "in time_weighted_return, change the sub_return '
            'formula to (values[i] - flows[i]) / values[i-1] - 1"}'
        )
    return (
        '{"confidence": 0.4, "category": "spec_gap", '
        '"root_cause": "unrecognized failure pattern", '
        '"suggested_patch": "regenerate from spec"}'
    )


def _qa_spec(attempt: int, ctx: dict) -> str:
    return '{"passed": true, "details": "Generated code matches all four acceptance criteria from the requirement."}'


def _qa_behavior(attempt: int, ctx: dict) -> str:
    return '{"passed": true, "details": "Property tests (associativity of chained returns, identity for flat portfolios) all pass."}'


_RESPONSES = {
    "plan_step": _plan_step,
    "write_code": _write_code,
    "analyze_errors": _analyze,
    "qa_spec_conformance": _qa_spec,
    "qa_behavior_validation": _qa_behavior,
}


# ---------------------------------------------------------------------------
# Code that the mock "writes" — bundled here so the file content is grounded
# in actual Python that runs, not made-up text.
# ---------------------------------------------------------------------------

_BUGGY_TWR = '''"""Time-weighted return."""
from typing import Sequence


def time_weighted_return(values: Sequence[float], flows: Sequence[float]) -> float:
    if not values or not flows:
        raise ValueError("values and flows must be non-empty")
    if len(values) != len(flows):
        raise ValueError("values and flows must have equal length")
    for v in list(values) + list(flows):
        if not isinstance(v, (int, float)):
            raise ValueError("all entries must be numeric")

    chained = 1.0
    for i in range(1, len(values)):
        # BUG: forgets to subtract flows[i] before dividing.
        sub_return = values[i] / values[i - 1] - 1
        chained *= (1 + sub_return)
    return chained - 1
'''

_CORRECT_TWR = '''"""Time-weighted return."""
from typing import Sequence


def time_weighted_return(values: Sequence[float], flows: Sequence[float]) -> float:
    if not values or not flows:
        raise ValueError("values and flows must be non-empty")
    if len(values) != len(flows):
        raise ValueError("values and flows must have equal length")
    for v in list(values) + list(flows):
        if not isinstance(v, (int, float)):
            raise ValueError("all entries must be numeric")

    chained = 1.0
    for i in range(1, len(values)):
        sub_return = (values[i] - flows[i]) / values[i - 1] - 1
        chained *= (1 + sub_return)
    return chained - 1
'''

_TWR_TESTS = '''"""Tests for time_weighted_return."""
import pytest
from twr import time_weighted_return


def test_flat_portfolio_no_flows_returns_zero():
    assert time_weighted_return([100.0, 100.0, 100.0], [0.0, 0.0, 0.0]) == 0.0


def test_simple_growth_no_flows():
    assert time_weighted_return([100.0, 110.0], [0.0, 0.0]) == pytest.approx(0.10)


def test_deposit_does_not_show_as_performance():
    # 100 -> deposit 50 -> 150. The portfolio did not actually grow.
    # TWR should be 0.0 because (150 - 50) / 100 - 1 == 0.
    assert time_weighted_return([100.0, 150.0], [0.0, 50.0]) == pytest.approx(0.0)


def test_mismatched_lengths_raises():
    with pytest.raises(ValueError):
        time_weighted_return([100.0, 110.0], [0.0])


def test_empty_inputs_raise():
    with pytest.raises(ValueError):
        time_weighted_return([], [])
'''


def _bundle(files: dict[str, str]) -> str:
    """Encode a multi-file response. The write step parses this back."""
    parts = []
    for path, content in files.items():
        parts.append(f"=== FILE: {path} ===\n{content}")
    return "\n".join(parts)


def parse_bundle(s: str) -> dict[str, str]:
    """Inverse of _bundle. Used by codegen.write to extract files from LLM output."""
    files = {}
    current_path = None
    current_lines: list[str] = []
    for line in s.splitlines(keepends=True):
        if line.startswith("=== FILE: ") and line.rstrip().endswith(" ==="):
            if current_path is not None:
                files[current_path] = "".join(current_lines)
            current_path = line.removeprefix("=== FILE: ").rstrip().removesuffix(" ===")
            current_lines = []
        else:
            current_lines.append(line)
    if current_path is not None:
        files[current_path] = "".join(current_lines)
    return files
