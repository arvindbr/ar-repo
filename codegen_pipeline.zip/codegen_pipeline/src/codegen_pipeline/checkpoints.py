"""Checkpoints — persist RunState to disk so a run can resume after a crash.

In a production pipeline this would write to a durable store (Cosmos DB,
S3, Postgres). For the reference we use the local filesystem under a
runs/ directory. The contract is the same either way: every stage writes
a checkpoint after completing, and a re-run from a checkpoint produces
the same result as a fresh run from that point.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from .models import RunState
from .output.json_payload import _encode


DEFAULT_DIR = Path(os.environ.get("CODEGEN_RUNS_DIR", "./runs"))


def save(state: RunState, *, stage: str, root: Path = DEFAULT_DIR) -> Path:
    run_dir = root / state.run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    path = run_dir / f"checkpoint__{stage}.json"
    path.write_text(json.dumps(_encode(state), indent=2), encoding="utf-8")
    return path


def list_checkpoints(run_id: str, root: Path = DEFAULT_DIR) -> list[Path]:
    run_dir = root / run_id
    if not run_dir.exists():
        return []
    return sorted(run_dir.glob("checkpoint__*.json"))
