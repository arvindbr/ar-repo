"""Output band — packages run state into human and machine consumable forms."""
from .html_report import render_html
from .json_payload import render_json
from .pr import generate_pr_bundle
