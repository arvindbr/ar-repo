"""JSON payload — machine-consumable run summary.

Same content as the HTML report but structured. Lets downstream automation
(dashboards, FinOps, compliance tracking) consume the run without scraping
HTML. Schema is versioned via the top-level "schema_version" field.
"""
from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from datetime import datetime
from enum import Enum

from ..models import RunState


SCHEMA_VERSION = "1.0.0"


def render_json(state: RunState, *, indent: int = 2) -> str:
    return json.dumps(_encode(state), indent=indent, default=_fallback)


def _encode(state: RunState) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "run_id": state.run_id,
        "started_at": state.started_at.isoformat(),
        "completed_at": state.completed_at.isoformat() if state.completed_at else None,
        "failed": state.failed,
        "failure_reason": state.failure_reason,
        "requirement": _to_dict(state.requirement) if state.requirement else None,
        "plan": _to_dict(state.plan) if state.plan else None,
        "story_results": [_to_dict(s) for s in state.story_results],
        "qa_results": [_to_dict(q) for q in state.qa_results],
    }


def _to_dict(obj):
    if obj is None:
        return None
    if is_dataclass(obj):
        return {k: _to_dict(v) for k, v in asdict(obj).items()}
    if isinstance(obj, list):
        return [_to_dict(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


def _fallback(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, Enum):
        return obj.value
    return str(obj)
