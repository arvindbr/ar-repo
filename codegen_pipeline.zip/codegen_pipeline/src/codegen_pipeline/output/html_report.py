"""HTML report — human-readable run summary.

Designed to be skimmable: a reviewer should be able to tell whether to
approve without reading every file. Sections:
  - Summary header (pass/fail, story count, attempt count)
  - Per-story timeline showing each attempt and what changed
  - Governance findings
  - QA results
  - File diffs (final state)
"""
from __future__ import annotations

import html
from datetime import datetime, timezone

from ..models import RunState


def render_html(state: RunState) -> str:
    overall_pass = (
        not state.failed
        and all(s.success for s in state.story_results)
        and all(q.passed for q in state.qa_results)
    )
    status_label = "PASSED" if overall_pass else "FAILED"
    status_color = "#10a37f" if overall_pass else "#c4456a"

    parts: list[str] = []
    parts.append(_HEAD)
    parts.append(f'<header><div class="kicker">Codegen pipeline run</div>')
    parts.append(f'<h1>{html.escape(state.requirement.title) if state.requirement else "Untitled"}</h1>')
    parts.append(f'<div class="meta"><span class="run-id">run {state.run_id}</span>')
    parts.append(f'<span class="status" style="background:{status_color}">{status_label}</span>')
    parts.append(f'<span class="ts">{state.started_at.strftime("%Y-%m-%d %H:%M:%S UTC")}</span></div></header>')

    # Summary stats
    parts.append('<section><h2>Summary</h2><dl class="stats">')
    parts.append(f'<dt>Stories</dt><dd>{len(state.story_results)}</dd>')
    total_attempts = sum(s.attempts for s in state.story_results)
    parts.append(f'<dt>Total attempts</dt><dd>{total_attempts}</dd>')
    parts.append(f'<dt>QA agents</dt><dd>{len(state.qa_results)} run, '
                 f'{sum(1 for q in state.qa_results if q.passed)} passed</dd>')
    parts.append('</dl></section>')

    # Stories timeline
    parts.append('<section><h2>Stories</h2>')
    for s in state.story_results:
        story_status = "✓" if s.success else "✗"
        story_class = "ok" if s.success else "fail"
        parts.append(f'<article class="story {story_class}">')
        parts.append(f'<h3><span class="mark">{story_status}</span> {html.escape(s.story.id)} — {html.escape(s.story.title)}</h3>')
        parts.append(f'<p class="story-meta">{s.attempts} attempt(s)</p>')

        # Attempts
        parts.append('<ol class="attempts">')
        for i, tr in enumerate(s.test_history, 1):
            attempt_class = "ok" if tr.passed else "fail"
            label = "tests passed" if tr.passed else f"failed (exit {tr.exit_code})"
            parts.append(f'<li class="{attempt_class}"><span class="num">attempt {i}</span> {label}')
            if not tr.passed and tr.failure_summary:
                parts.append(f'<pre class="failure">{html.escape(tr.failure_summary[:600])}</pre>')
            parts.append('</li>')
        parts.append('</ol>')

        # Governance findings
        if s.governance.findings:
            parts.append('<details><summary>Governance findings</summary><ul class="gov">')
            for f in s.governance.findings:
                parts.append(
                    f'<li class="sev-{html.escape(f.severity)}">'
                    f'<code>{html.escape(f.rule)}</code> '
                    f'<span class="file">{html.escape(f.file)}</span>: '
                    f'{html.escape(f.message)}</li>'
                )
            parts.append('</ul></details>')

        # Final files
        if s.success and s.files:
            parts.append('<details><summary>Generated files</summary>')
            for gf in s.files:
                parts.append(f'<h4 class="filename">{html.escape(gf.path)}</h4>')
                parts.append(f'<pre class="code">{html.escape(gf.content)}</pre>')
            parts.append('</details>')

        if not s.success and s.final_diagnosis:
            parts.append('<div class="diagnosis">')
            parts.append(f'<strong>Final diagnosis:</strong> {html.escape(s.final_diagnosis.category)} '
                         f'(confidence {s.final_diagnosis.confidence:.2f})<br>')
            parts.append(html.escape(s.final_diagnosis.root_cause))
            parts.append('</div>')

        parts.append('</article>')
    parts.append('</section>')

    # QA results
    if state.qa_results:
        parts.append('<section><h2>QA agents</h2><ul class="qa">')
        for q in state.qa_results:
            mark = "✓" if q.passed else "✗"
            cls = "ok" if q.passed else "fail"
            parts.append(
                f'<li class="{cls}"><span class="mark">{mark}</span> '
                f'<strong>{html.escape(q.agent)}</strong>: {html.escape(q.details)}</li>'
            )
        parts.append('</ul></section>')

    parts.append(f'<footer>Generated {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")}</footer>')
    parts.append('</body></html>')
    return "".join(parts)


_HEAD = """<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>Codegen run report</title>
<style>
  :root { --ink:#0c0d10; --ink2:#14161b; --line:#2a2e38; --paper:#f3efe7;
          --muted:#8a8a92; --gold:#c8a665; --ok:#10a37f; --fail:#c4456a; }
  * { box-sizing: border-box; margin:0; padding:0; }
  body { background: var(--ink); color: var(--paper); font-family: 'Inter Tight', system-ui, sans-serif;
         padding: 32px 48px; line-height: 1.55; max-width: 1100px; margin: 0 auto; }
  header { border-bottom: 1px solid var(--line); padding-bottom: 22px; margin-bottom: 28px; }
  .kicker { font-family: 'JetBrains Mono', monospace; font-size: 10px; letter-spacing: 0.22em;
            text-transform: uppercase; color: var(--gold); margin-bottom: 8px; }
  h1 { font-family: 'Fraunces', serif; font-weight: 400; font-style: italic; font-size: 32px; line-height: 1.1; }
  .meta { display: flex; gap: 16px; align-items: center; margin-top: 12px;
          font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--muted); }
  .status { color: #fff; padding: 3px 10px; border-radius: 2px; font-weight: 600; letter-spacing: 0.1em; }
  section { margin: 32px 0; }
  h2 { font-family: 'Fraunces', serif; font-weight: 400; font-size: 22px; margin-bottom: 14px;
       padding-bottom: 6px; border-bottom: 1px solid var(--line); }
  h3 { font-family: 'Fraunces', serif; font-weight: 500; font-size: 17px; margin-bottom: 6px; }
  .stats { display: grid; grid-template-columns: auto 1fr; gap: 6px 20px;
           font-family: 'JetBrains Mono', monospace; font-size: 12px; }
  .stats dt { color: var(--muted); text-transform: uppercase; letter-spacing: 0.1em; font-size: 10px; }
  .story { background: var(--ink2); border: 1px solid var(--line); padding: 18px 22px; margin-bottom: 16px;
           border-left-width: 2px; }
  .story.ok { border-left-color: var(--ok); }
  .story.fail { border-left-color: var(--fail); }
  .story .mark { color: var(--gold); font-family: 'Fraunces', serif; font-style: italic;
                 font-size: 18px; margin-right: 6px; }
  .story-meta { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--muted);
                letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 12px; }
  .attempts { list-style: none; padding: 0; margin: 12px 0; }
  .attempts li { padding: 6px 0; border-top: 1px dashed var(--line);
                 font-family: 'JetBrains Mono', monospace; font-size: 12px; }
  .attempts li.ok { color: var(--ok); }
  .attempts li.fail { color: var(--fail); }
  .attempts .num { color: var(--muted); margin-right: 12px; }
  pre.failure, pre.code { background: var(--ink); border: 1px solid var(--line); padding: 12px 14px;
                          margin-top: 8px; font-family: 'JetBrains Mono', monospace; font-size: 11px;
                          line-height: 1.5; overflow-x: auto; color: var(--paper); white-space: pre-wrap; }
  details { margin-top: 12px; }
  summary { cursor: pointer; font-family: 'JetBrains Mono', monospace; font-size: 11px;
            color: var(--gold); letter-spacing: 0.1em; text-transform: uppercase; }
  ul.gov, ul.qa { list-style: none; padding: 0; margin-top: 8px; }
  ul.gov li, ul.qa li { padding: 5px 0; border-top: 1px dashed var(--line);
                       font-family: 'JetBrains Mono', monospace; font-size: 11px; }
  ul.gov code { color: var(--gold); }
  ul.gov .file { color: var(--muted); margin: 0 8px; }
  .sev-error { color: var(--fail); }
  .sev-warn  { color: #d4a85a; }
  .sev-info  { color: var(--muted); }
  ul.qa li.ok { color: var(--ok); }
  ul.qa li.fail { color: var(--fail); }
  ul.qa .mark { font-family: 'Fraunces', serif; margin-right: 8px; }
  h4.filename { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--gold);
                margin-top: 14px; margin-bottom: 4px; }
  .diagnosis { background: rgba(196,69,106,0.08); border-left: 2px solid var(--fail);
               padding: 10px 14px; margin-top: 12px; font-family: 'Fraunces', serif; font-size: 13px; }
  footer { margin-top: 48px; padding-top: 18px; border-top: 1px solid var(--line);
           font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--muted);
           letter-spacing: 0.15em; text-transform: uppercase; }
</style></head><body>"""
