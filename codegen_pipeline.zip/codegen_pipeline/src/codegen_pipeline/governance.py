"""Governance — runs on every loop iteration.

Five rule families:
  1. PII detection — refuse code that hardcodes personal data
  2. Secret scan — refuse hardcoded keys, tokens, connection strings
  3. License scan — reject incompatible OSS deps (stub for the reference)
  4. Style & lint — basic Python style smells
  5. Dependency policy — allowlist + flag known-suspect imports

Findings have a severity. Errors fail the gate; warnings don't. The
loop treats a failed gate the same as a failed test.
"""
from __future__ import annotations

import re

from .models import GeneratedFile, GovernanceFinding, GovernanceResult


# ---------------------------------------------------------------------------
# Rule definitions
# ---------------------------------------------------------------------------

# PII: SSN, credit-card-shaped, email-in-source-as-data (not import).
_PII_PATTERNS = [
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "SSN-shaped literal"),
    (re.compile(r"\b(?:\d[ -]?){13,16}\b"), "credit-card-shaped literal"),
]

# Secrets: API key prefixes, bearer-shaped tokens, connection strings.
_SECRET_PATTERNS = [
    (re.compile(r"sk-[A-Za-z0-9]{20,}"), "OpenAI-style API key"),
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS access key id"),
    (re.compile(r"AIza[0-9A-Za-z_-]{35}"), "Google API key"),
    (re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,}"), "Slack token"),
    (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"), "private key block"),
    (re.compile(
        r"(?:password|passwd|pwd)\s*=\s*[\"'][^\"'\s]{4,}[\"']",
        re.IGNORECASE
    ), "hardcoded password literal"),
    (re.compile(
        r"(?:Server|Host|Data Source)=[^;\s]+;.*?(?:Password|Pwd)=[^;\"'\s]+",
        re.IGNORECASE
    ), "connection string with credentials"),
]

# Dependency allowlist — anything not on this list raises a warning.
# In production this is config; here it's enough to keep the toy honest.
_DEP_ALLOWLIST = {
    "pytest", "typing", "dataclasses", "datetime", "enum", "pathlib",
    "json", "re", "subprocess", "sys", "os", "tempfile", "shutil",
    "math", "decimal", "fractions",
    "twr",  # the module under test
}

_IMPORT_RE = re.compile(r"^\s*(?:from\s+([A-Za-z_][\w.]*)|import\s+([A-Za-z_][\w.]*))", re.MULTILINE)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def check(files: list[GeneratedFile]) -> GovernanceResult:
    findings: list[GovernanceFinding] = []
    for f in files:
        findings.extend(_check_pii(f))
        findings.extend(_check_secrets(f))
        findings.extend(_check_dependencies(f))
        findings.extend(_check_style(f))
    passed = not any(x.severity == "error" for x in findings)
    return GovernanceResult(passed=passed, findings=findings)


# ---------------------------------------------------------------------------
# Individual rule implementations
# ---------------------------------------------------------------------------

def _check_pii(f: GeneratedFile) -> list[GovernanceFinding]:
    out: list[GovernanceFinding] = []
    for pat, label in _PII_PATTERNS:
        for m in pat.finditer(f.content):
            out.append(GovernanceFinding(
                rule="pii.literal",
                severity="error",
                file=f.path,
                message=f"{label} found at offset {m.start()}: {m.group()!r}",
            ))
    return out


def _check_secrets(f: GeneratedFile) -> list[GovernanceFinding]:
    out: list[GovernanceFinding] = []
    for pat, label in _SECRET_PATTERNS:
        for m in pat.finditer(f.content):
            # Don't echo the actual secret in the finding message.
            out.append(GovernanceFinding(
                rule="secret.hardcoded",
                severity="error",
                file=f.path,
                message=f"{label} detected at offset {m.start()}",
            ))
    return out


def _check_dependencies(f: GeneratedFile) -> list[GovernanceFinding]:
    out: list[GovernanceFinding] = []
    for m in _IMPORT_RE.finditer(f.content):
        mod = (m.group(1) or m.group(2)).split(".")[0]
        if mod not in _DEP_ALLOWLIST:
            out.append(GovernanceFinding(
                rule="dep.not_allowlisted",
                severity="warn",
                file=f.path,
                message=f"import {mod!r} is not on the allowlist",
            ))
    return out


def _check_style(f: GeneratedFile) -> list[GovernanceFinding]:
    out: list[GovernanceFinding] = []
    # Cheap lint: tabs mixed with spaces, lines over 120 chars, TODO markers.
    for i, line in enumerate(f.content.splitlines(), 1):
        if "\t" in line and "    " in line:
            out.append(GovernanceFinding(
                rule="style.mixed_indent",
                severity="warn",
                file=f.path,
                message=f"line {i}: tab and 4-space indent mixed",
            ))
        if len(line) > 120:
            out.append(GovernanceFinding(
                rule="style.line_too_long",
                severity="info",
                file=f.path,
                message=f"line {i} is {len(line)} chars",
            ))
    return out
