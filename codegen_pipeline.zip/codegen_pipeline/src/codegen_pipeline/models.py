"""Data models used across the pipeline.

Every stage produces typed objects so downstream stages can reason over
structure rather than parsing prose. These are the contracts that hold the
pipeline together.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class InputKind(str, Enum):
    TEXT = "text"
    EXCEL = "excel"
    OCR = "ocr"
    QUERY = "query"


@dataclass
class Requirement:
    """The unified requirement model. Every input adapter normalizes to this."""
    source_kind: InputKind
    source_path: str
    title: str
    body: str
    acceptance_criteria: list[str] = field(default_factory=list)
    extracted_entities: dict[str, Any] = field(default_factory=dict)


@dataclass
class Story:
    """A single unit of work the codegen loop will process."""
    id: str
    title: str
    description: str
    acceptance_criteria: list[str]
    target_module: str  # e.g. "twr.py"


@dataclass
class Plan:
    checkpoints: list[str]
    stories: list[Story]


@dataclass
class GeneratedFile:
    path: str
    content: str
    is_test: bool = False


@dataclass
class TestResult:
    passed: bool
    exit_code: int
    stdout: str
    stderr: str
    failure_summary: str | None  # set when passed is False


@dataclass
class Diagnosis:
    """Output of analyze_errors. Tells repair what to do."""
    confidence: float            # 0.0 to 1.0
    category: str                # "code_bug" | "test_bug" | "env" | "spec_gap"
    root_cause: str              # human-readable
    suggested_patch: str         # description of the fix to apply


@dataclass
class GovernanceFinding:
    rule: str
    severity: str                # "info" | "warn" | "error"
    file: str
    message: str


@dataclass
class GovernanceResult:
    passed: bool
    findings: list[GovernanceFinding]


@dataclass
class StoryRunResult:
    """Final outcome of one trip through the codegen loop for one story."""
    story: Story
    success: bool
    files: list[GeneratedFile]
    attempts: int
    test_history: list[TestResult]
    governance: GovernanceResult
    final_diagnosis: Diagnosis | None  # set on failure


@dataclass
class QAResult:
    agent: str                   # "spec_conformance" | "behavior" | "regression"
    passed: bool
    details: str


@dataclass
class RunState:
    """The complete state of a pipeline run. Persisted at every checkpoint."""
    run_id: str
    started_at: datetime
    requirement: Requirement | None = None
    plan: Plan | None = None
    story_results: list[StoryRunResult] = field(default_factory=list)
    qa_results: list[QAResult] = field(default_factory=list)
    completed_at: datetime | None = None
    failed: bool = False
    failure_reason: str | None = None
