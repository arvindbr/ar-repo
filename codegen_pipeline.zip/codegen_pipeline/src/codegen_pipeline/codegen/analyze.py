"""analyze_errors() — diagnose test failures.

Reads the failure summary, reconciles it with the code that just got
written, and produces a structured Diagnosis. The diagnosis is what
repair uses to decide what to patch.

Output is structured (category, confidence, root_cause, suggested_patch),
not prose, so repair can branch on category programmatically.
"""
from __future__ import annotations

import json

from ..llm import MockLLM
from ..models import Diagnosis, GeneratedFile, TestResult


def analyze_errors(
    llm: MockLLM,
    files: list[GeneratedFile],
    test_result: TestResult,
) -> Diagnosis:
    raw = llm.complete("analyze_errors", {
        "failure_summary": test_result.failure_summary or "",
        "exit_code": test_result.exit_code,
        "file_paths": [f.path for f in files],
    })
    data = json.loads(raw)
    return Diagnosis(
        confidence=float(data["confidence"]),
        category=data["category"],
        root_cause=data["root_cause"],
        suggested_patch=data["suggested_patch"],
    )
