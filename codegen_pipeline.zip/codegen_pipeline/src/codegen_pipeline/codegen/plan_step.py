"""plan() — the first stage inside the codegen loop.

Decides the approach for one story before any code is written. Output is
a structured plan (parsed JSON), not prose, so write_code() can consume it.
"""
from __future__ import annotations

import json
from dataclasses import dataclass

from ..llm import MockLLM
from ..models import Story


@dataclass
class StoryPlan:
    approach: str
    files: list[str]
    reuse: list[str]


def plan_step(llm: MockLLM, story: Story, schema: dict) -> StoryPlan:
    raw = llm.complete("plan_step", {
        "story_id": story.id,
        "title": story.title,
        "description": story.description,
        "acceptance": story.acceptance_criteria,
        "schema_keys": list(schema.keys()),
    })
    data = json.loads(raw)
    return StoryPlan(
        approach=data["approach"],
        files=data.get("files", []),
        reuse=data.get("reuse", []),
    )
