"""run_tests() — execute the generated test suite.

Materializes the generated files into a temp directory and shells out to
pytest. This is the one place in the pipeline that does real I/O and
real subprocess work — the test result is grounded in actual execution,
not a model's opinion of what would happen.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from ..models import GeneratedFile, TestResult


def run_tests(files: list[GeneratedFile], *, timeout: int = 30) -> TestResult:
    """Write files to a temp dir, run pytest, return a structured result."""
    workdir = Path(tempfile.mkdtemp(prefix="codegen_pipeline_run_"))
    try:
        for f in files:
            (workdir / f.path).write_text(f.content, encoding="utf-8")

        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "--tb=short", "--no-header"],
            cwd=workdir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        passed = result.returncode == 0
        return TestResult(
            passed=passed,
            exit_code=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
            failure_summary=None if passed else _summarize_failure(result.stdout, result.stderr),
        )
    except subprocess.TimeoutExpired as e:
        return TestResult(
            passed=False,
            exit_code=-1,
            stdout=e.stdout.decode() if e.stdout else "",
            stderr=e.stderr.decode() if e.stderr else "",
            failure_summary=f"Timeout after {timeout}s",
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _summarize_failure(stdout: str, stderr: str) -> str:
    """Pull the most informative lines out of pytest output for the diagnoser."""
    combined = (stdout or "") + "\n" + (stderr or "")
    # Take the FAILED lines and any AssertionError block.
    interesting: list[str] = []
    for line in combined.splitlines():
        if "FAILED" in line or "assert" in line.lower() or "Error" in line:
            interesting.append(line.strip())
    if not interesting:
        # Fall back to the last 20 lines so analyze_errors has something to work with.
        interesting = combined.strip().splitlines()[-20:]
    return "\n".join(interesting[:40])
