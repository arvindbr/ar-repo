"""repair — patch and retry.

Takes a Diagnosis from analyze_errors and decides what to do next:

  - If confidence is too low, escalate (return None to break the loop).
  - If the same diagnosis keeps recurring, detect oscillation and bail.
  - Otherwise, encode the diagnosis as the prior_diagnosis input to the
    next write_code attempt and let the loop re-enter.

This module is *just* the decision logic. The actual re-write happens in
loop.py — repair just says "go around again, here's the context".
"""
from __future__ import annotations

from dataclasses import dataclass

from ..models import Diagnosis


# Bound the loop. Beyond this we fail loudly rather than burn tokens
# on an unsolvable problem.
DEFAULT_MAX_ATTEMPTS = 5
MIN_REPAIR_CONFIDENCE = 0.5


@dataclass
class RepairDecision:
    should_retry: bool
    reason: str
    diagnosis_for_next_attempt: str | None  # passed back into write_code


def decide(
    diagnosis: Diagnosis,
    *,
    attempt: int,
    max_attempts: int = DEFAULT_MAX_ATTEMPTS,
    prior_diagnoses: list[Diagnosis] | None = None,
) -> RepairDecision:
    if attempt >= max_attempts:
        return RepairDecision(
            should_retry=False,
            reason=f"Max attempts ({max_attempts}) reached without passing tests.",
            diagnosis_for_next_attempt=None,
        )

    if diagnosis.confidence < MIN_REPAIR_CONFIDENCE:
        return RepairDecision(
            should_retry=False,
            reason=(
                f"Diagnosis confidence {diagnosis.confidence:.2f} below "
                f"threshold {MIN_REPAIR_CONFIDENCE}; escalating rather than "
                "burning more attempts on a guess."
            ),
            diagnosis_for_next_attempt=None,
        )

    # Oscillation check — if the same root_cause has shown up twice already,
    # repeating won't help. Bail.
    if prior_diagnoses:
        recurrences = sum(
            1 for prev in prior_diagnoses
            if prev.root_cause == diagnosis.root_cause
        )
        if recurrences >= 2:
            return RepairDecision(
                should_retry=False,
                reason=(
                    "Oscillation detected: same root cause diagnosed "
                    f"{recurrences + 1} times. Stopping."
                ),
                diagnosis_for_next_attempt=None,
            )

    return RepairDecision(
        should_retry=True,
        reason=f"{diagnosis.category}: {diagnosis.root_cause}",
        diagnosis_for_next_attempt=(
            f"PRIOR ATTEMPT FAILED. Diagnosis: {diagnosis.root_cause}. "
            f"Suggested fix: {diagnosis.suggested_patch}"
        ),
    )
