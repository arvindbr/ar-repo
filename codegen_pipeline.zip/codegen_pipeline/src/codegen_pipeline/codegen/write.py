"""write_code() — generate source files and tests.

Returns a list of GeneratedFile. The mock LLM bundles multiple files in
one response, parsed via llm.parse_bundle. In a real implementation the
caller would emit per-file responses or use a structured tool call.
"""
from __future__ import annotations

from ..llm import MockLLM, parse_bundle
from ..models import GeneratedFile, Story
from .plan_step import StoryPlan


def write_code(
    llm: MockLLM,
    story: Story,
    story_plan: StoryPlan,
    schema: dict,
    *,
    prior_diagnosis: str | None = None,
) -> list[GeneratedFile]:
    """Produce files for one story.

    `prior_diagnosis` is set on repair attempts so the model has context
    about what went wrong last time. The mock ignores its content and just
    returns the corrected version because attempt count drives behavior,
    but the parameter is here to match the real-LLM contract.
    """
    raw = llm.complete("write_code", {
        "story_id": story.id,
        "approach": story_plan.approach,
        "files_planned": story_plan.files,
        "schema_keys": list(schema.keys()),
        "prior_diagnosis": prior_diagnosis,
    })
    parsed = parse_bundle(raw)
    files: list[GeneratedFile] = []
    for path, content in parsed.items():
        files.append(GeneratedFile(
            path=path,
            content=content,
            is_test=path.startswith("test_") or path.endswith("_test.py"),
        ))
    return files
