"""get_schema() — live metadata retrieval.

In production this queries INFORMATION_SCHEMA on the target database (or
the equivalent introspection endpoint for non-SQL targets). It's *live*
on purpose — the whole point is to ground codegen in what's actually
deployed, not what training data remembers.

For this reference, since the toy requirement doesn't talk to a database,
we return a minimal schema dict that records the call happened. The
contract is what matters: every loop iteration calls this, and the
returned object is fed into plan_step and write_code.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def get_schema(target_module: str) -> dict[str, Any]:
    """Return live schema metadata relevant to this story.

    For SQL targets this would be:
        SELECT table_schema, table_name, column_name, data_type
        FROM information_schema.columns
        WHERE table_schema IN (...allowlist...)

    Cached only within the current run — never across runs.
    """
    return {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "target": target_module,
        "tables": {},     # populated for SQL targets
        "apis": {},       # populated for API targets (OpenAPI/GraphQL)
        "stdlib_only": True,
    }
