"""The codegen loop — drives a single story from plan to passing tests.

The full cycle, run per story:

    plan_step()   →  decide approach
    get_schema()  →  live target metadata
    write_code()  →  draft files + tests
    run_tests()   →  actually execute
        if passed → governance check → done
        if failed:
            analyze_errors()  →  structured diagnosis
            repair.decide()   →  retry? bail?
            if retry: feed diagnosis back into write_code, loop

Every iteration runs governance. Governance failures are treated like
test failures — they feed analyze_errors and trigger repair, rather than
silently blocking the PR at the end.
"""
from __future__ import annotations

from .. import governance
from ..llm import MockLLM
from ..models import (
    Diagnosis,
    GeneratedFile,
    GovernanceFinding,
    GovernanceResult,
    Story,
    StoryRunResult,
    TestResult,
)
from . import analyze, plan_step, repair, schema, test, write


def run_story(
    llm: MockLLM,
    story: Story,
    *,
    max_attempts: int = repair.DEFAULT_MAX_ATTEMPTS,
    log=print,
) -> StoryRunResult:
    """Run one story through the loop. Returns the final outcome."""
    log(f"\n  ┌── Story {story.id}: {story.title}")

    # Schema retrieval is per-story (not per-attempt) because the underlying
    # data shape doesn't change between attempts at the same story.
    sch = schema.get_schema(story.target_module)
    log(f"  │  schema fetched (target={story.target_module})")

    # Plan is also per-story. The repair feedback goes into write_code, not
    # back into plan — re-planning per attempt would let the agent thrash.
    sp = plan_step.plan_step(llm, story, sch)
    log(f"  │  plan: {sp.approach[:70]}{'...' if len(sp.approach) > 70 else ''}")

    files: list[GeneratedFile] = []
    test_history: list[TestResult] = []
    diagnosis_history: list[Diagnosis] = []
    last_diagnosis: Diagnosis | None = None
    prior_diagnosis_text: str | None = None
    final_governance: GovernanceResult = GovernanceResult(passed=True, findings=[])

    for attempt in range(1, max_attempts + 1):
        log(f"  │  attempt {attempt}/{max_attempts}:")

        files = write.write_code(
            llm, story, sp, sch,
            prior_diagnosis=prior_diagnosis_text,
        )
        log(f"  │    wrote {len(files)} file(s): {[f.path for f in files]}")

        # Governance runs first — cheaper than tests, so failing fast here saves
        # the test sandbox from having to spin up at all.
        gov = governance.check(files)
        if not gov.passed:
            log(f"  │    governance FAILED: {len(gov.findings)} finding(s)")
            # Treat governance like a test failure: synthesize a TestResult so
            # analyze_errors and repair work uniformly across both signals.
            synth = _governance_as_test_result(gov)
            test_history.append(synth)
            diag = analyze.analyze_errors(llm, files, synth)
            diagnosis_history.append(diag)
            last_diagnosis = diag
            decision = repair.decide(
                diag, attempt=attempt,
                max_attempts=max_attempts,
                prior_diagnoses=diagnosis_history[:-1],
            )
            if not decision.should_retry:
                log(f"  │    bail: {decision.reason}")
                final_governance = gov
                break
            prior_diagnosis_text = decision.diagnosis_for_next_attempt
            continue

        # Run the actual tests.
        tr = test.run_tests(files)
        test_history.append(tr)
        if tr.passed:
            log(f"  │    tests PASSED ✓")
            final_governance = gov
            break

        log(f"  │    tests FAILED (exit {tr.exit_code})")
        diag = analyze.analyze_errors(llm, files, tr)
        diagnosis_history.append(diag)
        last_diagnosis = diag
        log(f"  │    diagnosis: {diag.category} (conf {diag.confidence:.2f}) — {diag.root_cause[:60]}{'...' if len(diag.root_cause) > 60 else ''}")

        decision = repair.decide(
            diag,
            attempt=attempt,
            max_attempts=max_attempts,
            prior_diagnoses=diagnosis_history[:-1],
        )
        if not decision.should_retry:
            log(f"  │    bail: {decision.reason}")
            final_governance = gov
            break
        log(f"  │    repair: {decision.reason[:70]}{'...' if len(decision.reason) > 70 else ''}")
        prior_diagnosis_text = decision.diagnosis_for_next_attempt

    success = bool(test_history) and test_history[-1].passed and final_governance.passed
    log(f"  └── story {'OK' if success else 'FAILED'} after {len(test_history)} attempt(s)\n")

    return StoryRunResult(
        story=story,
        success=success,
        files=files,
        attempts=len(test_history),
        test_history=test_history,
        governance=final_governance,
        final_diagnosis=last_diagnosis if not success else None,
    )


def _governance_as_test_result(gov: GovernanceResult) -> TestResult:
    """Wrap governance findings in a TestResult shape so the rest of the loop
    can treat them uniformly."""
    summary_lines = [f"[{f.severity}] {f.rule} in {f.file}: {f.message}"
                     for f in gov.findings if f.severity == "error"]
    return TestResult(
        passed=False,
        exit_code=2,
        stdout="",
        stderr="governance failed",
        failure_summary="\n".join(summary_lines) or "governance check failed",
    )
