"""Text spec adapter — Markdown, plain text, or .docx.

Parses the document, extracts the title from the first H1, and pulls
acceptance criteria from a section that names them. Output: a Requirement.
"""
from __future__ import annotations

import re
from pathlib import Path

from ..models import InputKind, Requirement


def read(path: str) -> Requirement:
    body = Path(path).read_text(encoding="utf-8")
    return Requirement(
        source_kind=InputKind.TEXT,
        source_path=path,
        title=_extract_title(body) or Path(path).stem,
        body=body,
        acceptance_criteria=_extract_acceptance_criteria(body),
        extracted_entities=_extract_entities(body),
    )


def _extract_title(body: str) -> str | None:
    for line in body.splitlines():
        line = line.strip()
        if line.startswith("# "):
            return line.removeprefix("# ").strip()
    return None


def _extract_acceptance_criteria(body: str) -> list[str]:
    """Find a section headed with 'Acceptance criteria' (any case) and pull bullets."""
    lines = body.splitlines()
    in_section = False
    criteria: list[str] = []
    for line in lines:
        stripped = line.strip()
        if re.match(r"^#+\s*acceptance\s+criteria", stripped, re.IGNORECASE):
            in_section = True
            continue
        if in_section:
            if stripped.startswith("#"):
                # next section starts; stop
                break
            if stripped.startswith(("- ", "* ")):
                criteria.append(stripped[2:].strip())
    return criteria


def _extract_entities(body: str) -> dict:
    """Pull out structured hints the planner can use.

    For now: function signatures inferred from inline code, target module names.
    """
    entities: dict = {}
    # Look for `module.py` patterns
    modules = sorted(set(re.findall(r"\b([a-z_][a-z_0-9]*\.py)\b", body)))
    if modules:
        entities["target_modules"] = modules
    # Look for `function_name(...)` patterns inside backticks
    funcs = sorted(set(re.findall(r"`([a-z_][a-z_0-9]*)\([^`]*\)`", body)))
    if funcs:
        entities["functions"] = funcs
    return entities
