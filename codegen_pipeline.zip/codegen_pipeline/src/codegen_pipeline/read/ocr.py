"""Screenshot OCR adapter.

Real implementation: two passes — OCR for text, vision model for layout.
Reference implementation: accepts a sidecar .txt file describing what
the screenshot contains, so the rest of the pipeline can be exercised
without bringing in image dependencies.
"""
from __future__ import annotations

from pathlib import Path

from ..models import InputKind, Requirement


def read(path: str) -> Requirement:
    p = Path(path)
    sidecar = p.with_suffix(".txt")
    if not sidecar.exists():
        raise NotImplementedError(
            "Image OCR requires Document Intelligence + a vision model; "
            "not wired up in this reference. Provide a sidecar "
            f"{sidecar.name} describing the image content."
        )
    body = sidecar.read_text(encoding="utf-8")
    return Requirement(
        source_kind=InputKind.OCR,
        source_path=path,
        title=p.stem,
        body=body,
        acceptance_criteria=[],
        extracted_entities={"sidecar": str(sidecar)},
    )
