"""User-query adapter — freeform conversational asks.

The query string is the requirement body. No structure is inferred; the
planner does more work for these inputs because there's less to lean on.
"""
from __future__ import annotations

from ..models import InputKind, Requirement


def read(query: str, *, source_label: str = "<chat>") -> Requirement:
    return Requirement(
        source_kind=InputKind.QUERY,
        source_path=source_label,
        title=_summarize(query),
        body=query,
        acceptance_criteria=[],
        extracted_entities={},
    )


def _summarize(query: str) -> str:
    """Cheap summarizer: first sentence, capped at 80 chars."""
    first = query.strip().split(".")[0]
    return (first[:77] + "...") if len(first) > 80 else first
