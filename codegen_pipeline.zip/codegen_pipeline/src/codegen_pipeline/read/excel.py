"""Excel adapter.

In the real implementation this would parse cells, formulas, named ranges,
and VBA macros via openpyxl + a VBA parser. For this reference, we keep a
narrow stub that produces a Requirement when given a CSV-shaped extract,
and emits a clear "not implemented" message for true .xlsx inputs so the
caller knows where the boundary is.
"""
from __future__ import annotations

from pathlib import Path

from ..models import InputKind, Requirement


def read(path: str) -> Requirement:
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        raise NotImplementedError(
            "Excel parsing requires openpyxl + VBA extractor; not wired up "
            "in this reference. Convert to CSV or use the text adapter."
        )
    if suffix != ".csv":
        raise ValueError(f"Excel adapter expects .csv/.xlsx/.xlsm, got {suffix}")

    body = p.read_text(encoding="utf-8")
    rows = [row.split(",") for row in body.splitlines() if row.strip()]
    headers = rows[0] if rows else []
    return Requirement(
        source_kind=InputKind.EXCEL,
        source_path=path,
        title=p.stem,
        body=body,
        acceptance_criteria=[],
        extracted_entities={"headers": headers, "row_count": max(0, len(rows) - 1)},
    )
