"""Read band — input adapters that normalize sources to Requirement objects.

Dispatches to the right adapter based on file extension, or to the query
adapter for raw strings.
"""
from __future__ import annotations

from pathlib import Path

from ..models import Requirement
from . import excel, ocr, query, text

_TEXT_SUFFIXES = {".md", ".markdown", ".txt", ".rst"}
_EXCEL_SUFFIXES = {".csv", ".xlsx", ".xlsm"}
_IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}


def read(source: str) -> Requirement:
    """Read a requirement from a file path or treat the string as a query."""
    p = Path(source)
    if not p.exists():
        # Not a path on disk — treat it as a freeform query.
        return query.read(source)
    suffix = p.suffix.lower()
    if suffix in _TEXT_SUFFIXES:
        return text.read(source)
    if suffix in _EXCEL_SUFFIXES:
        return excel.read(source)
    if suffix in _IMAGE_SUFFIXES:
        return ocr.read(source)
    # Unknown extension — fall through to text best-effort
    return text.read(source)
