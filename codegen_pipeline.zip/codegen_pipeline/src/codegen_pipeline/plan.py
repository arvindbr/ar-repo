"""Plan band — turns a Requirement into a Plan (checkpoints + stories).

In the real pipeline this would call the LLM. For the reference, the
toy requirement is small enough that a deterministic decomposer makes
the test of the rest of the pipeline cleaner — exactly one story for
the TWR function, with acceptance criteria carried forward verbatim.
"""
from __future__ import annotations

from .models import Plan, Requirement, Story


_STANDARD_CHECKPOINTS = [
    "requirement_parsed",
    "plan_generated",
    "story_codegen_complete",
    "governance_cleared",
    "qa_passed",
    "output_packaged",
]


def plan(requirement: Requirement) -> Plan:
    target_modules = requirement.extracted_entities.get("target_modules") or ["main.py"]
    funcs = requirement.extracted_entities.get("functions") or []

    stories: list[Story] = []
    primary_module = target_modules[0]
    primary_func = funcs[0] if funcs else "main_function"

    stories.append(Story(
        id="STORY-001",
        title=f"Implement {primary_func} in {primary_module}",
        description=(
            f"Implement the function described in the requirement. "
            f"Target module: {primary_module}. "
            f"All acceptance criteria from the requirement must hold."
        ),
        acceptance_criteria=requirement.acceptance_criteria,
        target_module=primary_module,
    ))

    return Plan(checkpoints=list(_STANDARD_CHECKPOINTS), stories=stories)
