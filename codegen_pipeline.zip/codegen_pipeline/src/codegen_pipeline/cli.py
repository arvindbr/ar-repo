"""CLI entry point.

Usage:
    python -m codegen_pipeline run <source>
    python -m codegen_pipeline run examples/twr_requirement.md

Runs the full pipeline against the given source (file path or freeform
query string) and writes outputs to ./runs/<run_id>/.
"""
from __future__ import annotations

import argparse
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

from . import checkpoints, plan, read
from .codegen import run_story
from .llm import MockLLM
from .models import RunState
from .output import generate_pr_bundle, render_html, render_json
from .qa import check_spec_conformance, run_regression, validate_behavior


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="codegen-pipeline")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run", help="Run the full pipeline against a requirement")
    p_run.add_argument("source", help="Path to a requirement file, or freeform query")
    p_run.add_argument("--output-dir", default="./runs", help="Where to write outputs")
    p_run.add_argument("--max-attempts", type=int, default=5)

    args = parser.parse_args(argv)
    if args.cmd == "run":
        return _cmd_run(args)
    return 2


def _cmd_run(args) -> int:
    run_id = uuid.uuid4().hex[:12]
    root = Path(args.output_dir).resolve()
    run_dir = root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    state = RunState(run_id=run_id, started_at=datetime.now(timezone.utc))
    llm = MockLLM()

    print(f"╔═ codegen pipeline · run {run_id}")
    print(f"║  source: {args.source}")
    print(f"║  output: {run_dir}")
    print("╚═")

    # ─── Band 01: Read ────────────────────────────────────────────────
    print("\n[01] Read requirement")
    try:
        state.requirement = read.read(args.source)
    except Exception as e:
        return _fail(state, run_dir, f"read failed: {e}")
    print(f"     kind={state.requirement.source_kind.value}  "
          f"title={state.requirement.title!r}")
    print(f"     {len(state.requirement.acceptance_criteria)} acceptance criterion/criteria")
    checkpoints.save(state, stage="01_requirement_parsed", root=root)

    # ─── Band 02: Plan ────────────────────────────────────────────────
    print("\n[02] Plan")
    try:
        state.plan = plan.plan(state.requirement)
    except Exception as e:
        return _fail(state, run_dir, f"plan failed: {e}")
    print(f"     {len(state.plan.checkpoints)} checkpoint stages, "
          f"{len(state.plan.stories)} story/stories")
    for s in state.plan.stories:
        print(f"     · {s.id}: {s.title}")
    checkpoints.save(state, stage="02_plan_generated", root=root)

    # ─── Band 03: Generate code (loop per story) ──────────────────────
    print("\n[03] Generate code (recursive repair loop)")
    for story in state.plan.stories:
        result = run_story(llm, story, max_attempts=args.max_attempts)
        state.story_results.append(result)
    checkpoints.save(state, stage="03_codegen_complete", root=root)

    if not all(s.success for s in state.story_results):
        # Continue to outputs anyway so the failure report is generated.
        print("     some stories failed; continuing to package failure report")

    # ─── Band 04: QA ──────────────────────────────────────────────────
    print("[04] QA agents")
    successful = [s for s in state.story_results if s.success]
    if successful:
        files_for_qa = [f for s in successful for f in s.files]
        qa1 = check_spec_conformance(llm, state.requirement, files_for_qa)
        print(f"     · spec_conformance: {'PASS' if qa1.passed else 'FAIL'} — {qa1.details[:80]}")
        state.qa_results.append(qa1)

        qa2 = validate_behavior(llm, files_for_qa)
        print(f"     · behavior:         {'PASS' if qa2.passed else 'FAIL'} — {qa2.details[:80]}")
        state.qa_results.append(qa2)

        qa3 = run_regression(files_for_qa)
        print(f"     · regression:       {'PASS' if qa3.passed else 'FAIL'} — {qa3.details[:80]}")
        state.qa_results.append(qa3)
    else:
        print("     skipped — no successful stories to validate")
    checkpoints.save(state, stage="04_qa_complete", root=root)

    # ─── Band 05: Output ──────────────────────────────────────────────
    print("\n[05] Package outputs")
    state.completed_at = datetime.now(timezone.utc)

    html_path = run_dir / "report.html"
    html_path.write_text(render_html(state), encoding="utf-8")
    print(f"     · {html_path}")

    json_path = run_dir / "run.json"
    json_path.write_text(render_json(state), encoding="utf-8")
    print(f"     · {json_path}")

    pr = generate_pr_bundle(state)
    pr_path = run_dir / "pr_bundle.json"
    pr_path.write_text(_pr_to_json(pr), encoding="utf-8")
    print(f"     · {pr_path}  (branch: {pr.branch}, draft={pr.draft})")

    checkpoints.save(state, stage="05_output_packaged", root=root)

    overall_pass = (
        all(s.success for s in state.story_results)
        and all(q.passed for q in state.qa_results)
    )
    print(f"\n══ run {run_id}: {'PASSED' if overall_pass else 'FAILED'}")
    return 0 if overall_pass else 1


def _fail(state: RunState, run_dir: Path, reason: str) -> int:
    state.failed = True
    state.failure_reason = reason
    state.completed_at = datetime.now(timezone.utc)
    (run_dir / "report.html").write_text(render_html(state), encoding="utf-8")
    (run_dir / "run.json").write_text(render_json(state), encoding="utf-8")
    print(f"\n!! pipeline failed: {reason}", file=sys.stderr)
    return 1


def _pr_to_json(pr) -> str:
    import json
    return json.dumps({
        "branch": pr.branch,
        "base": pr.base,
        "title": pr.title,
        "description": pr.description,
        "draft": pr.draft,
        "reviewers": pr.reviewers,
        "commits": [
            {
                "story_id": c.story_id,
                "message": c.message,
                "files": c.files,
            }
            for c in pr.commits
        ],
    }, indent=2)


if __name__ == "__main__":
    sys.exit(main())
