"""Spec conformance — does the code do what was asked?

Independent of the codegen agent. Reads the original requirement and the
generated code, asks whether they line up. Different from running tests:
tests check the code against its own tests; spec conformance checks that
the tests express the right thing.
"""
from __future__ import annotations

import json

from ..llm import MockLLM
from ..models import GeneratedFile, QAResult, Requirement


def check_spec_conformance(
    llm: MockLLM,
    requirement: Requirement,
    files: list[GeneratedFile],
) -> QAResult:
    raw = llm.complete("qa_spec_conformance", {
        "requirement_title": requirement.title,
        "acceptance_criteria": requirement.acceptance_criteria,
        "file_paths": [f.path for f in files],
    })
    data = json.loads(raw)
    return QAResult(
        agent="spec_conformance",
        passed=bool(data["passed"]),
        details=data["details"],
    )
