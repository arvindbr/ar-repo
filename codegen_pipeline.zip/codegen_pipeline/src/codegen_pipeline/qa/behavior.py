"""Behavior validation — property tests + edge cases the codegen agent
didn't write itself.

Independence matters. The codegen agent and the QA agent must not share
prompts — if they did, they'd share blind spots. In a real deployment
this would also use a different model config (different temperature,
different system prompt) for the same reason.
"""
from __future__ import annotations

import json

from ..llm import MockLLM
from ..models import GeneratedFile, QAResult


def validate_behavior(
    llm: MockLLM,
    files: list[GeneratedFile],
) -> QAResult:
    raw = llm.complete("qa_behavior_validation", {
        "file_paths": [f.path for f in files],
    })
    data = json.loads(raw)
    return QAResult(
        agent="behavior",
        passed=bool(data["passed"]),
        details=data["details"],
    )
