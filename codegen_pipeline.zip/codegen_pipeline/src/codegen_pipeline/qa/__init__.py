"""QA agents — independent validation after the codegen loop succeeds."""
from .behavior import validate_behavior
from .regression import run_regression
from .spec_conformance import check_spec_conformance
