"""Regression — runs the existing test suite to verify the change didn't
break anything else.

Cheap to run, expensive to skip. A failure here is a hard block: the PR
cannot proceed even if the new feature works perfectly. For the toy
reference there is no pre-existing suite, so this re-runs the generated
tests as a sanity check that they're stable across runs.
"""
from __future__ import annotations

from ..codegen import test as test_runner
from ..models import GeneratedFile, QAResult


def run_regression(files: list[GeneratedFile]) -> QAResult:
    result = test_runner.run_tests(files)
    return QAResult(
        agent="regression",
        passed=result.passed,
        details=(
            f"Re-ran the test suite (exit {result.exit_code}). "
            + ("All previously-green tests remain green." if result.passed
               else f"Failures: {result.failure_summary}")
        ),
    )
