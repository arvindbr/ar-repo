# Time-Weighted Return Calculator

## Background

Performance reporting needs a Python function that computes the
time-weighted return (TWR) for a series of cash flows.

## Functional requirements

Implement a function `time_weighted_return(values, flows)` in a module
`twr.py` that:

1. Takes two equal-length lists of floats:
   - `values`: portfolio market values at each measurement point (n entries)
   - `flows`: external cash flows that occurred just before each measurement (n entries; index 0 is the initial deposit)
2. Returns the time-weighted return as a float, expressed as a decimal
   (e.g. `0.05` for 5%).
3. Raises `ValueError` when the input lists are empty, of unequal length,
   or contain non-numeric values.

## Formula

For each sub-period i (1 to n-1):

    sub_return_i = (values[i] - flows[i]) / values[i-1] - 1

The overall TWR is the geometric chain of sub-returns:

    TWR = product(1 + sub_return_i for i in 1..n-1) - 1

## Acceptance criteria

- A flat portfolio with no flows returns `0.0`
- A portfolio that goes 100 → 110 with no flows returns `0.10`
- A portfolio with a 50 deposit between two equal valuations should not
  show that deposit as performance
- Mismatched list lengths raise `ValueError`
- Empty inputs raise `ValueError`
